package gestoreIoT;

import emulatori.*;
import models.Ricarica;
import org.eclipse.paho.client.mqttv3.*;
import utils.CodaRicariche;
import utils.Config;

import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GestoreIoT {

    private static final String TOPIC_LWT;
    private static final String TOPIC_CODA_RIC_ADD;
    private static final String TOPIC_MW_BOT_STATO;
    private static final String TOPIC_MW_BOT;
    private static final String TOPIC_MW_BOT_RIC_TERM;
    private static final String TOPIC_MW_BOT_RIC_INT;
    private static final String TOPIC_CONTROLLA_TARGA_OUT;
    private static final String TOPIC_CONTROLLA_TARGA_IN;
    private static final String TOPIC_TARGA_IN;
    private static final String TOPIC_TARGA_OUT;
    private static final String TOPIC_RIC_TERM;
    private static final String TOPIC_RIC_INT;
    private static final String TOPIC_RIC_CANC;

    private static final int ID_PARCHEGGIO;

    private static final String brokerUrl;
    private static final String MWBOT_LIBERO = "LIBERO";
    private static final Logger logger = Logger.getLogger(GestoreIoT.class.getName());

    private static MqttClient client;
    private static final CodaRicariche codaRicariche = new CodaRicariche();
    private static String statoMwbot = MWBOT_LIBERO;
    private static Ricarica ricaricaCorrente;
    // private static boolean mwbotDisconnesso = false;

    static {
        Config config = Config.getInstance();

        TOPIC_LWT = config.getTopicLwt();
        TOPIC_CODA_RIC_ADD = config.getTopicCodaRicAdd();
        TOPIC_MW_BOT = config.getTopicMwBot();
        TOPIC_MW_BOT_RIC_TERM = config.getTopicMwBotRicTerm();
        TOPIC_MW_BOT_STATO = config.getTopicMwBotStato();
        TOPIC_MW_BOT_RIC_INT = config.getTopicMwBotRicInt();
        TOPIC_CONTROLLA_TARGA_IN = config.getTopicControllaTargaIn();
        TOPIC_CONTROLLA_TARGA_OUT = config.getTopicControllaTargaOut();
        TOPIC_TARGA_IN = config.getTopicTargaIn();
        TOPIC_TARGA_OUT = config.getTopicTargaOut();
        TOPIC_RIC_TERM = config.getTopicRicTerm();
        TOPIC_RIC_INT = config.getTopicRicInt();
        TOPIC_RIC_CANC = config.getTopicRicCanc();

        ID_PARCHEGGIO = config.getIdParcheggio();

        brokerUrl = config.getBrokerUrl();

        try {
            client = new MqttClient(brokerUrl, MqttClient.generateClientId());

            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(false);
            options.setWill(TOPIC_LWT, "I'm gone. Bye.".getBytes(), 1, false);

            client.connect(options);
            logger.info("Connessione al broker MQTT riuscita");

            client.subscribe(TOPIC_CODA_RIC_ADD, 1);
            client.subscribe(TOPIC_MW_BOT_STATO, 1);
            client.subscribe(TOPIC_MW_BOT_RIC_TERM);
            client.subscribe(TOPIC_RIC_TERM, 1);
            client.subscribe(TOPIC_RIC_CANC, 1);
            client.subscribe(TOPIC_RIC_INT, 1);
            client.subscribe(TOPIC_TARGA_IN, 1);
            client.subscribe(TOPIC_TARGA_OUT, 1);
            client.subscribe(TOPIC_LWT, 1);
            logger.info("Sottoscrizione ai topic MQTT riuscita");

            client.setCallback(new Callback());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la connessione o sottoscrizione", e);
        }
    }

    public static void main(String[] args) {
        SbarraIngresso sbarraIngresso = new SbarraIngresso();
        SbarraUscita sbarraUscita = new SbarraUscita();
        MWbot mWbot = new MWbot();
        MonitorIngresso monitorIngresso = new MonitorIngresso();
        Sensori sensori = new Sensori();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            sbarraIngresso.disconnect();
            sbarraUscita.disconnect();
            mWbot.disconnect();
            monitorIngresso.disconnect();
            sensori.disconnect();

            try {
                if (client != null) {
                    client.disconnect();
                    client.close();
                    logger.info("Disconnessione e chiusura del client MQTT riuscita");
                }
            } catch (MqttException e) {
                logger.log(Level.SEVERE, "Errore durante la disconnessione o chiusura del client MQTT", e);
            }

            logger.info("Applicazione terminata correttamente.");
        }));

        new Thread(sbarraIngresso::start).start();
        new Thread(sbarraUscita::start).start();
        new Thread(mWbot::start).start();
        new Thread(() -> {
            monitorIngresso.start();
            sensori.start();
        }).start();
    }

    /* public GestoreIoT() {
        try {
            client = new MqttClient(brokerUrl, MqttClient.generateClientId());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore nella creazione del client MQTT", e);
        }
    } */

    /* public void start() {
        try {
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(false);
            options.setWill(TOPIC_LWT, "I'm gone. Bye.".getBytes(), 1, false);

            client.connect(options);
            logger.info("Connessione al broker MQTT riuscita");

            client.subscribe(TOPIC_CODA_RIC_ADD, 1);
            client.subscribe(TOPIC_MW_BOT_STATO, 1);
            client.subscribe(TOPIC_MW_BOT_RIC_TERM);
            client.subscribe(TOPIC_RIC_TERM, 1);
            client.subscribe(TOPIC_RIC_CANC, 1);
            client.subscribe(TOPIC_RIC_INT, 1);
            client.subscribe(TOPIC_TARGA_IN, 1);
            client.subscribe(TOPIC_TARGA_OUT, 1);
            client.subscribe(TOPIC_LWT, 1);
            logger.info("Sottoscrizione ai topic MQTT riuscita");

            client.setCallback(new Callback());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la connessione o sottoscrizione", e);
        }
    } */

    /* public void disconnect() {
        try {
            if (client != null) {
                client.disconnect();
                client.close();
                logger.info("Disconnessione e chiusura del client MQTT riuscita");
            }
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la disconnessione o chiusura del client MQTT", e);
        }
    } */

    private static class Callback implements MqttCallback {
        @Override
        public void connectionLost(Throwable throwable) {
            logger.log(Level.WARNING, "Connessione persa, tentativo di riconnessione...", throwable);

            boolean reconnected = false;
            int attempt = 0;
            while (!reconnected) {
                try {
                    Thread.sleep(2000);
                    client.connect();
                    reconnected = true;
                    logger.info("Riconnessione al broker MQTT riuscita");

                    client.subscribe(TOPIC_CODA_RIC_ADD, 1);
                    client.subscribe(TOPIC_MW_BOT_STATO, 1);
                    client.subscribe(TOPIC_MW_BOT_RIC_TERM);
                    client.subscribe(TOPIC_RIC_TERM, 1);
                    client.subscribe(TOPIC_RIC_CANC, 1);
                    client.subscribe(TOPIC_RIC_INT, 1);
                    client.subscribe(TOPIC_TARGA_IN, 1);
                    client.subscribe(TOPIC_TARGA_OUT, 1);
                    client.subscribe(TOPIC_LWT, 1);
                    logger.info("Sottoscrizione ai topic MQTT riuscita");
                } catch (MqttException | InterruptedException e) {
                    attempt++;
                    logger.log(Level.WARNING, "Errore durante la riconnessione al broker MQTT, tentativo: " + attempt, e);
                }
            }
        }

        @Override
        public void messageArrived(String s, MqttMessage mqttMessage) {
            logger.log(Level.SEVERE, "Arrivato messaggio sul topic: " + s);

            String payload = new String(mqttMessage.getPayload(), StandardCharsets.UTF_8);

            if (s.equals(TOPIC_CODA_RIC_ADD)) handleRicAdd(payload);
            if (s.equals(TOPIC_MW_BOT_STATO)) handleMWBotStato(payload);
            if (s.equals(TOPIC_MW_BOT_RIC_TERM)) haldeRicTerm(payload);
            if (s.equals(TOPIC_RIC_CANC)) handleRicCanc(payload);
            if (s.equals(TOPIC_RIC_INT)) handleRicInt(payload);
            if (s.equals(TOPIC_TARGA_IN)) handleTargaIn(payload);
            if (s.equals(TOPIC_TARGA_OUT)) handleTargaOut(payload);
            // if (s.equals(TOPIC_LWT)) handleLWT(payload);
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            try {
                logger.info("Consegna completata per il messaggio: " + iMqttDeliveryToken.getMessage());
            } catch (MqttException e) {
                logger.log(Level.WARNING, "Errore nel recupero del messaggio completato", e);
            }
        }

        private void handleMWBotStato(String payload) {
            String[] arr = payload.split(",");

            int idParcheggio = Integer.parseInt(arr[0]);
            if (ID_PARCHEGGIO != idParcheggio) return;

            statoMwbot = arr[1];
            logger.info("Aggiornato stato MWBot: " + statoMwbot);

            /* if (mwbotDisconnesso && statoMwbot.equals(MWBOT_LIBERO)) {
                iniziaRicarica(ricaricaCorrente);
                mwbotDisconnesso = false;
            } */
        }

        private void handleRicAdd(String payload) {
            String[] arr = payload.split(",");

            int idParcheggio = Integer.parseInt(arr[0]);
            if (ID_PARCHEGGIO != idParcheggio) return;

            int idRicarica = Integer.parseInt(arr[1]);
            int percentualeRichiesta = Integer.parseInt(arr[2]);
            int numeroPosto = Integer.parseInt(arr[3]);

            codaRicariche.add(new Ricarica(idRicarica, percentualeRichiesta, numeroPosto));

            if (codaRicariche.size() == 1 && statoMwbot.equals(MWBOT_LIBERO)) {
                Ricarica ricarica = codaRicariche.getFirst();

                // notificaNumeroCoda();

                iniziaRicarica(ricarica);
                ricaricaCorrente = ricarica;
            }
        }

        /* private void handleLWT(String payload) {
            if (payload.equals("Disconnesso MWbot")) mwbotDisconnesso = true;
        } */

        private void handleRicInt(String payload) {
            String[] arr = payload.split(",");

            int idParcheggio = Integer.parseInt(arr[0]);
            if (ID_PARCHEGGIO != idParcheggio) return;

            try {
                int idRicarica = Integer.parseInt(arr[1]);
                if (ricaricaCorrente != null && ricaricaCorrente.getId() == idRicarica) {
                    client.publish(TOPIC_MW_BOT_RIC_INT, (String.valueOf(ID_PARCHEGGIO)).getBytes(), 1, false);

                    logger.info("Pubblicato messaggio per interrompere l'MWBot: " + idRicarica);

                    if (codaRicariche.size() > 0) {
                        Ricarica ricarica = codaRicariche.getFirst();

                        // notificaNumeroCoda();

                        iniziaRicarica(ricarica);
                        ricaricaCorrente = ricarica;
                    } else {
                        ricaricaCorrente = null;
                    }
                }
            } catch (MqttException e) {
                logger.log(Level.SEVERE, "Errore durante la notifica di interruzione ricarica");
            }
        }

        private void handleRicCanc(String payload) {
            String[] arr = payload.split(",");

            int idParcheggio = Integer.parseInt(arr[0]);
            if (ID_PARCHEGGIO != idParcheggio) return;

            int idRicarica = Integer.parseInt(arr[0]);

            codaRicariche.removeById(idRicarica);

            // notificaNumeroCoda();

            logger.info("Rimossa ricarica dalla coda: " + idRicarica);
        }

        private void haldeRicTerm(String payload) {
            String[] arr = payload.split(",");

            int idParcheggio = Integer.parseInt(arr[0]);
            if (ID_PARCHEGGIO != idParcheggio) return;

            if (codaRicariche.size() > 0 && statoMwbot.equals(MWBOT_LIBERO)) {
                Ricarica ricarica = codaRicariche.getFirst();

                // notificaNumeroCoda();

                iniziaRicarica(ricarica);
                ricaricaCorrente = ricarica;
            } else {
                ricaricaCorrente = null;
            }

            try {
                client.publish(TOPIC_RIC_TERM, payload.getBytes(), 1, false);
            } catch (MqttException e) {
                logger.log(Level.SEVERE, "Errore durante la pubblicazione della ricarica terminata", e);
            }
        }

        private void handleTargaOut(String payload) {
            try {
                String[] arr = payload.split(",");

                int idParcheggio = Integer.parseInt(arr[0]);
                if (ID_PARCHEGGIO != idParcheggio) return;

                client.publish(TOPIC_CONTROLLA_TARGA_OUT, payload.getBytes(), 1, false);

                logger.info("Pubblicato messaggio per controllo targa: " + arr[1]);
            } catch (MqttException e) {
                logger.log(Level.SEVERE, "Errore durante la pubblicazione della targa in uscita", e);
            }
        }

        private void handleTargaIn(String payload) {
            try {
                String[] arr = payload.split(",");

                int idParcheggio = Integer.parseInt(arr[0]);
                if (ID_PARCHEGGIO != idParcheggio) return;

                client.publish(TOPIC_CONTROLLA_TARGA_IN, payload.getBytes(), 1, false);

                logger.info("Pubblicato messaggio per controllo targa: " + arr[1]);
            } catch (MqttException e) {
                logger.log(Level.SEVERE, "Errore durante la pubblicazione della targa in ingresso", e);
            }
        }

        private void iniziaRicarica(Ricarica ricarica) {
            try {
                String msg = ID_PARCHEGGIO + "," + ricarica.getId() + "," + ricarica.getPercentuale() + "," + ricarica.getNumeroPosto();

                client.publish(TOPIC_MW_BOT, msg.getBytes(), 1, false);

                logger.info("Pubblicato messaggio per nuova ricarica: " + msg);
            } catch (MqttException e) {
                logger.log(Level.SEVERE, "Errore durante l'avvio della ricarica", e);
            }
        }
    }
}
