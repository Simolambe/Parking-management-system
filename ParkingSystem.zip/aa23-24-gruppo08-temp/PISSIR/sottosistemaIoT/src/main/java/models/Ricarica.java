package models;

public class Ricarica {

    int id;
    int percentuale;
    int numeroPosto;

    public Ricarica(int id, int percentuale, int numeroPosto) {
        this.id = id;
        this.percentuale = percentuale;
        this.numeroPosto = numeroPosto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumeroPosto() {
        return numeroPosto;
    }

    public void setNumeroPosto(int numeroPosto) {
        this.numeroPosto = numeroPosto;
    }

    public int getPercentuale() {
        return percentuale;
    }

    public void setPercentuale(int percentuale) {
        this.percentuale = percentuale;
    }

}
