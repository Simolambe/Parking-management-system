package utils;

import org.tomlj.Toml;
import org.tomlj.TomlParseResult;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Config {
    private static Config instance;

    // [parcheggio]
    private int ID_PARCHEGGIO;
    private int NUMERO_POSTI_BASE;
    private int NUMERO_POSTI_PREMIUM;
    private int POTENZA_BOT;

    // [broker]
    private String BROKER_ULR;

    // [lights]
    private String LIGHTS_URL;

    // [topics]
    private String TOPIC_TARGA_IN;
    private String TOPIC_TARGA_OUT;
    private String TOPIC_CONTROLLA_TARGA_IN;
    private String TOPIC_CONTROLLA_TARGA_OUT;
    private String TOPIC_ERRORE_SOSTA_IN;
    private String TOPIC_ERRORE_SOSTA_OUT;
    private String TOPIC_SBARRA_IN;
    private String TOPIC_SBARRA_OUT;
    private String TOPIC_SENSORI;
    private String TOPIC_CODA_RIC_ADD;
    private String TOPIC_RIC_STATO;
    private String TOPIC_RIC_TERM;
    private String TOPIC_RIC_INT;
    private String TOPIC_RIC_CANC;
    private String TOPIC_MW_BOT;
    private String TOPIC_MW_BOT_STATO;
    private String TOPIC_MW_BOT_RIC_TERM;
    private String TOPIC_MW_BOT_RIC_INT;
    private String TOPIC_LWT;
    // private String TOPIC_CODA_RIC_NUM_CODA;

    private Config() {
        try {
            Path source = Paths.get("config.toml");
            TomlParseResult result = Toml.parse(source);

            result.errors().forEach(error -> System.err.println("Parsing error: " + error.toString()));

            if (!result.hasErrors()) {
                ID_PARCHEGGIO = result.getLong("parcheggio.id_parcheggio").intValue();
                NUMERO_POSTI_BASE = result.getLong("parcheggio.numero_posti_base").intValue();
                NUMERO_POSTI_PREMIUM = result.getLong("parcheggio.numero_posti_premium").intValue();
                POTENZA_BOT = result.getLong("parcheggio.potenza_bot").intValue();

                BROKER_ULR = result.getString("broker.broker_url");
                LIGHTS_URL = result.getString("lights.lights_url");

                TOPIC_TARGA_IN = result.getString("topics.TOPIC_TARGA_IN");
                TOPIC_TARGA_OUT = result.getString("topics.TOPIC_TARGA_OUT");
                TOPIC_CONTROLLA_TARGA_IN = result.getString("topics.TOPIC_CONTROLLA_TARGA_IN");
                TOPIC_CONTROLLA_TARGA_OUT = result.getString("topics.TOPIC_CONTROLLA_TARGA_OUT");
                TOPIC_ERRORE_SOSTA_IN = result.getString("topics.TOPIC_ERRORE_SOSTA_IN");
                TOPIC_ERRORE_SOSTA_OUT = result.getString("topics.TOPIC_ERRORE_SOSTA_OUT");
                TOPIC_SBARRA_IN = result.getString("topics.TOPIC_SBARRA_IN");
                TOPIC_SBARRA_OUT = result.getString("topics.TOPIC_SBARRA_OUT");
                TOPIC_SENSORI = result.getString("topics.TOPIC_SENSORI");
                TOPIC_CODA_RIC_ADD = result.getString("topics.TOPIC_CODA_RIC_ADD");
                // TOPIC_CODA_RIC_NUM_CODA = result.getString("topics.TOPIC_CODA_RIC_NUM_CODA");
                TOPIC_RIC_STATO = result.getString("topics.TOPIC_RIC_STATO");
                TOPIC_RIC_TERM = result.getString("topics.TOPIC_RIC_TERM");
                TOPIC_RIC_INT = result.getString("topics.TOPIC_RIC_INT");
                TOPIC_RIC_CANC = result.getString("topics.TOPIC_RIC_CANC");
                TOPIC_MW_BOT = result.getString("topics.TOPIC_MW_BOT");
                TOPIC_MW_BOT_STATO = result.getString("topics.TOPIC_MW_BOT_STATO");
                TOPIC_MW_BOT_RIC_TERM = result.getString("topics.TOPIC_MW_BOT_RIC_TERM");
                TOPIC_MW_BOT_RIC_INT = result.getString("topics.TOPIC_MW_BOT_RIC_INT");
                TOPIC_LWT = result.getString("topics.TOPIC_LWT");
            }
        } catch (IOException e) {
            System.err.println("Errore durante la lettura del file di configurazione: " + e.getMessage());
        }
    }

    public static synchronized Config getInstance() {
        if (instance == null) {
            instance = new Config();
        }
        return instance;
    }

    // Getters

    public String getTopicControllaTargaIn() {
        return TOPIC_CONTROLLA_TARGA_IN;
    }

    public String getTopicControllaTargaOut() {
        return TOPIC_CONTROLLA_TARGA_OUT;
    }

    public String getTopicErroreSostaIn() {
        return TOPIC_ERRORE_SOSTA_IN;
    }

    public String getTopicErroreSostaOut() {
        return TOPIC_ERRORE_SOSTA_OUT;
    }

    public String getTopicSbarraIn() {
        return TOPIC_SBARRA_IN;
    }

    public String getTopicSbarraOut() {
        return TOPIC_SBARRA_OUT;
    }

    public String getTopicSensori() {
        return TOPIC_SENSORI;
    }

    public String getTopicCodaRicAdd() {
        return TOPIC_CODA_RIC_ADD;
    }

    /* public String getTopicCodaRicNumCoda() {
        return TOPIC_CODA_RIC_NUM_CODA;
    } */

    public String getTopicRicStato() {
        return TOPIC_RIC_STATO;
    }

    public String getTopicRicTerm() {
        return TOPIC_RIC_TERM;
    }

    public String getTopicRicInt() {
        return TOPIC_RIC_INT;
    }

    public String getTopicRicCanc() {
        return TOPIC_RIC_CANC;
    }

    public String getTopicLwt() {
        return TOPIC_LWT;
    }

    public String getTopicTargaIn() {
        return TOPIC_TARGA_IN;
    }

    public String getTopicTargaOut() {
        return TOPIC_TARGA_OUT;
    }

    public String getTopicMwBot() {
        return TOPIC_MW_BOT;
    }

    public String getTopicMwBotStato() {
        return TOPIC_MW_BOT_STATO;
    }

    public String getTopicMwBotRicTerm() {
        return TOPIC_MW_BOT_RIC_TERM;
    }

    public String getTopicMwBotRicInt() {
        return TOPIC_MW_BOT_RIC_INT;
    }

    public int getIdParcheggio() {
        return ID_PARCHEGGIO;
    }

    public int getNumeroPostiBase() {
        return NUMERO_POSTI_BASE;
    }

    public int getNumeroPostiPremium() {
        return NUMERO_POSTI_PREMIUM;
    }

    public String getBrokerUrl() {
        return BROKER_ULR;
    }

    public String getLightsUrl() {
        return LIGHTS_URL;
    }

    public int getPotenzaBot() {
        return POTENZA_BOT;
    }
}
