package utils;

import models.Ricarica;

import java.util.ArrayList;
import java.util.List;

public class CodaRicariche {

    private static final List<Ricarica> coda = new ArrayList<>();

    public void add(Ricarica ricarica) {
        coda.add(ricarica);
    }

    public int size() {
        return coda.size();
    }

    public Ricarica getFirst() {
        return coda.remove(0);
    }

    public void removeById(int idRicarica) {
        coda.removeIf(ricarica -> ricarica.getId() == idRicarica);
    }
}
