package emulatori;

import org.eclipse.paho.client.mqttv3.*;
import utils.Config;

import javax.swing.*;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MWbot {

    private static final String TOPIC_LWT;
    private static final String TOPIC_MW_BOT;
    private static final String TOPIC_MW_BOT_RIC_INT;
    private static final String TOPIC_MW_BOT_RIC_TERM;
    private static final String TOPIC_MW_BOT_STATO;
    private static final String TOPIC_RIC_STATO;

    private static final String LIBERO = "LIBERO";
    private static final String OCCUPATO = "OCCUPATO";
    // private static final String RICONNESSO = "RICONNESSO";

    private static final int ID_PARCHEGGIO;
    private static final int POTENZA_BOT;

    private static final String brokerUrl;
    private static final Random random = new Random();
    private static final Logger logger = Logger.getLogger(MWbot.class.getName());

    private String stato;
    private MqttClient client;
    private PannelloMWBot pannelloMWBot;
    private Thread threadRicarica;
    private int idRicarica;
    private int percentualeRichiesta;
    private int percentualeAttuale;
    private int numeroPosto;
    private float kilowattRicaricati;

    static {
        Config config = Config.getInstance();

        TOPIC_LWT = config.getTopicLwt();
        TOPIC_MW_BOT = config.getTopicMwBot();
        TOPIC_MW_BOT_RIC_INT = config.getTopicMwBotRicInt();
        TOPIC_MW_BOT_RIC_TERM = config.getTopicMwBotRicTerm();
        TOPIC_MW_BOT_STATO = config.getTopicMwBotStato();
        TOPIC_RIC_STATO = config.getTopicRicStato();

        POTENZA_BOT = config.getPotenzaBot();
        ID_PARCHEGGIO = config.getIdParcheggio();

        brokerUrl = config.getBrokerUrl();
    }

    public MWbot() {
        try {
            client = new MqttClient(brokerUrl, MqttClient.generateClientId());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore nella creazione del client MQTT", e);
        }

        stato = LIBERO;

        SwingUtilities.invokeLater(() -> {
            pannelloMWBot = new PannelloMWBot();
            pannelloMWBot.aggiornaStato();
        });
    }

    public void start() {
        try {
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(false);
            options.setWill(client.getTopic(TOPIC_LWT), "Disconnessione MWbot".getBytes(), 1, false);

            client.connect(options);
            logger.info("Connessione al broker MQTT riuscita");

            client.subscribe(TOPIC_MW_BOT, 1);
            client.subscribe(TOPIC_MW_BOT_RIC_INT, 1);
            logger.info("Sottoscrizione ai topic riuscita");

            client.setCallback(new Callback());

            client.publish(TOPIC_MW_BOT_STATO, (ID_PARCHEGGIO + "," + stato).getBytes(), 1, false);
            logger.info("Pubblicazione dello stato iniziale riuscita: " + stato);
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la connessione o sottoscrizione", e);
        }
    }

    public void disconnect() {
        try {
            if (client != null) {
                client.disconnect();
                client.close();
                logger.info("Disconnessione e chiusura del client MQTT riuscita");
            }
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la disconnessione o chiusura del client MQTT", e);
        }
    }

    private void simulaRicarica() {
        threadRicarica = new Thread(() -> {
            try {
                logger.info("Inizio simulazione ricarica");

                cambiaStato();

                while (percentualeAttuale < percentualeRichiesta && !Thread.currentThread().isInterrupted()) {
                    percentualeAttuale += 1;
                    kilowattRicaricati += 0.75f;

                    String payload = ID_PARCHEGGIO + "," + idRicarica + "," + percentualeAttuale + "," + kilowattRicaricati + "," + POTENZA_BOT;
                    client.publish(TOPIC_RIC_STATO, payload.getBytes(), 1, false);
                    logger.info("Pubblicato stato ricarica: " + payload);

                    SwingUtilities.invokeLater(() -> pannelloMWBot.aggiornaRicarica(idRicarica, percentualeAttuale, kilowattRicaricati, numeroPosto));

                    Thread.sleep(3000);
                }

                if (!Thread.currentThread().isInterrupted()) {
                    cambiaStato();

                    String payload = ID_PARCHEGGIO + "," + idRicarica + "," + percentualeAttuale + "," + kilowattRicaricati;
                    client.publish(TOPIC_MW_BOT_RIC_TERM, payload.getBytes(), 1, false);
                    logger.info("Pubblicato termine ricarica: " + payload);
                }

                SwingUtilities.invokeLater(pannelloMWBot::cancellaRicarica);
                logger.info("Fine simulazione ricarica o interruzione");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.info("Simulazione ricarica interrotta");
            } catch (MqttException e) {
                logger.log(Level.SEVERE, "Errore durante la simulazione della ricarica", e);
            }
        });
        threadRicarica.start();
    }

    private void cambiaStato() {
        try {
            logger.info("Cambio stato");

            stato = stato.equals(LIBERO) ? OCCUPATO : LIBERO;
            client.publish(TOPIC_MW_BOT_STATO, (ID_PARCHEGGIO + "," + stato).getBytes(), 1, false);
            logger.info("Pubblicato nuovo stato: " + stato);

            SwingUtilities.invokeLater(pannelloMWBot::aggiornaStato);
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante il cambio di stato", e);
        }
    }

    private class Callback implements MqttCallback {
        @Override
        public void connectionLost(Throwable throwable) {
            logger.log(Level.WARNING, "Connessione persa, tentativo di riconnessione...", throwable);

            boolean reconnected = false;
            int attempt = 0;
            while (!reconnected) {
                try {
                    Thread.sleep(2000);
                    client.connect();
                    reconnected = true;
                    logger.info("Riconnessione al broker MQTT riuscita");

                    client.subscribe(TOPIC_MW_BOT, 1);
                    client.subscribe(TOPIC_MW_BOT_RIC_INT, 1);
                    logger.info("Sottoscrizione ai topic MQTT riuscita");

                    stato = LIBERO;
                    client.publish(TOPIC_MW_BOT_STATO, (ID_PARCHEGGIO + "," + stato).getBytes(), 1, false);
                } catch (MqttException | InterruptedException e) {
                    attempt++;
                    logger.log(Level.WARNING, "Errore durante la riconnessione al broker MQTT, tentativo: " + attempt, e);
                }
            }
        }

        @Override
        public void messageArrived(String s, MqttMessage mqttMessage) {
            logger.log(Level.SEVERE, "Arrivato messaggio sul topic: " + s);

            String payload = new String(mqttMessage.getPayload(), StandardCharsets.UTF_8);

            if (s.equals(TOPIC_MW_BOT)) handleRicarica(payload);
            if (s.equals(TOPIC_MW_BOT_RIC_INT)) handleInterrompiRicarica(payload);
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            try {
                logger.info("Consegna completata per il messaggio: " + iMqttDeliveryToken.getMessage());
            } catch (MqttException e) {
                logger.log(Level.WARNING, "Errore nel recupero del messaggio completato", e);
            }
        }

        private void handleRicarica(String payload) {
            String[] arr = payload.split(",");

            int idParcheggio = Integer.parseInt(arr[0]);
            if (idParcheggio != ID_PARCHEGGIO) return;

            if (stato.equals(LIBERO)) {
                idRicarica = Integer.parseInt(arr[1]);
                percentualeRichiesta = Integer.parseInt(arr[2]);
                numeroPosto = Integer.parseInt(arr[3]);
                percentualeAttuale = random.nextInt(31);
                kilowattRicaricati = 0.0f;

                logger.info("Ricevuto messaggio per nuova ricarica: ID " + idRicarica
                        + ", Percentuale Richiesta " + percentualeRichiesta
                        + ", Numero Posto " + numeroPosto);

                simulaRicarica();
            } else {
                logger.warning("Il MWbot è occupato. Ignorato il messaggio.");
            }
        }

        private void handleInterrompiRicarica(String payload) {
            int idParcheggio = Integer.parseInt(payload);
            if (idParcheggio != ID_PARCHEGGIO) return;

            if (threadRicarica != null && threadRicarica.isAlive()) {
                threadRicarica.interrupt();

                cambiaStato();

                SwingUtilities.invokeLater(pannelloMWBot::cancellaRicarica);

                logger.info("Ricarica interrotta con successo");
            }
        }
    }

    private class PannelloMWBot {
        private final JLabel jLabelStato;
        private final JLabel jLabelDatiRicarica;

        public PannelloMWBot() {
            JFrame jframe = new JFrame("MWBot");

            jLabelStato = new JLabel();
            jLabelStato.setBounds(50,50, 200,30);
            jframe.add(jLabelStato);

            jLabelDatiRicarica = new JLabel();
            jLabelDatiRicarica.setBounds(50, 100, 300, 100);
            jframe.add(jLabelDatiRicarica);

            jframe.setSize(600,400);
            jframe.setLayout(null);
            jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jframe.setVisible(true);
        }

        public void aggiornaStato() {
            logger.info("Aggiornamento stato pannello");
            jLabelStato.setText("Stato MWBot: " + stato.toLowerCase());
        }

        public void aggiornaRicarica(int idRicarica, int percentualeAttuale, float kilowattRicaricati, int numeroPosto) {
            logger.info("Aggiornamento dati ricarica pannello: ID " + idRicarica
                    + ", Percentuale Attuale " + percentualeAttuale
                    + ", Kilowatt Ricaricati " + kilowattRicaricati
                    + ", Numero Posto " + numeroPosto);
            jLabelDatiRicarica.setText("<html>Dati Ricarica:" +
                    "<br>- id ricarica: " + idRicarica +
                    "<br>- percentuale attuale: " + percentualeAttuale +
                    "<br>- kilowattRicaricati: " + kilowattRicaricati +
                    "<br>- numeroPosto: " + numeroPosto + "</html>");
        }

        public void cancellaRicarica() {
            logger.info("Cancellazione dati ricarica pannello");
            jLabelDatiRicarica.setText("");
        }
    }
}
