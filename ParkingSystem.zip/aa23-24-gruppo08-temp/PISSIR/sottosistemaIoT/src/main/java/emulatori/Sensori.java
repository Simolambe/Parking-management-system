package emulatori;

import org.eclipse.paho.client.mqttv3.*;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import utils.Config;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Sensori {

    private static final String TOPIC_LWT;
    private static final String TOPIC_SENSORI;

    private static final int ID_PARCHEGGIO;
    private static final int NUMERO_POSTI_BASE;
    private static final int NUMERO_POSTI_PREMIUM;

    private static final String lightsUrl;
    private static final String brokerUrl;

    private static final int[] red = {254, 254, 65535};
    private static final int[] green = {254, 254, 25500};
    private static final RestTemplate rest = new RestTemplate();
    private static final Logger logger = Logger.getLogger(Sensori.class.getName());

    private static MqttClient client;
    private Map allLights;
    private final Map<String, String> mapSensori;
    private PannelloPosti pannelloPosti;

    static {
        Config config = Config.getInstance();

        TOPIC_LWT = config.getTopicLwt();
        TOPIC_SENSORI = config.getTopicSensori();

        ID_PARCHEGGIO = config.getIdParcheggio();
        NUMERO_POSTI_BASE = config.getNumeroPostiBase();
        NUMERO_POSTI_PREMIUM = config.getNumeroPostiPremium();

        lightsUrl = config.getLightsUrl();
        brokerUrl = config.getBrokerUrl();

        /*rest = new RestTemplate();
        List<HttpMessageConverter<?>> messageConverters = new ArrayList<>();
        MappingJackson2HttpMessageConverter jacksonMessageConverter = new MappingJackson2HttpMessageConverter();
        messageConverters.add(jacksonMessageConverter);
        rest.setMessageConverters(messageConverters);*/
    }


    public Sensori() {
        try {
            client = new MqttClient(brokerUrl, MqttClient.generateClientId());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore nella creazione del client MQTT", e);
        }

        mapSensori = new HashMap<>();

        /* try {
            allLights = rest.getForObject(lightsUrl, Map.class);
        } catch (RestClientException e) {
            logger.log(Level.SEVERE, "Errore durante la chiamata a: " + lightsUrl, e);
        } */

        SwingUtilities.invokeLater(() -> pannelloPosti = new PannelloPosti());
    }

    public void start() {
        try {
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            options.setWill(TOPIC_LWT, "Disconnessione Sensori".getBytes(), 1, false);

            client.connect(options);
            client.setCallback(new Callback());
            logger.info("Connessione al broker MQTT riuscita");

            /* if (allLights == null) {
                for (int i = 1; i <= NUMERO_POSTI_PREMIUM + NUMERO_POSTI_BASE; i++) {
                    mapSensori.put(String.valueOf(i), "true");
                    publishStatus(String.valueOf(i));
                }
            } else {
                for (Object light : allLights.keySet()) {
                    mapSensori.put((String) light, "true");
                    changeStatus((String) light);
                    publishStatus((String) light);
                }
            }*/
            for (int i = 1; i <= NUMERO_POSTI_PREMIUM + NUMERO_POSTI_BASE; i++) {
                mapSensori.put(String.valueOf(i), "true");
                changeStatus(String.valueOf(i));
                publishStatus(String.valueOf(i));
            }
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la connessione o sottoscrizione", e);
        }
    }

    public void disconnect() {
        try {
            if (client != null) {
                client.disconnect();
                client.close();
                logger.info("Disconnessione e chiusura del client MQTT riuscita");
            }
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la disconnessione o chiusura del client MQTT", e);
        }
    }

    private void publishStatus(String light) {
        try {
            String stato = Objects.equals(mapSensori.get(light), "true") ? "LIBERO" : "OCCUPATO";
            client.publish(TOPIC_SENSORI + "/" + light, (ID_PARCHEGGIO + "," + stato).getBytes(), 1, false);
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante l'invio del messaggio MQTT", e);
        }
    }

    private void changeStatus(String light) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String status = mapSensori.get(light);
        String body = getBody(status);
        HttpEntity<String> request = new HttpEntity<>(body, headers);
        try {
            String callUrl = lightsUrl + "/" + light + "/state";
            rest.put(callUrl, request);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Errore durante la modifica dello stato delle luci", e);
        }
    }

    private void occupaPosto(String posto) {
        if (posto.isEmpty() || mapSensori.get(posto).equals("false")) {
            SwingUtilities.invokeLater(() -> pannelloPosti.mostraErrore("Il posto è già occupato."));
            return;
        }
        mapSensori.put(posto, "false");
        changeStatus(posto);
        publishStatus(posto);
        SwingUtilities.invokeLater(pannelloPosti::confermaOccupazione);
    }

    private void liberaPosto(String posto) {
        if (posto.isEmpty() || mapSensori.get(posto).equals("true")) {
            SwingUtilities.invokeLater(() -> pannelloPosti.mostraErrore("Il posto è già libero"));
            return;
        }
        mapSensori.put(posto, "true");
        changeStatus(posto);
        publishStatus(posto);
        SwingUtilities.invokeLater(pannelloPosti::confermaLiberazione);
    }

    private static String getBody(String status) {
        String body;
        if (status.equals("true")) {
            body = "{"
                    + "\"on\":true"
                    + ",\"sat\":" + green[0]
                    + ",\"bri\":" + green[1]
                    + ",\"hue\":" + green[2]
                    + "}";
        } else {
            body = "{"
                    + "\"on\":true"
                    + ",\"sat\":" + red[0]
                    + ",\"bri\":" + red[1]
                    + ",\"hue\":" + red[2]
                    + "}";
        }
        return body;
    }

    private static class Callback implements MqttCallback {

        @Override
        public void connectionLost(Throwable throwable) {
            logger.log(Level.WARNING, "Connessione persa, tentativo di riconnessione...", throwable);

            boolean reconnected = false;
            int attempt = 0;
            while (!reconnected) {
                try {
                    Thread.sleep(2000);
                    client.connect();
                    reconnected = true;
                    logger.info("Riconnessione al broker MQTT riuscita");
                } catch (MqttException | InterruptedException e) {
                    attempt++;
                    logger.log(Level.WARNING, "Errore durante la riconnessione al broker MQTT, tentativo: " + attempt, e);
                }
            }
        }

        @Override
        public void messageArrived(String s, MqttMessage mqttMessage) {
            logger.log(Level.SEVERE, "Arrivato messaggio sul topic: " + s);
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            try {
                logger.info("Consegna completata per il messaggio: " + iMqttDeliveryToken.getMessage());
            } catch (MqttException e) {
                logger.log(Level.WARNING, "Errore nel recupero del messaggio completato", e);
            }
        }
    }

    private class PannelloPosti {
        private final JFrame frame;
        private final JTextField fieldPosto;
        private final JButton occupaButton;
        private final JButton liberaButton;
        private final JLabel labelPosto;
        private JLabel labelConferma;

        public PannelloPosti() {
            frame = new JFrame("Controller posti");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 400);
            frame.setLayout(new BorderLayout());

            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);

            labelPosto = new JLabel("Inserisci il numero di un posto: ");
            gbc.gridx = 0;
            gbc.gridy = 0;
            panel.add(labelPosto, gbc);

            fieldPosto = new JTextField(6);
            fieldPosto.setPreferredSize(new Dimension(100, 25));
            gbc.gridx = 1;
            gbc.gridy = 0;
            panel.add(fieldPosto, gbc);

            occupaButton = new JButton("Occupa");
            occupaButton.setPreferredSize(new Dimension(100, 25));
            occupaButton.addActionListener(e -> occupaPosto(fieldPosto.getText()));
            gbc.gridx = 0;
            gbc.gridy = 1;
            panel.add(occupaButton, gbc);

            liberaButton = new JButton("Libera");
            liberaButton.setPreferredSize(new Dimension(100, 25));
            liberaButton.addActionListener(e -> liberaPosto(fieldPosto.getText()));
            gbc.gridx = 1;
            gbc.gridy = 1;
            panel.add(liberaButton, gbc);

            frame.add(panel, BorderLayout.CENTER);
            frame.setVisible(true);
        }

        public void mostraErrore(String msg) {
            frame.getContentPane().removeAll();

            JLabel labelErrore = new JLabel(msg, SwingConstants.CENTER);
            frame.add(labelErrore, BorderLayout.CENTER);

            JButton okButton = new JButton("OK");
            okButton.addActionListener(e -> resetFrame());
            frame.add(okButton, BorderLayout.SOUTH);

            frame.revalidate();
            frame.repaint();
        }

        public void confermaOccupazione() {
            frame.getContentPane().removeAll();

            labelConferma = new JLabel("Posto occupato con successo", SwingConstants.CENTER);
            frame.add(labelConferma, BorderLayout.CENTER);

            JButton okButton = new JButton("OK");
            okButton.addActionListener(e -> resetFrame());
            frame.add(okButton, BorderLayout.SOUTH);

            frame.revalidate();
            frame.repaint();
        }

        public void confermaLiberazione() {
            frame.getContentPane().removeAll();

            labelConferma = new JLabel("Posto liberato con successo", SwingConstants.CENTER);
            frame.add(labelConferma, BorderLayout.CENTER);

            JButton okButton = new JButton("OK");
            okButton.addActionListener(e -> resetFrame());
            frame.add(okButton, BorderLayout.SOUTH);

            frame.revalidate();
            frame.repaint();
        }

        private void resetFrame() {
            frame.getContentPane().removeAll();

            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);

            gbc.gridx = 0;
            gbc.gridy = 0;
            panel.add(labelPosto, gbc);

            fieldPosto.setText("");

            gbc.gridx = 1;
            gbc.gridy = 0;
            panel.add(fieldPosto, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            panel.add(occupaButton, gbc);

            gbc.gridx = 1;
            gbc.gridy = 1;
            panel.add(liberaButton, gbc);

            frame.add(panel, BorderLayout.CENTER);

            frame.revalidate();
            frame.repaint();
        }
    }
}
