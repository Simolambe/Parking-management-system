package emulatori;

import org.eclipse.paho.client.mqttv3.*;
import utils.Config;

import javax.swing.*;
import java.awt.*;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SbarraUscita {
    private static final String TOPIC_LWT;
    private static final String TOPIC_SBARRA_OUT;
    private static final String TOPIC_ERRORE_SOSTA_OUT;
    private static final String TOPIC_TARGA_OUT;

    private static final int ID_PARCHEGGIO;

    private static final String brokerUrl;
    private static final Logger logger = Logger.getLogger(SbarraUscita.class.getName());

    private MqttClient client;
    private PannelloTarga pannelloTarga;

    static {
        Config config = Config.getInstance();

        TOPIC_LWT = config.getTopicLwt();
        TOPIC_SBARRA_OUT = config.getTopicSbarraOut();
        TOPIC_ERRORE_SOSTA_OUT = config.getTopicErroreSostaOut();
        TOPIC_TARGA_OUT = config.getTopicTargaOut();

        ID_PARCHEGGIO = config.getIdParcheggio();

        brokerUrl = config.getBrokerUrl();
    }

    public SbarraUscita() {
        try {
            client = new MqttClient(brokerUrl, MqttClient.generateClientId());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore nella creazione del client MQTT", e);
        }

        SwingUtilities.invokeLater(() -> pannelloTarga = new PannelloTarga());
    }

    public void start() {
        try {
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(false);
            options.setWill(TOPIC_LWT, "Disconnessione SbarraUscita".getBytes(), 1, false);

            client.connect(options);
            logger.info("Connessione al broker MQTT riuscita");

            client.subscribe(TOPIC_SBARRA_OUT, 1);
            client.subscribe(TOPIC_ERRORE_SOSTA_OUT, 1);
            logger.info("Sottoscrizione ai topic MQTT riuscita");

            client.setCallback(new SbarraUscita.Callback());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la connessione o sottoscrizione", e);
        }
    }

    public void disconnect() {
        try {
            if (client != null) {
                client.disconnect();
                client.close();
                logger.info("Disconnessione e chiusura del client MQTT riuscita");
            }
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la disconnessione o chiusura del client MQTT", e);
        }
    }

    private void inviaTarga(String targa) {
        if (targa.isEmpty()) return;
        try {
            client.publish(TOPIC_TARGA_OUT, (ID_PARCHEGGIO + "," + targa).getBytes(), 1, false);
            logger.info("Targa inviata con successo: " + targa);
            SwingUtilities.invokeLater(pannelloTarga::clear);
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante l'invio del messaggio", e);
        }
    }

    private class Callback implements MqttCallback {
        @Override
        public void connectionLost(Throwable throwable) {
            logger.log(Level.WARNING, "Connessione persa, tentativo di riconnessione...", throwable);

            boolean reconnected = false;
            int attempt = 0;
            while (!reconnected) {
                try {
                    Thread.sleep(2000);
                    client.connect();
                    reconnected = true;
                    logger.info("Riconnessione al broker MQTT riuscita");

                    client.subscribe(TOPIC_SBARRA_OUT, 1);
                    client.subscribe(TOPIC_ERRORE_SOSTA_OUT, 1);
                    logger.info("Sottoscrizione ai topic MQTT riuscita");
                } catch (MqttException | InterruptedException e) {
                    attempt++;
                    logger.log(Level.WARNING, "Errore durante la riconnessione al broker MQTT, tentativo: " + attempt, e);
                }
            }
        }

        @Override
        public void messageArrived(String s, MqttMessage mqttMessage) {
            logger.log(Level.SEVERE, "Arrivato messaggio sul topic: " + s);
            String payload = new String(mqttMessage.getPayload(), StandardCharsets.UTF_8);

            if (s.equals(TOPIC_SBARRA_OUT)) {
                handleTargaOut(payload);
            }
            if (s.matches(TOPIC_ERRORE_SOSTA_OUT)) {
                handleErrore(payload);
            }
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            try {
                logger.info("Consegna completata per il messaggio: " + iMqttDeliveryToken.getMessage());
            } catch (MqttException e) {
                logger.log(Level.WARNING, "Errore nel recupero del messaggio completato", e);
            }
        }

        private void handleTargaOut(String payload) {
            String[] arr = payload.split(",");

            String idParcheggio = arr[0];
            if (Integer.parseInt(idParcheggio) != ID_PARCHEGGIO) return;

            String msg = arr[1];
            if (msg.equals("UP")) {
                System.out.println("Sto alzando la sbarra di uscita");
                pannelloTarga.confermaUscita();
            }
        }

        private void handleErrore(String payload) {
            String[] arr = payload.split(",");

            String idParcheggio = arr[0];
            if (Integer.parseInt(idParcheggio) != ID_PARCHEGGIO) return;

            String msg = arr[1];
            pannelloTarga.mostraErrore(msg);
        }
    }

    private class PannelloTarga {
        private final JFrame frame;
        private final JTextField targaField;
        private final JButton inviaButton;
        private final JLabel labelTarga;

        public PannelloTarga() {
            frame = new JFrame("Sbarra uscita");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 400);
            frame.setLayout(new BorderLayout());

            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);

            labelTarga = new JLabel("Inserisci una targa: ");
            gbc.gridx = 0;
            gbc.gridy = 0;
            panel.add(labelTarga, gbc);

            targaField = new JTextField(6);
            targaField.setPreferredSize(new Dimension(100, 25));
            gbc.gridx = 1;
            gbc.gridy = 0;
            panel.add(targaField, gbc);

            frame.add(panel, BorderLayout.CENTER);

            inviaButton = new JButton("Invia Targa");
            inviaButton.setPreferredSize(new Dimension(100, 25));
            inviaButton.addActionListener(e -> inviaTarga(targaField.getText()));
            frame.add(inviaButton, BorderLayout.SOUTH);

            frame.setVisible(true);
        }

        public void clear() {
            targaField.setText("");
        }

        public void confermaUscita() {
            frame.getContentPane().removeAll();

            JLabel labelConferma = new JLabel("Sosta terminata con successo", SwingConstants.CENTER);
            frame.add(labelConferma, BorderLayout.CENTER);

            JButton okButton = new JButton("OK");
            okButton.addActionListener(e -> resetFrame());
            frame.add(okButton, BorderLayout.SOUTH);

            frame.revalidate();
            frame.repaint();
        }

        public void mostraErrore(String msg) {
            frame.getContentPane().removeAll();

            JLabel labelErrore = new JLabel(msg, SwingConstants.CENTER);
            frame.add(labelErrore, BorderLayout.CENTER);

            JButton okButton = new JButton("OK");
            okButton.addActionListener(e -> resetFrame());
            frame.add(okButton, BorderLayout.SOUTH);

            frame.revalidate();
            frame.repaint();
        }

        private void resetFrame() {
            frame.getContentPane().removeAll();

            JPanel panel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);

            gbc.gridx = 0;
            gbc.gridy = 0;
            panel.add(labelTarga, gbc);

            gbc.gridx = 1;
            gbc.gridy = 0;
            panel.add(targaField, gbc);

            frame.add(panel, BorderLayout.CENTER);
            frame.add(inviaButton, BorderLayout.SOUTH);

            frame.revalidate();
            frame.repaint();
        }
    }
}
