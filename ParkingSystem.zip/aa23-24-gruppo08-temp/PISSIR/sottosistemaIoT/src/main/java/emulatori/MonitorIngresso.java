package emulatori;

import org.eclipse.paho.client.mqttv3.*;
import utils.Config;

import javax.swing.*;
import java.awt.*;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MonitorIngresso {

    private static final int ID_PARCHEGGIO;
    private static final String TOPIC_SENSORI;
    private static final String TOPIC_LWT;

    private static final String brokerUrl;
    private static final Logger logger = Logger.getLogger(MonitorIngresso.class.getName());

    private MqttClient client;
    private MonitorImpl monitorImpl;
    private int postiLiberi = 0;

    static {
        Config config = Config.getInstance();

        ID_PARCHEGGIO = config.getIdParcheggio();
        TOPIC_SENSORI = config.getTopicSensori();
        TOPIC_LWT = config.getTopicLwt();

        brokerUrl = config.getBrokerUrl();
    }

    public MonitorIngresso() {
        try {
            client = new MqttClient(brokerUrl, MqttClient.generateClientId());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore nella creazione del client MQTT", e);
        }

        SwingUtilities.invokeLater(() -> monitorImpl = new MonitorImpl());
    }

    public void start() {
        try {
            MqttConnectOptions options = new MqttConnectOptions();

            options.setCleanSession(false);
            options.setWill(client.getTopic(TOPIC_LWT), "Disconnessione MonitorIngresso".getBytes(), 1, false);

            client.connect(options);

            client.subscribe(TOPIC_SENSORI + "/+");
            client.setCallback(new Callback());
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la connessione o sottoscrizione", e);
        }
    }

    public void disconnect() {
        try {
            if (client != null) {
                client.disconnect();
                client.close();
                logger.info("Disconnessione e chiusura del client MQTT riuscita");
            }
        } catch (MqttException e) {
            logger.log(Level.SEVERE, "Errore durante la disconnessione o chiusura del client MQTT", e);
        }
    }

    private void decrementaContatore() {
        postiLiberi -= 1;
        monitorImpl.aggiornaMonitor();
    }

    private void incrementaContatore() {
        postiLiberi += 1;
        monitorImpl.aggiornaMonitor();
    }

    private class Callback implements MqttCallback {

        @Override
        public void connectionLost(Throwable throwable) {
            logger.log(Level.WARNING, "Connessione persa, tentativo di riconnessione...", throwable);

            boolean reconnected = false;
            int attempt = 0;
            while (!reconnected) {
                try {
                    Thread.sleep(2000);
                    client.connect();
                    reconnected = true;
                    logger.info("Riconnessione al broker MQTT riuscita");

                    client.subscribe(TOPIC_SENSORI + "/+");
                    logger.info("Sottoscrizione ai topic MQTT riuscita");
                } catch (MqttException | InterruptedException e) {
                    attempt++;
                    logger.log(Level.WARNING, "Errore durante la riconnessione al broker MQTT, tentativo: " + attempt, e);
                }
            }
        }

        @Override
        public void messageArrived(String s, MqttMessage mqttMessage) {
            logger.log(Level.SEVERE, "Arrivato messaggio sul topic: " + s);
            String payload = new String(mqttMessage.getPayload(), StandardCharsets.UTF_8);

            if  (s.matches(TOPIC_SENSORI + "/\\d+")) {
                handleSensore(payload);
            }
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            try {
                logger.info("Consegna completata per il messaggio: " + iMqttDeliveryToken.getMessage());
            } catch (MqttException e) {
                logger.log(Level.WARNING, "Errore nel recupero del messaggio completato", e);
            }
        }

        private void handleSensore(String payload) {
            String[] arr = payload.split(",");

            String idParcheggio = arr[0];
            if (Integer.parseInt(idParcheggio) != ID_PARCHEGGIO) return;

            String stato = arr[1];
            if (stato.equals("OCCUPATO")) {
                decrementaContatore();
            } else if (stato.equals("LIBERO")) {
                incrementaContatore();
            }
        }
    }

    private class MonitorImpl {
        JFrame jframe;
        JPanel jpanel;
        JLabel jlabel;
        String message;

        public MonitorImpl() {
            if (postiLiberi > 0) {
                message = "Posti liberi: " + postiLiberi;
            } else {
                message = "Pieno";
            }

            jframe = new JFrame("Monitor ingresso");
            jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            jframe.setSize(600, 400);
            jframe.setLayout(new BorderLayout());

            jpanel = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);

            jlabel = new JLabel(message);
            gbc.gridx = 0;
            gbc.gridy = 0;
            jpanel.add(jlabel, gbc);

            jframe.add(jpanel, BorderLayout.CENTER);
            jframe.setVisible(true);
        }

        public void aggiornaMonitor() {
            if (postiLiberi > 0) {
                message = "Posti liberi: " + postiLiberi;
            } else {
                message = "Pieno";
            }

            jlabel.setText(message);
        }
    }

}
