package services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dao.DaoException;
import dao.SosteDao;
import dao.UtenteDao;
import models.MetodoPagamento;
import models.Prenotazione;
import models.Sosta;
import models.Utente;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import spark.QueryParamsMap;
import spark.Request;
import spark.Response;
import utils.LocalDateSerializer;
import utils.LocalDateTimeSerializer;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

class ServizioSosteTest {

    /* private static final Gson GSON = new GsonBuilder()
            .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeSerializer())
            .registerTypeAdapter(LocalDate.class, new LocalDateSerializer())
            .create();
    private static MockedStatic<SosteDao> sosteDaoMockedStatic;
    private static MockedStatic<UtenteDao> utenteDaoMockedStatic;
    private static MockedStatic<ServizioPrenotazioni> servizioPrenotazioniMockedStatic;
    private static MockedStatic<ServizioParcheggio> servizioParcheggioMockedStatic;
    private static MockedStatic<ServizioPagamenti> servizioPagamentiMockedStatic;

    @BeforeEach
    void beforeEach() {
        sosteDaoMockedStatic = Mockito.mockStatic(SosteDao.class);
        utenteDaoMockedStatic = Mockito.mockStatic(UtenteDao.class);
        servizioPrenotazioniMockedStatic = Mockito.mockStatic(ServizioPrenotazioni.class);
        servizioParcheggioMockedStatic = Mockito.mockStatic(ServizioParcheggio.class);
        servizioPagamentiMockedStatic = Mockito.mockStatic(ServizioPagamenti.class);
    }

    @AfterEach
    void afterEach() {
        sosteDaoMockedStatic.close();
        utenteDaoMockedStatic.close();
        servizioPrenotazioniMockedStatic.close();
        servizioParcheggioMockedStatic.close();
        servizioPagamentiMockedStatic.close();
    }

    @Test
    void testGetSoste() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);
        QueryParamsMap queryParamsMap = mock(QueryParamsMap.class);

        when(request.queryMap()).thenReturn(queryParamsMap);
        when(queryParamsMap.hasKey("idUtente")).thenReturn(false);
        when(queryParamsMap.hasKey("corrente")).thenReturn(false);

        List<Sosta> sosteList = Arrays.asList(
                new Sosta(1, 1, 1, 1, LocalDateTime.now(), null, 10.0f, ServizioSoste.IN_CORSO, "AA111BB"),
                new Sosta(2, 2, 2, 2, LocalDateTime.now(), null, 15.0f, ServizioSoste.PASSATA, "CC222DD")
        );

        when(SosteDao.getSoste()).thenReturn(sosteList);

        // Act
        Object result = ServizioSoste.getSoste(request, response);

        // Assert
        String expectedJson = GSON.toJson(sosteList);
        assertEquals(expectedJson, result);
        verify(response).type("application/json");
        verify(response).status(200);
    }

    @Test
    void testGetSosteUtente() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);
        QueryParamsMap queryParamsMap = mock(QueryParamsMap.class);

        // Configura il comportamento del mock QueryParamsMap
        when(request.queryMap()).thenReturn(queryParamsMap);
        when(queryParamsMap.hasKey("idUtente")).thenReturn(true);
        when(request.queryMap("idUtente").value()).thenReturn("1");


        List<Sosta> sosteList = Arrays.asList(
                new Sosta(1, 1, 1, 1, LocalDateTime.now(), null, 10.0f, ServizioSoste.IN_CORSO, "AA111BB"),
                new Sosta(2, 1, 2, 2, LocalDateTime.now(), LocalDateTime.now().plusHours(2), 15.0f, ServizioSoste.PASSATA, "CC222DD")
        );

        when(SosteDao.getSosteUtente(1)).thenReturn(sosteList);

        // Act
        Object result = ServizioSoste.getSoste(request, response);

        // Assert
        String expectedJson = GSON.toJson(sosteList);
        assertEquals(expectedJson, result);
        verify(response).type("application/json");
        verify(response).status(200);
    }

    @Test
    void testGetSosteUtenteInCorso() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);
        QueryParamsMap queryParamsMap = mock(QueryParamsMap.class);

        when(request.queryMap()).thenReturn(queryParamsMap);
        when(request.queryMap().hasKey("idUtente")).thenReturn(true);
        when(request.queryMap("idUtente").value()).thenReturn("1");
        when(request.queryMap().hasKey("corrente")).thenReturn(true);
        when(request.queryMap("corrente").value()).thenReturn("true"); // Corretto valore di ritorno

        List<Sosta> sosteList = Arrays.asList(
                new Sosta(1, 1, 1, 1, LocalDateTime.now(), null, 10.0f, ServizioSoste.IN_CORSO, "AA111BB"),
                new Sosta(2, 1, 2, 2, LocalDateTime.now(), null, 15.0f, ServizioSoste.IN_CORSO, "CC222DD")
        );

        when(SosteDao.getSosteUtenteByStato(1, true)).thenReturn(sosteList);

        // Act
        Object result = ServizioSoste.getSoste(request, response);

        // Assert
        String expectedJson = GSON.toJson(sosteList);
        assertEquals(expectedJson, result);
        verify(response).type("application/json");
        verify(response).status(200);
    }

    @Test
    void testGetSosteUtentePassate() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);
        QueryParamsMap queryParamsMap = mock(QueryParamsMap.class);

        when(request.queryMap()).thenReturn(queryParamsMap);
        when(request.queryMap().hasKey("idUtente")).thenReturn(true);
        when(request.queryMap("idUtente").value()).thenReturn("1");
        when(request.queryMap().hasKey("corrente")).thenReturn(true);
        when(request.queryMap("corrente").value()).thenReturn("false"); // Corretto valore di ritorno

        List<Sosta> sosteList = Arrays.asList(
                new Sosta(1, 1, 1, 1, LocalDateTime.now(), LocalDateTime.now().plusHours(2), 10.0f, ServizioSoste.PASSATA, "AA111BB"),
                new Sosta(2, 1, 2, 2, LocalDateTime.now(), LocalDateTime.now().plusHours(1), 10.0f, ServizioSoste.PASSATA, "CC222DD")
        );

        when(SosteDao.getSosteUtenteByStato(1, false)).thenReturn(sosteList);

        // Act
        Object result = ServizioSoste.getSoste(request, response);

        // Assert
        String expectedJson = GSON.toJson(sosteList);
        assertEquals(expectedJson, result);
        verify(response).type("application/json");
        verify(response).status(200);
    }

    @Test
    void testAvviaSostaSuccess() throws DaoException {
        // Arrange
        String targa = "AA111BB";
        int idParcheggio = 1;

        Utente utente = new Utente(1, "Nome", "Cognome", "email@example.com", "password", 0, null);
        Sosta sosta = new Sosta(1, 1, 0, idParcheggio, LocalDateTime.now(), null, 10.0f, ServizioSoste.IN_CORSO, targa);
        MetodoPagamento metodoPagamento = new MetodoPagamento(1, "1234567812345678", "12", "25", "123", "Visa", "Nome Cognome");
        Prenotazione prenotazione = new Prenotazione(1, 1, idParcheggio, LocalDateTime.now().plusHours(1), LocalDateTime.now().plusHours(2), ServizioPrenotazioni.VALIDA, 1);

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(utente);
        when(SosteDao.getSostaByTarga(targa)).thenReturn(null);
        when(UtenteDao.getMetodoPagamento(utente.getId())).thenReturn(metodoPagamento);
        when(ServizioPrenotazioni.getFirstValida(utente.getId(), idParcheggio)).thenReturn(prenotazione);
        when(ServizioParcheggio.getPrezzoSosta(idParcheggio)).thenReturn(10.0f);
        when(SosteDao.addSosta(any(Sosta.class))).thenReturn(1);

        // Act
        int result = ServizioSoste.avviaSosta(targa, idParcheggio);

        // Assert
        assertEquals(0, result);
    }

    @Test
    void testTerminaSostaSuccess() throws DaoException {
        // Arrange
        String targa = "AA111BB";
        int idParcheggio = 1;

        Utente utente = new Utente(1, "Nome", "Cognome", "email@example.com", "password", 0, null);
        Sosta sosta = new Sosta(1, 1, 0, idParcheggio, LocalDateTime.now().minusHours(1), LocalDateTime.now(), 10.0f, ServizioSoste.IN_CORSO, targa);
        MetodoPagamento metodoPagamento = new MetodoPagamento(1, "1234567812345678", "12", "25", "123", "Visa", "Nome Cognome");

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(utente);
        when(SosteDao.getSostaByTarga(targa)).thenReturn(sosta);
        when(UtenteDao.getMetodoPagamento(utente.getId())).thenReturn(metodoPagamento);
        when(ServizioPagamenti.effettuaPagamento(any(Sosta.class))).thenReturn(true);

        // Act
        int result = ServizioSoste.terminaSosta(targa, idParcheggio);

        // Assert
        assertEquals(0, result);
        sosteDaoMockedStatic.verify(() -> SosteDao.terminaSosta(sosta));
    }

    @Test
    void testAvviaSosta_UtenteNonTrovato() throws DaoException {
        // Arrange
        String targa = "NON_EXISTENT";
        int idParcheggio = 1;

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(null);

        // Act
        int result = ServizioSoste.avviaSosta(targa, idParcheggio);

        // Assert
        assertEquals(1, result);
    }

    @Test
    void testAvviaSosta_SostaGiaInCorso() throws DaoException {
        // Arrange
        String targa = "AA111BB";
        int idParcheggio = 1;

        Utente utente = new Utente(1, "Nome", "Cognome", "email@example.com", "password", 0, null);
        Sosta sostaInCorso = new Sosta(1, 1, 0, idParcheggio, LocalDateTime.now(), null, 10.0f, ServizioSoste.IN_CORSO, targa);

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(utente);
        when(SosteDao.getSostaByTarga(targa)).thenReturn(sostaInCorso);

        // Act
        int result = ServizioSoste.avviaSosta(targa, idParcheggio);

        // Assert
        assertEquals(2, result);
    }

    @Test
    void testAvviaSosta_MetodoPagamentoNonTrovato() throws DaoException {
        // Arrange
        String targa = "AA111BB";
        int idParcheggio = 1;

        Utente utente = new Utente(1, "Nome", "Cognome", "email@example.com", "password", 0, null);
        Sosta sosta = new Sosta(1, 1, 0, idParcheggio, LocalDateTime.now(), null, 10.0f, ServizioSoste.PASSATA, targa);

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(utente);
        when(SosteDao.getSostaByTarga(targa)).thenReturn(null);
        when(UtenteDao.getMetodoPagamento(utente.getId())).thenReturn(null);

        // Act
        int result = ServizioSoste.avviaSosta(targa, idParcheggio);

        // Assert
        assertEquals(3, result);
    }

    @Test
    void testTerminaSosta_UtenteNonTrovato() throws DaoException {
        // Arrange
        String targa = "NON_EXISTENT";
        int idParcheggio = 1;

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(null);

        // Act
        int result = ServizioSoste.terminaSosta(targa, idParcheggio);

        // Assert
        assertEquals(1, result);
    }

    @Test
    void testTerminaSosta_SostaNonInCorso() throws DaoException {
        // Arrange
        String targa = "AA111BB";
        int idParcheggio = 1;

        Utente utente = new Utente(1, "Nome", "Cognome", "email@example.com", "password", 0, null);
        Sosta sostaPassata = new Sosta(1, 1, 0, idParcheggio, LocalDateTime.now().minusHours(2), LocalDateTime.now().minusHours(1), 10.0f, ServizioSoste.PASSATA, targa);

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(utente);
        when(SosteDao.getSostaByTarga(targa)).thenReturn(sostaPassata);

        // Act
        int result = ServizioSoste.terminaSosta(targa, idParcheggio);

        // Assert
        assertEquals(2, result);
    }

    @Test
    void testTerminaSosta_MetodoPagamentoNonTrovato() throws DaoException {
        // Arrange
        String targa = "AA111BB";
        int idParcheggio = 1;

        Utente utente = new Utente(1, "Nome", "Cognome", "email@example.com", "password", 0, null);
        Sosta sosta = new Sosta(1, 1, 0, idParcheggio, LocalDateTime.now().minusHours(1), null, 10.0f, ServizioSoste.IN_CORSO, targa);

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(utente);
        when(SosteDao.getSostaByTarga(targa)).thenReturn(sosta);
        when(UtenteDao.getMetodoPagamento(utente.getId())).thenReturn(null);

        // Act
        int result = ServizioSoste.terminaSosta(targa, idParcheggio);

        // Assert
        assertEquals(3, result);
    }

    @Test
    void testTerminaSosta_PagamentoFallito() throws DaoException {
        // Arrange
        String targa = "AA111BB";
        int idParcheggio = 1;

        Utente utente = new Utente(1, "Nome", "Cognome", "email@example.com", "password", 0, null);
        Sosta sosta = new Sosta(1, 1, 0, idParcheggio, LocalDateTime.now().minusHours(1), null, 10.0f, ServizioSoste.IN_CORSO, targa);
        MetodoPagamento metodoPagamento = new MetodoPagamento(1, "1234567812345678", "12", "25", "123", "Visa", "Nome Cognome");

        when(UtenteDao.getUtenteByTarga(targa)).thenReturn(utente);
        when(SosteDao.getSostaByTarga(targa)).thenReturn(sosta);
        when(UtenteDao.getMetodoPagamento(utente.getId())).thenReturn(metodoPagamento);
        when(ServizioPagamenti.effettuaPagamento(any(Sosta.class))).thenReturn(false);

        // Act
        int result = ServizioSoste.terminaSosta(targa, idParcheggio);

        // Assert
        assertEquals(5, result);
    } */

}
