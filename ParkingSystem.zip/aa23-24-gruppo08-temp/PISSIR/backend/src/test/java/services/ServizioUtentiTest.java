package services;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.google.gson.Gson;
import dao.DaoException;
import org.junit.jupiter.api.*;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import spark.QueryParamsMap;
import spark.Request;
import spark.Response;
import dao.UtenteDao;
import models.Utente;
import models.MetodoPagamento;
import models.Veicolo;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class ServizioUtentiTest {

    /* private static final Gson GSON = new Gson();
    private static MockedStatic<UtenteDao> utenteDaoMockedStatic;

    @BeforeEach
    void setUp() {
        utenteDaoMockedStatic = Mockito.mockStatic(UtenteDao.class);
    }

    @AfterEach
    void tearDown() {
        utenteDaoMockedStatic.close();
    }

    @Test
    void testGetUtenteByEmail() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        QueryParamsMap queryParamsMap = mock(QueryParamsMap.class);
        when(request.queryMap("email")).thenReturn(queryParamsMap);
        when(queryParamsMap.value()).thenReturn("email1@example.com");

        Utente utente = new Utente(1, "Nome1", "Cognome1", "email1@example.com", "password1", ServizioUtenti.UTENTE_BASE, null);

        when(UtenteDao.getUtenteByEmail("email1@example.com")).thenReturn(utente);

        // Act
        Object result = ServizioUtenti.getUtenteByEmail(request, response);

        // Assert
        String expectedJson = GSON.toJson(utente);
        assertEquals(expectedJson, result);
        verify(response).type("application/json");
        verify(response).status(200);
    }

    @Test
    void testGetUtenti() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        QueryParamsMap queryParamsMap = mock(QueryParamsMap.class);
        when(queryParamsMap.hasKey("email")).thenReturn(false);
        when(request.queryMap()).thenReturn(queryParamsMap);

        List<Utente> utentiList = Arrays.asList(
                new Utente(1, "Nome1", "Cognome1", "email1@example.com", "password1", ServizioUtenti.UTENTE_BASE, null),
                new Utente(2, "Nome2", "Cognome2", "email2@example.com", "password2", ServizioUtenti.UTENTE_BASE, null)
        );

        when(UtenteDao.getAll()).thenReturn(utentiList);

        // Act
        Object result = ServizioUtenti.getUtenti(request, response);

        // Assert
        String expectedJson = GSON.toJson(utentiList);
        assertEquals(expectedJson, result);
        verify(response).type("application/json");
        verify(response).status(200);
    }

    @Test
    void testAddUtente() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        String requestBody = "{\"nome\":\"Nome\",\"cognome\":\"Cognome\",\"email\":\"email@example.com\",\"password\":\"password123\"}";
        when(request.body()).thenReturn(requestBody);

        when(UtenteDao.findUserByEmail("email@example.com")).thenReturn(null);
        when(UtenteDao.addUser(any(Utente.class))).thenReturn(1);

        // Act
        Object result = ServizioUtenti.addUtente(request, response);

        // Assert
        assertEquals("", result);
        verify(response).header("Location", "/api/v1/utenti/1");
        verify(response).status(201);
    }

    @Test
    void testUpdateEmail() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");
        String requestBody = "{\"email\":\"newemail@example.com\"}";
        when(request.body()).thenReturn(requestBody);

        when(UtenteDao.findUserByEmail("newemail@example.com")).thenReturn(null);

        // Act
        Object result = ServizioUtenti.updateEmail(request, response);

        // Assert
        assertEquals("", result);
        utenteDaoMockedStatic.verify(() -> UtenteDao.updateEmail(1, "newemail@example.com"));
        verify(response).status(200);
    }

    @Test
    void testUpdatePassword() {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");
        String requestBody = "{\"password\":\"newpassword123\"}";
        when(request.body()).thenReturn(requestBody);

        // Act
        Object result = ServizioUtenti.updatePassword(request, response);

        // Assert
        assertEquals("", result);
        utenteDaoMockedStatic.verify(() -> UtenteDao.updatePassword(1, "newpassword123"));
        verify(response).status(200);
    }

    @Test
    void testDeleteUtente() {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");

        // Act
        Object result = ServizioUtenti.deleteUtente(request, response);

        // Assert
        assertEquals("", result);
        utenteDaoMockedStatic.verify(() -> UtenteDao.deleteUser(1));
        verify(response).status(200);
    }

    @Test
    void testAddMetodoPagamento() {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");
        String requestBody = "{\"numeroCarta\":\"1234567812345678\",\"annoScadenza\":\"25\",\"meseScadenza\":\"12\",\"cvv\":\"123\",\"tipoCarta\":\"Visa\",\"titolare\":\"Nome Cognome\"}";
        when(request.body()).thenReturn(requestBody);

        // Act
        Object result = ServizioUtenti.addMetodoPagamento(request, response);

        // Assert
        assertEquals("", result);
        utenteDaoMockedStatic.verify(() -> UtenteDao.addPaymentMethod(any(MetodoPagamento.class)));
        verify(response).status(200);
    }

    @Test
    void testGetMetodoPagamento() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");

        MetodoPagamento metodoPagamento = new MetodoPagamento(1, "1234567812345678", "12", "25", "123", "Visa", "Nome Cognome");

        when(UtenteDao.getMetodoPagamento(1)).thenReturn(metodoPagamento);

        // Act
        Object result = ServizioUtenti.getMetodoPagamento(request, response);

        // Assert
        String expectedJson = GSON.toJson(metodoPagamento);
        assertEquals(expectedJson, result);
        verify(response).type("application/json");
        verify(response).status(200);
    }

    @Test
    void testDeleteMetodoPagamento() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");

        MetodoPagamento metodoPagamento = new MetodoPagamento(1, "1234567812345678", "12", "25", "123", "Visa", "Nome Cognome");

        when(UtenteDao.getMetodoPagamento(1)).thenReturn(metodoPagamento);

        // Act
        Object result = ServizioUtenti.deleteMetodoPagamento(request, response);

        // Assert
        assertEquals("", result);
        utenteDaoMockedStatic.verify(() -> UtenteDao.deleteMetodoPagamento(1));
        verify(response).status(200);
    }

    @Test
    void testAddVeicolo() {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");
        String requestBody = "{\"targa\":\"AA111BB\",\"modello\":\"Modello\",\"marca\":\"Marca\",\"anno\":\"2022\"}";
        when(request.body()).thenReturn(requestBody);

        // Act
        Object result = ServizioUtenti.addVeicolo(request, response);

        // Assert
        assertEquals("", result);
        utenteDaoMockedStatic.verify(() -> UtenteDao.addVeicolo(any(Veicolo.class)));
        verify(response).status(200);
    }

    @Test
    void testGetVeicoli() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");

        Veicolo veicolo = new Veicolo(1, "AA111BB");

        when(UtenteDao.getVeicoli(1)).thenReturn(Collections.singletonList(veicolo));

        // Act
        Object result = ServizioUtenti.getVeicoli(request, response);

        // Assert
        String expectedJson = GSON.toJson(Collections.singletonList(veicolo));
        assertEquals(expectedJson, result);
        verify(response).type("application/json");
        verify(response).status(200);
    }

    @Test
    void testDeleteVeicolo() throws DaoException {
        // Arrange
        Request request = mock(Request.class);
        Response response = mock(Response.class);

        when(request.params("idUtente")).thenReturn("1");
        when(request.params("targa")).thenReturn("AA111BB");

        Veicolo veicolo = new Veicolo(1, "AA111BB");

        when(UtenteDao.getVeicoli(1)).thenReturn(Collections.singletonList(veicolo));

        // Act
        Object result = ServizioUtenti.deleteVeicolo(request, response);

        // Assert
        assertEquals("", result);
        utenteDaoMockedStatic.verify(() -> UtenteDao.deleteVeicolo("AA111BB"));
        verify(response).status(200);
    } */

}
