package server;

import static spark.Spark.*;

import com.google.gson.*;
import org.eclipse.paho.client.mqttv3.*;
import services.*;
import utils.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server {

    public static final Gson GSON;
    public static final String API_ROOT;
    public static final String API_VERSION;
    public static final HashMap<Integer, MqttClient> clientMap;

    private static final int PORT;
    private static final Logger logger = Logger.getLogger(Server.class.getName());

    private static final ControllorePrenotazioni controllorePrenotazioni;

    static {
        Config config = Config.getInstance();

        PORT = config.getPort();

        API_ROOT = config.getApiRoot();
        API_VERSION = config.getApiVersion();

        GSON = new GsonBuilder()
                .registerTypeAdapter(LocalDateTime.class, new LocalDateTimeSerializer())
                .registerTypeAdapter(LocalDate.class, new LocalDateSerializer())
                .create();

        clientMap = new HashMap<>();

        try {
            Map<Integer, String> mapBrokers = config.getMapBrokers();
            for (Integer idParcheggio : mapBrokers.keySet()) {
                MqttClient clientTemp = new MqttClient(mapBrokers.get(idParcheggio), MqttClient.generateClientId());

                MqttConnectOptions options = new MqttConnectOptions();

                options.setCleanSession(false);
                options.setWill(config.getTopicLwt(), "Disconnessione server".getBytes(), 1, false);

                clientTemp.connect(options);

                clientTemp.subscribe(config.getTopicControllaTargaIn(), 1);
                clientTemp.subscribe(config.getTopicControllaTargaOut(), 1);
                clientTemp.subscribe(config.getTopicSensori() + "/+", 1);
                clientTemp.subscribe(config.getTopicRicStato(), 1);
                clientTemp.subscribe(config.getTopicRicTerm(), 1);

                clientTemp.setCallback(new MQTTCallback(idParcheggio));

                clientMap.put(idParcheggio, clientTemp);

                logger.info("Connessione al broker per il parcheggio " + idParcheggio + " riuscita");
            }
        } catch (MqttException | IllegalArgumentException e) {
            logger.log(Level.SEVERE, "Connessione al broker fallita", e);
        }

        controllorePrenotazioni = ControllorePrenotazioni.getInstance();
        controllorePrenotazioni.controllaPrenotazioni(60000 * 15);
    }

    public static void main(String[] args) {
        port(PORT);

        before((request, response) -> {
            response.header("Access-Control-Allow-Origin", "*");
            response.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
            response.header("Access-Control-Allow-Headers", "Content-Type");
        });

        path(API_ROOT, () -> path(API_VERSION, () -> {

            /* --- Utenti --- */

            get("/utenti", ServizioUtenti::getUtenti);
            post("/utenti", "application/json", ServizioUtenti::addUtente);
            delete("/utenti/:idUtente", ServizioUtenti::deleteUtente);
            put("/utenti/:idUtente/nome", "application/json", ServizioUtenti::updateNome);
            put("/utenti/:idUtente/cognome", "application/json", ServizioUtenti::updateCognome);
            put("/utenti/:idUtente/immagine", "application/json", ServizioUtenti::upadateImmagine);
            put("/utenti/:idUtente/email", "application/json", ServizioUtenti::updateEmail);
            put("/utenti/:idUtente/password", "application/json", ServizioUtenti::updatePassword);
            post("/utenti/:idUtente/metodoPagamento", "application/json", ServizioUtenti::addMetodoPagamento);
            get("/utenti/:idUtente/metodoPagamento", ServizioUtenti::getMetodoPagamento);
            delete("/utenti/:idUtente/metodoPagamento", ServizioUtenti::deleteMetodoPagamento);
            post("/utenti/:idUtente/veicoli", "application/json", ServizioUtenti::addVeicolo);
            get("/utenti/:idUtente/veicoli", ServizioUtenti::getVeicoli);
            delete("/utenti/:idUtente/veicoli/:targa", ServizioUtenti::deleteVeicolo);

            /* Abbonamenti */

            post("/abbonamenti", ServizioAbbonamenti::addAbbonamento);
            get("/abbonamenti/costo", ServizioAbbonamenti::getCostoAbbonamento);

            /* Prenotazioni */

            get("/prenotazioni", ServizioPrenotazioni::getPrenotazioni);
            post("/prenotazioni", "application/json", ServizioPrenotazioni::addPrenotazione);
            get("/prenotazioni/:idPrenotazione/cancella", ServizioPrenotazioni::cancellaPrenotazione);

            /* Soste */

            get("/soste", ServizioSoste::getSoste);

            /* Ricariche */

            get("/ricariche", ServizioRicariche::getRicariche);
            post("/ricariche", "application/json", ServizioRicariche::addRicarica);
            post("/ricariche/:idRicarica/cancella", ServizioRicariche::cancellaRicarica);
            post("/ricariche/:idRicarica/interrompi", ServizioRicariche::interrompiRicarica);
            get("/ricariche/attesa", ServizioRicariche::getAttesa);

            /* Parcheggi */

            get("/parcheggi", ServizioParcheggio::getAll);
            get("/parcheggi/:idParcheggio", ServizioParcheggio::getById);
            get("/parcheggi/:idParcheggio/occupazione", ServizioParcheggio::getOccupazione);
            put("/parcheggi/:idParcheggio/costi", ServizioParcheggio::aggiornaCosti);
            get("/parcheggi/:idParcheggio/disponibilita", ServizioParcheggio::getDisponibilita);

            /* Pagamenti */
            get("/pagamenti", ServizioPagamenti::getPagamenti);

        }));

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                for (MqttClient client : clientMap.values()) {
                    if (client != null) {
                        client.disconnect();
                        client.close();
                        logger.info("Disconnessione e chiusura del client MQTT riuscita");
                    }
                }
            } catch (MqttException e) {
                logger.log(Level.SEVERE, "Errore durante la disconnessione o chiusura del client MQTT", e);
            }

            controllorePrenotazioni.interrupt();
        }));
    }
}
