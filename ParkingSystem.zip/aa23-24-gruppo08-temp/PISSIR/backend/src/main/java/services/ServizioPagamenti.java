package services;

import dao.RicaricheDao;
import spark.Request;
import spark.Response;
import dao.DaoException;
import models.Abbonamento;
import models.Pagamento;
import models.Ricarica;
import models.Sosta;
import dao.PagamentiDao;

import static server.Server.GSON;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import static spark.Spark.halt;

public class ServizioPagamenti {

    private static final int SOSTA = 0;
    private static final int RICARICA = 1;
    private static final int ABBONAMENTO = 2;

    public static boolean effettuaPagamento(Sosta sosta, LocalDateTime tempoFine) {
        try {
            PagamentiDao.addPagamento(new Pagamento(-1,
                    sosta.getIdUtente(),
                    sosta.getIdSosta(),
                    calcolaPrezzo(sosta.getTempoInizio(), tempoFine, sosta.getPrezzoOrario()),
                    LocalDate.now(),
                    SOSTA,
                    ServizioUtenti.getTipoUtente(sosta.getIdUtente())));

            List<Ricarica> ricariche = null;

            try {
                ricariche = RicaricheDao.getRicaricheBySosta(sosta.getIdSosta());
            } catch (DaoException e) {
                halt(500);
            }

            for (Ricarica ricarica : ricariche) {
                PagamentiDao.addPagamento(new Pagamento(-1,
                        ricarica.getIdUtente(),
                        ricarica.getIdRicarica(),
                        calcolaPrezzoRicarica(ricarica.getKilowattRicaricati(), ricarica.getPrezzoRicarica()),
                        LocalDate.now(),
                        RICARICA,
                        ServizioUtenti.getTipoUtente(ricarica.getIdUtente())));
            }
        } catch (DaoException e) {
            return false;
        }

        return true;
    }

    public static boolean effettuaPagamento(Sosta sosta) {
        try {
            PagamentiDao.addPagamento(new Pagamento(-1,
                    sosta.getIdUtente(),
                    sosta.getIdSosta(),
                    calcolaPrezzo(sosta.getTempoInizio(), sosta.getTempoFine(), sosta.getPrezzoOrario()),
                    LocalDate.now(),
                    SOSTA,
                    ServizioUtenti.getTipoUtente(sosta.getIdUtente())));

            List<Ricarica> ricariche = null;

            try {
                ricariche = RicaricheDao.getRicaricheBySosta(sosta.getIdSosta());
            } catch (DaoException e) {
                halt(500);
            }

            for (Ricarica ricarica : ricariche) {
                PagamentiDao.addPagamento(new Pagamento(-1,
                        ricarica.getIdUtente(),
                        ricarica.getIdRicarica(),
                        calcolaPrezzoRicarica(ricarica.getKilowattRicaricati(), ricarica.getPrezzoRicarica()),
                        LocalDate.now(),
                        RICARICA,
                        ServizioUtenti.getTipoUtente(ricarica.getIdUtente())));
            }
        } catch (DaoException e) {
            return false;
        }

        return true;
    }

    public static boolean effettuaPagamento(Abbonamento abbonamento) {
        try {
            PagamentiDao.addPagamento(new Pagamento(-1,
                    abbonamento.getIdUtente(),
                    abbonamento.getIdAbbonamento(),
                    ServizioAbbonamenti.COSTO_ABBONAMENTO,
                    abbonamento.getData(),
                    ABBONAMENTO,
                    ServizioUtenti.getTipoUtente(abbonamento.getIdUtente())));
        } catch (DaoException e) {
            return false;
        }

        return true;
    }

    private static float calcolaPrezzo(LocalDateTime tempoInizio, LocalDateTime tempoFine, float prezzoOrario) {
        Duration durata = Duration.between(tempoInizio, tempoFine);

        long minutiSosta = durata.toMinutes();

        return ((float) minutiSosta / 60) * prezzoOrario;
    }

    private static float calcolaPrezzoRicarica(float kilowatt, float prezzo) {
        return kilowatt * prezzo;
    }

    public static Object getPagamenti(Request request, Response response) {
        List<Pagamento> pagamenti = null;

        if (request.queryMap().hasKey("tipoPagamento")) {
            return getPagamentiByTipo(request, response);
        }

        if (request.queryMap().hasKey("tipoUtente")) {
            return getPagamentiByTipoUtente(request, response);
        }

        try {
            pagamenti = PagamentiDao.getAll();
        } catch (DaoException e) {
            halt(500);
        }

        LocalDate tempoInizio = null;

        if (request.queryMap().hasKey("tempoInizio")) {
            try {
                tempoInizio = LocalDate.parse(request.queryMap("tempoInizio").value());
            } catch (DateTimeParseException e) {
                halt(422, "Data inizio non valida");
            }
        }

        LocalDate tempoFine = null;

        if (request.queryMap().hasKey("tempoFine")) {
            try {
                tempoFine = LocalDate.parse(request.queryMap("tempoFine").value());
            } catch (DateTimeParseException e) {
                halt(422, "Data fine non valida");
            }
        }

        if (tempoInizio != null && tempoFine != null) {
            pagamenti = filterPagamentiByData(pagamenti, tempoInizio, tempoFine);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(pagamenti);
    }

    private static Object getPagamentiByTipoUtente(Request request, Response response) {
        int tipoUtente = -1;

        try {
            tipoUtente = Integer.parseInt(request.queryMap("tipoUtente").value());
        } catch (NumberFormatException e) {
            halt(422, "tipo utente non valido");
        }

        List<Pagamento> pagamenti = null;

        try {
            pagamenti = PagamentiDao.getAllByTipoUtente(tipoUtente);
        } catch (DaoException e) {
            halt(500);
        }

        LocalDate tempoInizio = null;

        if (request.queryMap().hasKey("tempoInizio")) {
            try {
                tempoInizio = LocalDate.parse(request.queryMap("tempoInizio").value());
            } catch (DateTimeParseException e) {
                halt(422, "Data inizio non valida");
            }
        }

        LocalDate tempoFine = null;

        if (request.queryMap().hasKey("tempoFine")) {
            try {
                tempoFine = LocalDate.parse(request.queryMap("tempoFine").value());
            } catch (DateTimeParseException e) {
                halt(422, "Data fine non valida");
            }
        }

        if (tempoInizio != null && tempoFine != null) {
            pagamenti = filterPagamentiByData(pagamenti, tempoInizio, tempoFine);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(pagamenti);
    }

    private static Object getPagamentiByTipo(Request request, Response response) {
        int tipoPagamento = -1;

        try {
            tipoPagamento = Integer.parseInt(request.queryMap("tipoPagamento").value());
        } catch (NumberFormatException e) {
            halt(400, "tipo pagamento non valido");
        }

        int tipoUtente = -1;

        if (request.queryMap().hasKey("tipoUtente")) {
            try {
                tipoUtente = Integer.parseInt(request.queryMap("tipoUtente").value());
            } catch (NumberFormatException e) {
                halt(422, "tipo utente non valido");
            }
        }

        List<Pagamento> pagamenti = null;

        try {
            if (tipoUtente != -1) {
                pagamenti = PagamentiDao.getAllByTipoAndTipoUtente(tipoPagamento, tipoUtente);
            } else {
                pagamenti = PagamentiDao.getAllByTipo(tipoPagamento);
            }
        } catch (DaoException e) {
            halt(500);
        }

        LocalDate tempoInizio = null;

        if (request.queryMap().hasKey("tempoInizio")) {
            try {
                tempoInizio = LocalDate.parse(request.queryMap("tempoInizio").value());
            } catch (DateTimeParseException e) {
                halt(422, "Data inizio non valida");
            }
        }

        LocalDate tempoFine = null;

        if (request.queryMap().hasKey("tempoFine")) {
            try {
                tempoFine = LocalDate.parse(request.queryMap("tempoFine").value());
            } catch (DateTimeParseException e) {
                halt(422, "Data fine non valida");
            }
        }

        if (tempoInizio != null && tempoFine != null) {
            pagamenti = filterPagamentiByData(pagamenti, tempoInizio, tempoFine);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(pagamenti);
    }

    private static List<Pagamento> filterPagamentiByData(List<Pagamento> pagamenti, LocalDate tempoInizio, LocalDate tempoFine) {
        List<Pagamento> res = new ArrayList<>();

        if (tempoInizio != null && tempoFine != null) {
            res = pagamenti.stream().filter(pagamento -> (pagamento.getData().isAfter(tempoInizio) || pagamento.getData().isEqual(tempoInizio))
                    && (pagamento.getData().isBefore(tempoFine) || pagamento.getData().isEqual(tempoFine))).toList();
        }
        if (tempoInizio == null && tempoFine != null) {
            res = pagamenti.stream().filter(pagamento -> pagamento.getData().isBefore(tempoFine) || pagamento.getData().isEqual(tempoFine)).toList();
        }
        if (tempoInizio != null) {
            res = pagamenti.stream().filter(pagamento -> pagamento.getData().isAfter(tempoInizio) || pagamento.getData().isEqual(tempoInizio)).toList();
        }

        return res;
    }
}
