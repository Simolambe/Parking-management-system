package services;

import spark.QueryParamsMap;
import spark.Request;
import spark.Response;
import dao.DaoException;
import dao.SosteDao;
import dao.UtenteDao;
import models.MetodoPagamento;
import models.Prenotazione;
import models.Sosta;
import models.Utente;

import java.time.LocalDateTime;
import java.util.List;

import static spark.Spark.halt;

import static server.Server.GSON;

public class ServizioSoste {
    public static final int IN_CORSO = 0;
    public static final int PASSATA = 1;

    public static Object getSoste(Request request, Response response) {
        QueryParamsMap queryParamsMap = request.queryMap();
        if (request.queryMap().hasKey("idUtente")) {
            return getSosteUtente(request, response);
        }

        List<Sosta> soste = null;

        if (request.queryMap().hasKey("corrente")) {
            boolean corrente = Boolean.parseBoolean(request.queryMap("corrente").value());

            try {
                soste = SosteDao.getSosteByStato(corrente);
            } catch (DaoException e) {
                halt(500);
            }
        }
        else {
            try {
                soste = SosteDao.getSoste();
            } catch (DaoException e) {
                halt(500);
            }
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(soste);
    }

    private static Object getSosteUtente(Request request, Response response) {
        int idUtente = -1;

        try {
            String id = request.queryMap("idUtente").value();
            idUtente = Integer.parseInt(request.queryMap("idUtente").value());
        } catch (NumberFormatException e) {
            halt(400, "idUtente non valido");
        }

        List<Sosta> soste = null;

        if (request.queryMap().hasKey("corrente")) {
            boolean corrente = Boolean.parseBoolean(request.queryMap("corrente").value());

            try {
                soste = SosteDao.getSosteUtenteByStato(idUtente, corrente);
            } catch (DaoException e) {
                halt(500);
            }
        }
        else {
            try {
                soste = SosteDao.getSosteUtente(idUtente);
            } catch (DaoException e) {
                halt(500);
            }
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(soste);
    }

    public static int avviaSosta(String targa, int idParcheggio) {
        Utente utente = null;

        try {
            utente = UtenteDao.getUtenteByTarga(targa);
        } catch (DaoException e) {
            return 4;
        }

        if (utente == null) return 1;

        Sosta sosta = null;

        try {
            sosta = SosteDao.getSostaByTarga(targa);
        } catch (DaoException e) {
            return 4;
        }

        if (sosta != null && sosta.getStato() == IN_CORSO) return 2;

        MetodoPagamento metodoPagamento = null;

        try {
            metodoPagamento = UtenteDao.getMetodoPagamento(utente.getId());
        } catch (DaoException e) {
            return 4;
        }

        if (metodoPagamento == null) {
            return 3;
        }

        Prenotazione prenotazione = null;

        try {
            prenotazione = ServizioPrenotazioni.getFirstValida(utente.getId(), idParcheggio);
        } catch (DaoException e) {
            return 4;
        }

        if (prenotazione != null) {
            sosta = new Sosta(-1,
                    utente.getId(),
                    prenotazione.getIdPrenotazione(),
                    idParcheggio,
                    LocalDateTime.now().withNano(0),
                    null,
                    ServizioParcheggio.getPrezzoSosta(idParcheggio),
                    IN_CORSO,
                    targa);
        } else {
            sosta = new Sosta(-1,
                    utente.getId(),
                    0,
                    idParcheggio,
                    LocalDateTime.now().withNano(0),
                    null,
                    ServizioParcheggio.getPrezzoSosta(idParcheggio),
                    IN_CORSO,
                    targa);
        }

        try {
            sosta.setIdSosta(SosteDao.addSosta(sosta));
        } catch (DaoException e) {
            return 4;
        }

        return 0;
    }

    public static int terminaSosta(String targa, int idParcheggio) {
        Utente utente = null;

        try {
            utente = UtenteDao.getUtenteByTarga(targa);
        } catch (DaoException e) {
            return 4;
        }

        if (utente == null) return 1;

        Sosta sosta = null;

        try {
            sosta = SosteDao.getSostaByTarga(targa);
        } catch (DaoException e) {
            return 4;
        }

        if (sosta == null || sosta.getStato() != ServizioSoste.IN_CORSO) return 2;

        MetodoPagamento metodoPagamento = null;

        try {
            metodoPagamento = UtenteDao.getMetodoPagamento(utente.getId());
        } catch (DaoException e) {
            return 4;
        }

        if (metodoPagamento == null) {
            return 3;
        }

        Prenotazione prenotazione = null;

        if (sosta.getIdPrenotazione() > 0) {
            prenotazione = ServizioPrenotazioni.getPrenotazioneById(sosta.getIdPrenotazione());
        }

        LocalDateTime tempoFine = LocalDateTime.now().withNano(0);

        boolean res;

        if (prenotazione != null && prenotazione.getTempoFine().isAfter(tempoFine)) {
            res = ServizioPagamenti.effettuaPagamento(sosta, prenotazione.getTempoFine());
        } else {
            sosta.setTempoFine(LocalDateTime.now().withNano(0));
            res = ServizioPagamenti.effettuaPagamento(sosta);
        }

        if (!res) {
            return 5;
        }

        try {
            SosteDao.terminaSosta(sosta);
        } catch (DaoException e) {
            return 4;
        }

        return 0;
    }
}
