package services;

import models.Utente;
import spark.Request;
import spark.Response;
import dao.AbbonamentiDao;
import dao.DaoException;
import dao.UtenteDao;
import models.Abbonamento;
import models.MetodoPagamento;
import utils.Config;

import java.time.LocalDate;

import static server.Server.GSON;
import static spark.Spark.halt;

public class ServizioAbbonamenti {
    public static final float COSTO_ABBONAMENTO;

    static {
        Config config = Config.getInstance();
        COSTO_ABBONAMENTO = config.getCostoAbbonamento();
    }

    public static Object addAbbonamento(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.queryMap("idUtente").value());
        } catch (NumberFormatException e) {
            halt(422, "id utente non valido");
        }

        MetodoPagamento metodoPagamento = null;

        try {
            metodoPagamento = UtenteDao.getMetodoPagamento(idUtente);
        } catch (DaoException e) {
            halt(500);
        }

        if (metodoPagamento == null) halt(400, "inserire un metodo di pagamento");

        int idAbbonamento = -1;

        Abbonamento abbonamento = new Abbonamento(idAbbonamento,
                idUtente,
                COSTO_ABBONAMENTO,
                LocalDate.now());

        try {
            abbonamento.setIdAbbonamento(AbbonamentiDao.add(abbonamento));
        } catch (DaoException e) {
            halt(500);
        }

        boolean res = ServizioPagamenti.effettuaPagamento(abbonamento);

        if (!res) {
            halt(500, "impossibile effettuare il pagamento");
        }

        try {
            UtenteDao.upgradeToPremium(idUtente);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }


    public static Object getCostoAbbonamento(Request request, Response response) {
        response.type("application/json");
        response.status(200);
        return GSON.toJson(COSTO_ABBONAMENTO);
    }
}
