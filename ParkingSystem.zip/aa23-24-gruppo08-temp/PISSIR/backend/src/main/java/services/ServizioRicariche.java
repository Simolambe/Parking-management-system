package services;

import dao.*;
import org.eclipse.paho.client.mqttv3.MqttException;
import spark.Request;
import spark.Response;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static spark.Spark.halt;
import static server.Server.*;

import models.*;
import utils.Config;

public class ServizioRicariche {
    public static final int IN_CORSO = 0;
    public static final int IN_CODA = 1;
    public static final int EROGATA = 2;
    public static final int CANCELLATA = 3;

    private static final String TOPIC_CODA_RIC_ADD;
    private static final String TOPIC_RIC_CANC;
    private static final String TOPIC_RIC_INT;

    static {
        Config config = Config.getInstance();

        TOPIC_CODA_RIC_ADD = config.getTopicCodaRicAdd();
        TOPIC_RIC_CANC = config.getTopicRicCanc();
        TOPIC_RIC_INT = config.getTopicRicInt();
    }

    public static Object getRicariche(Request request, Response response) {
        if (request.queryMap().hasKey("idUtente")) {
            return getRicaricheUtente(request, response);
        }

        List<Ricarica> ricariche = new ArrayList<>();

        try {
            if (request.queryMap().hasKey("stato")) {
                ricariche = RicaricheDao.getRicaricheByStato(Integer.parseInt(request.queryMap("stato").value()));
            }
            else {
                ricariche = RicaricheDao.getRicariche();
            }
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(ricariche);
    }

    private static Object getRicaricheUtente(Request request, Response response) {
        List<Ricarica> ricariche = new ArrayList<>();
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.queryMap("idUtente").value());
        } catch (NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        try {
            if (request.queryMap().hasKey("stato")) {
                ricariche = RicaricheDao.getRicaricheUtenteByStato(idUtente, Integer.parseInt(request.queryMap("stato").value()));
            }
            else {
                ricariche = RicaricheDao.getRicaricheUtente(idUtente);
            }
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(ricariche);
    }

    public static Object getAttesa(Request request, Response response) {
        int idParcheggio = -1;

        try {
            idParcheggio = Integer.parseInt(request.queryMap("idParcheggio").value());
        } catch (NumberFormatException e) {
            halt(400, "id parcheggio non valido");
        }

        int attesa = 0;

        try {
            attesa = RicaricheDao.getRicaricheInCoda(idParcheggio).size(); // + (RicaricheDao.getRicaricaInCorso(idParcheggio) == null ? 0 : 1);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);
        response.type("application/json");

        return attesa;
    }

    public static Object addRicarica(Request request, Response response) {
        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null) halt(400, "inserire una ricarica");

        int idSosta = -1;
        int idUtente = -1;
        int percentualeRichiesta = -1;
        boolean notifica = false;
        int numeroPosto = -1;

        try {
            idUtente = ((Double) body.get("idUtente")).intValue();
        } catch (NumberFormatException e) {
            halt(422, "id utente non valido");
        }

        try {
            percentualeRichiesta = ((Double) body.get("percentualeRichiesta")).intValue();
        } catch (NumberFormatException e) {
            halt(422, "percentuale non valida");
        }

        try {
            idSosta = ((Double) body.get("idSosta")).intValue();
        } catch (NumberFormatException e) {
            halt(422, "id sosta non valido");
        }

        Sosta sosta = null;

        try {
            sosta = SosteDao.getSostaById(idSosta);
        } catch (DaoException e) {
            halt(500);
        }

        if (sosta == null || sosta.getStato() != IN_CORSO) halt(422, "sosta non valida");

        if (percentualeRichiesta < 0 || percentualeRichiesta > 100) halt(422, "percentuale non valida");

        Ricarica ricarica = null;

        try {
            ricarica = RicaricheDao.getRicaricheBySosta(idSosta)
                    .stream()
                    .filter(r -> r.getStato() == IN_CORSO)
                    .findFirst()
                    .orElse(null);
        } catch (DaoException e) {
            halt(500);
        }

        if (ricarica != null) halt(400, "hai già una ricarica in corso per la sosta indicata");

        if (body.get("numeroPosto") == null) {
            try {
                Prenotazione prenotazione = PrenotazioniDao.getById(sosta.getIdPrenotazione());
                if (prenotazione == null) halt(400, "inserire il numero del posto");
                numeroPosto = prenotazione.getNumeroPosto();
            } catch(DaoException e) {
                halt(500);
            }
        }
        else {
            try {
                numeroPosto = ((Double) body.get("numeroPosto")).intValue();
            } catch (NumberFormatException e) {
                halt(422, "numero posto non valido");
            }
        }

        notifica = (Boolean) body.get("notifica");

        /* PostoAuto postoAuto = null;

        try {
            postoAuto = ParcheggioDao.getPostoAutoById(sosta.getIdParcheggio(), numeroPosto);
        } catch (DaoException e) {
            halt(500);
        }

        if (postoAuto.getStato() != ServizioParcheggio.POSTO_OCCUPATO) halt(422, "Posto non valido"); */

        ricarica = new Ricarica(-1,
                idSosta,
                sosta.getIdParcheggio(),
                idUtente,
                percentualeRichiesta,
                0,
                notifica,
                0.0f,
                IN_CODA,
                numeroPosto,
                0,
                ServizioParcheggio.getPrezzoRicarica(sosta.getIdParcheggio()));

        try {
            ricarica.setIdRicarica(RicaricheDao.addRicaria(ricarica));
        } catch (DaoException e) {
            halt(500);
        }

        try {
            clientMap.get(ricarica.getIdParcheggio()).publish(TOPIC_CODA_RIC_ADD,
                    (ricarica.getIdParcheggio()
                            + "," + ricarica.getIdRicarica()
                            + "," + ricarica.getPercentualeRichiesta()
                            + "," + ricarica.getNumeroPosto()).getBytes(), 1, false);
        } catch (MqttException e) {
            halt(500);
        }

        response.cookie("Location", API_ROOT + API_VERSION + "/ricariche/" + ricarica.getIdRicarica());
        response.status(201);

        return "";
    }


    public static Object cancellaRicarica(Request request, Response response) {
        int idUtente = -1;

        if (request.queryMap().hasKey("idUtente")) {
            try {
                idUtente = Integer.parseInt(request.queryMap("idUtente").value());
            } catch (NumberFormatException e) {
                halt(422, "id utente non valido");
            }
        } else {
            halt(400, "inserire id utente");
        }

        int idRicarica = -1;

        try {
            idRicarica = Integer.parseInt(request.params("idRicarica"));
        } catch (NumberFormatException e) {
            halt(400, "id ricarica non valido");
        }

        Ricarica ricarica = null;

        try {
            ricarica = RicaricheDao.getRicaricaById(idRicarica);
        } catch (DaoException e) {
            halt(500);
        }

        if (ricarica == null) halt(422, "id ricarica non trovato");

        if (ricarica.getIdUtente() != idUtente) halt(422, "id utente non valido");

        if (ricarica.getStato() != IN_CODA) halt(422, "ricarica non cancellabile");

        try {
            clientMap.get(ricarica.getIdParcheggio()).publish(TOPIC_RIC_CANC, (ricarica.getIdParcheggio() + "," + ricarica.getIdRicarica()).getBytes(), 1, false);
        } catch (MqttException e) {
            halt(500);
        }

        try {
            RicaricheDao.cancellaRicarica(idRicarica, CANCELLATA);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static Object interrompiRicarica(Request request, Response response) {
        int idUtente = -1;

        if (request.queryMap().hasKey("idUtente")) {
            try {
                idUtente = Integer.parseInt(request.queryMap("idUtente").value());
            } catch (NumberFormatException e) {
                halt(422, "idUtente non valido");
            }
        } else {
            halt(400, "inserire id utente");
        }

        int idRicarica = -1;

        try {
            idRicarica = Integer.parseInt(request.params("idRicarica"));
        } catch (NumberFormatException e) {
            halt(400, "id ricarica non valido");
        }

        Ricarica ricarica = null;

        try {
            ricarica = RicaricheDao.getRicaricaById(idRicarica);
        } catch (DaoException e) {
            halt(500);
        }

        if (ricarica == null) halt(422, "id ricarica non trovato");

        if (ricarica.getStato() != IN_CORSO) halt(422, "impossibile interrompere ricarica");

        if (ricarica.getIdUtente() != idUtente) halt(422, "id utente non valido");

        try {
            clientMap.get(ricarica.getIdParcheggio()).publish(TOPIC_RIC_INT, (ricarica.getIdParcheggio() + "," + ricarica.getIdRicarica()).getBytes(), 1, false);
        } catch (MqttException e) {
            halt(500);
        }

        try {
            RicaricheDao.cancellaRicarica(idRicarica, EROGATA);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static void aggiornaRicarica(int idRicarica, int percentualeAttuale, float kilowattRicaricati, int potenzaKilowatt, int stato) {
        try {
            RicaricheDao.cambiaStato(idRicarica, percentualeAttuale, kilowattRicaricati, potenzaKilowatt, stato);
        } catch (DaoException e) {
            e.printStackTrace();
        }
    }

    public static void terminaRicarica(int idRicarica, int percentualeAttuale, float kilowattRicaricati, int stato) {
        try {
            RicaricheDao.terminaRicarica(idRicarica, percentualeAttuale, kilowattRicaricati, stato);
        } catch (DaoException e) {
            e.printStackTrace();
        }
    }

    public static Ricarica getRicaricaById(int idRicarica) {
        Ricarica ricarica = null;

        try {
            ricarica = RicaricheDao.getRicaricaById(idRicarica);
        } catch (DaoException e) {
            e.printStackTrace();
        }

        return ricarica;
    }
}
