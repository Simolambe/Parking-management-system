package services;

import spark.Request;
import spark.Response;

import java.util.List;
import java.util.Map;

import models.MetodoPagamento;
import models.Utente;
import dao.UtenteDao;
import dao.DaoException;
import models.Veicolo;

import static spark.Spark.halt;
import static server.Server.*;

public class ServizioUtenti {

    public static final int UTENTE_BASE = 0;
    public static final int UTENTE_PREMIUM = 1;
    public static final int UTENTE_AMMINISTRATORE = 2;

    public static Object getUtenti(Request request, Response response) {
        if (request.queryMap().hasKey("email")) return getUtenteByEmail(request, response);

        List<Utente> utenti = null;

        try {
            utenti = UtenteDao.getAll();
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(utenti);
    }

    static Object getUtenteByEmail(Request request, Response response) {
        String email = request.queryMap("email").value();

        Utente utente = null;

        try {
            utente = UtenteDao.getUtenteByEmail(email);
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(utente);
    }

    public static Object addUtente(Request request, Response response) {
        Map body = GSON.fromJson(request.body(), Map.class);

        if(body == null || body.isEmpty()) halt(400);

        String nome = (String) body.get("nome");
        String cognome = (String) body.get("cognome");
        String email = (String) body.get("email");
        String password = (String) body.get("password");

        if (!checkNome(nome)) halt(422, "nome non valido");
        if (!checkCognome(cognome)) halt(422, "cognome non valido");
        if (!checkPassword(password)) halt(422, "password non valida");

        try {
            if (!checkEmail(email)) halt(422, "email non valida o già in uso");
        } catch (DaoException e) {
            halt(500);
        }

        Utente utente = new Utente(-1, nome, cognome, email, password, ServizioUtenti.UTENTE_BASE, null);

        try {
            utente.setId(UtenteDao.addUser(utente));
        } catch (DaoException e) {
            halt(500);
        }

        response.header("Location", API_ROOT + API_VERSION + "/utenti/" + utente.getId());
        response.status(201);

        return "";
    }

    public static Object updateEmail(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null || body.isEmpty()) halt(400);

        String email = (String) body.get("email");

        try {
            if (!checkEmail(email)) halt(422, "email non valida o già in uso");
        } catch (DaoException e) {
            halt(500);
        }

        try {
            UtenteDao.updateEmail(idUtente, email);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static Object updatePassword(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non inserito o non valido");
        }

        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null || body.isEmpty()) halt(400);

        String password = (String) body.get("password");

        if (!checkPassword(password)) halt(422, "password non valida");

        try {
            UtenteDao.updatePassword(idUtente, password);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static Object deleteUtente(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non inserito non valido");
        }

        try {
            List<Veicolo> veicoli = UtenteDao.getVeicoli(idUtente);
            for (Veicolo veicolo : veicoli) {
                UtenteDao.deleteVeicolo(veicolo.getTarga());
            }
            UtenteDao.deleteMetodoPagamento(idUtente);
            UtenteDao.deleteUser(idUtente);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static Object addMetodoPagamento(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non inserito o non valido");
        }

        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null || body.isEmpty()) halt(400);

        String numeroCarta = (String) body.get("numeroCarta");
        String annoScadenza = (String) body.get("annoScadenza");
        String meseScadenza = (String) body.get("meseScadenza");
        String cvv = (String) body.get("cvv");
        String tipoCarta = (String) body.get("tipoCarta");
        String titolare = (String) body.get("titolare");

        if (!numeroCarta.matches("\\d{16}")) halt(422, "numero carta non valido");
        if (!annoScadenza.matches("\\d{2}")) halt(422, "anno scadenza non valido");
        if (!meseScadenza.matches("\\d{2}")) halt(422, "mese scadenza non valido");
        if (!cvv.matches("\\d{3}")) halt(422, "cvv non valido");
        if (titolare == null || titolare.isEmpty()) halt(422, "titolare non valido");

        MetodoPagamento metodoPagamento = new MetodoPagamento(idUtente,
                numeroCarta,
                meseScadenza,
                annoScadenza,
                cvv,
                tipoCarta,
                titolare);

        try {
            UtenteDao.addPaymentMethod(metodoPagamento);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }


    public static Object getMetodoPagamento(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non inserito o non valido");
        }

        MetodoPagamento metodoPagamento = null;

        try {
            metodoPagamento = UtenteDao.getMetodoPagamento(idUtente);
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(metodoPagamento);
    }

    public static Object deleteMetodoPagamento(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        MetodoPagamento metodoPagamento = null;

        try {
            metodoPagamento = UtenteDao.getMetodoPagamento(idUtente);
        } catch (DaoException e) {
            halt(500);
        }

        if (metodoPagamento == null) {
            halt(400, "nessun metodo di pagamento trovato");
        }

        try {
            UtenteDao.deleteMetodoPagamento(idUtente);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static Object addVeicolo(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null || body.isEmpty()) halt(400);

        String targa = (String) body.get("targa");

        if (!checkTarga(targa)) halt(422, "targa non valida");

        Veicolo veicolo = new Veicolo(idUtente, targa);

        try {
            UtenteDao.addVeicolo(veicolo);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static Object getVeicoli(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        List<Veicolo> veicoli = null;

        try {
            veicoli = UtenteDao.getVeicoli(idUtente);
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(veicoli);
    }

    public static Object deleteVeicolo(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        String targa = request.params("targa");

        if (!checkTarga(targa)) halt(422, "targa non valida");

        List<Veicolo> veicoli = null;

        try {
            veicoli = UtenteDao.getVeicoli(idUtente);
        } catch (DaoException e) {
            halt(500);
        }

        Veicolo veicolo = findVeicolo(veicoli, targa);

        if (veicolo == null) halt(400, "nessun veicolo trovato");

        try {
            UtenteDao.deleteVeicolo(targa);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    private static Veicolo findVeicolo(List<Veicolo> veicoli, String targa) {
        for (Veicolo veicolo : veicoli) {
            if (veicolo.getTarga().equals(targa)) return veicolo;
        }

        return null;
    }

    private static boolean checkNome(String nome) {
        return nome != null && !nome.isEmpty();
    }

    private static boolean checkCognome(String cognome) {
        return cognome != null && !cognome.isEmpty();
    }

    private static boolean checkEmail(String email) throws DaoException {
        return email != null && email.contains("@") && (UtenteDao.findUserByEmail(email) == null);
    }

    private static boolean checkPassword(String password) {
        return password != null && password.length() >= 8;
    }

    private static boolean checkTarga(String targa) {
        return targa != null && targa.matches("[A-Z]{2}\\d{3}[A-Z]{2}");
    }

    public static int getTipoUtente(int idUtente) throws DaoException {
        Utente utente = UtenteDao.getById(idUtente);
        return utente.getTipo();
    }

    public static Object updateNome(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null || body.isEmpty()) halt(400);

        String nome = (String) body.get("nome");

        if (!checkNome(nome)) halt(422, "nome non valido");

        try {
            UtenteDao.updateNome(idUtente, nome);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static Object updateCognome(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non inserito non valido");
        }

        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null || body.isEmpty()) halt(400);

        String cognome = (String) body.get("cognome");

        if (!checkCognome(cognome)) halt(422, "cognome non valido");

        try {
            UtenteDao.updateCognome(idUtente, cognome);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    public static Object upadateImmagine(Request request, Response response) {
        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.params("idUtente"));
        } catch (NullPointerException | NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null || body.isEmpty()) halt(400);

        String immagine = (String) body.get("immagine");

        if (immagine == null) halt(422, "immagine non valida");

        try {
            UtenteDao.updateImmagine(idUtente, immagine);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }
}
