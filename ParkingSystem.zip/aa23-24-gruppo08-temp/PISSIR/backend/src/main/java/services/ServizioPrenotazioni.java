package services;

import spark.Request;
import spark.Response;
import dao.DaoException;
import dao.ParcheggioDao;
import  dao.PrenotazioniDao;
import models.PostoAuto;
import models.Prenotazione;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import static spark.Spark.halt;
import static server.Server.*;
import static utils.CustomDateTimeFormatter.CUSTOM_DATE_TIME_FORMATTER;

public class ServizioPrenotazioni {

    public static final int VALIDA = 0;
    public static final int UTILIZZATA = 1;
    public static final int SCADUTA = 2;
    public static final int CANCELLATA = 3;

    public static Object getPrenotazioni(Request request, Response response) {
        List<Prenotazione> prenotazioni = new ArrayList<>();

        if (request.queryMap().hasKey("tipoUtente")
                && Integer.parseInt(request.queryMap("tipoUtente").value()) == ServizioUtenti.UTENTE_AMMINISTRATORE) {
            return getPrenotazioniAdmin(request, response);
        }

        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.queryMap("idUtente").value());
        } catch (NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        if (request.queryMap().hasKey("stato")) {
            int stato = Integer.parseInt(request.queryMap("stato").value());
            try {
                if (stato == VALIDA) prenotazioni = PrenotazioniDao.getPrenotazioniValide(idUtente);
                else prenotazioni = PrenotazioniDao.getPrenotazioniPassate(idUtente);
            } catch (DaoException e) {
                halt(500);
            }
        } else {
            try {
                prenotazioni = PrenotazioniDao.getPrenotazioni(idUtente);
            } catch (DaoException e) {
                halt(500);
            }
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(prenotazioni);
    }

    private static Object getPrenotazioniAdmin(Request request, Response response) {
        if (request.queryMap().hasKey("numeroPosto")) {
            return getPrenotazioniByNumeroPosto(request, response);
        }

        List<Prenotazione> prenotazioneList = null;

        try {
            prenotazioneList = PrenotazioniDao.getAll();
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(prenotazioneList);
    }

    private static Object getPrenotazioniByNumeroPosto(Request request, Response response) {
        int numeroPosto = -1;

        try {
            numeroPosto = Integer.parseInt(request.queryMap("numeroPosto").value());
        } catch (NumberFormatException e) {
            halt(422, "numero posto non valido");
        }

        List<Prenotazione> prenotazioni = null;

        try {
            prenotazioni = PrenotazioniDao.getByNumeroPosto(numeroPosto);
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(prenotazioni);
    }

    public static Object addPrenotazione(Request request, Response response) {
        Map body = GSON.fromJson(request.body(), Map.class);
        
        if (body == null) halt(400, "inserire una prenotazione");

        int idUtente = -1;

        try {
            idUtente = ((Double) body.get("idUtente")).intValue();
        } catch (NumberFormatException e) {
            halt(400, "id utente non valido");
        }

        int idParcheggio = -1;

        try {
            idParcheggio = ((Double) body.get("idParcheggio")).intValue();
        } catch (NumberFormatException e) {
            halt(422, "id parcheggio non valido");
        }
        
        LocalDateTime tempoInizio = null;
        LocalDateTime tempoFine = null;
        
        try {
            tempoInizio = LocalDateTime.parse((String) body.get("tempoInizio"), CUSTOM_DATE_TIME_FORMATTER);
        } catch (DateTimeParseException e) {
            halt(422, "tempo inizio non valido");
        }

        try {
            tempoFine = LocalDateTime.parse((String) body.get("tempoFine"), CUSTOM_DATE_TIME_FORMATTER);
        } catch (DateTimeParseException | NullPointerException e) {
            halt(422, "tempo fine non valido");
        }

        if (!tempoInizio.isAfter(LocalDateTime.now())) halt(422, "tempo inizio non valido");
        
        if (!tempoFine.isAfter(tempoInizio)) halt(422, "tempo fine non valido");

        try {
            if (!checkPrenotazioneUtente(idUtente, tempoInizio, tempoFine, idParcheggio)) halt(422, "hai già una prenotazione nell'orario indicato");
        } catch (DaoException e) {
            halt(500);
        }

        int numeroPosto = -1;

        try {
            numeroPosto = getPosto(tempoInizio, tempoFine, idParcheggio);
        } catch (DaoException e) {
            halt(500);
        }

        if (numeroPosto == -1) halt(400, "nessun posto libero nell'orario indicato");

        Prenotazione prenotazione = new Prenotazione(-1, idUtente, idParcheggio, tempoInizio, tempoFine, VALIDA, numeroPosto);

        try {
            prenotazione.setIdPrenotazione(PrenotazioniDao.addPrenotazione(prenotazione));
            PostoAuto postoAuto = ParcheggioDao.getPostoAutoById(idParcheggio, numeroPosto);
            ParcheggioDao.aggiornaPrenotazioniPosto(idParcheggio, numeroPosto, postoAuto.getNumeroPrenotazioni()+1);
        } catch (DaoException e) {
            halt(500);
        }

        response.header("Location", API_ROOT + API_VERSION + "/prenotazioni/" + prenotazione.getIdPrenotazione());
        response.status(201);

        return "";
    }

    public static Object cancellaPrenotazione(Request request, Response response) {
        int idPrenotazione = -1;

        try {
            idPrenotazione = Integer.parseInt(request.params("idPrenotazione"));
        } catch (NumberFormatException e) {
            halt(422, "id prenotazione non valido");
        }

        int idUtente = -1;

        try {
            idUtente = Integer.parseInt(request.queryMap("idUtente").value());
        } catch (NumberFormatException e) {
            halt(422, "id utente non valido");
        }

        if (idUtente == -1) halt(400, "inserire id utente");

        Prenotazione prenotazione = null;

        try {
            prenotazione = PrenotazioniDao.getById(idPrenotazione);
        } catch (DaoException e) {
            halt(500);
        }

        if (prenotazione == null) halt(422, "id prenotazione non trovato");

        if (prenotazione.getIdUtente() != idUtente) halt(422, "id utente non valido");

        if (prenotazione.getStato() != VALIDA) halt(422, "prenotazione non cancellabile");

        try {
            PrenotazioniDao.cambiaStato(idPrenotazione, CANCELLATA);
            PostoAuto postoAuto = ParcheggioDao.getPostoAutoById(prenotazione.getIdParcheggio(), prenotazione.getNumeroPosto());
            ParcheggioDao.aggiornaPrenotazioniPosto(prenotazione.getIdParcheggio(), prenotazione.getNumeroPosto(), postoAuto.getNumeroPrenotazioni()-1);
        } catch (DaoException e) {
            halt(500);
        }

        response.status(200);

        return "";
    }

    private static boolean checkPrenotazioneUtente(int idUtente, LocalDateTime tempoInizio, LocalDateTime tempoFine, int idParcheggio) throws DaoException {
        List<Prenotazione> prenotazioni = PrenotazioniDao.getPrenotazioni(idUtente, idParcheggio);

        boolean flag = true;

        for (Prenotazione prenotazione : prenotazioni) {
            if (tempoInizio.isBefore(prenotazione.getTempoFine()) && prenotazione.getTempoInizio().isBefore(tempoFine)) {
                flag = false;
                break;
            }
        }

        return flag;
    }

    private static int getPosto(LocalDateTime tempoInizio, LocalDateTime tempoFine, int idParcheggio) throws DaoException {
        List<PostoAuto> postiAuto = ParcheggioDao.getPostiAutoPremium(idParcheggio);

        for (PostoAuto posto : postiAuto) {
            List<Prenotazione> prenotazioni = PrenotazioniDao.getByPostoAuto(posto.getNumeroPosto());

            if (prenotazioni.isEmpty()) return posto.getNumeroPosto();

            boolean flag = true;

            for (Prenotazione prenotazione : prenotazioni) {
                if (tempoInizio.isBefore(prenotazione.getTempoFine()) && prenotazione.getTempoInizio().isBefore(tempoFine)) {
                    flag = false;
                    break;
                }
            }

            if (flag) return posto.getNumeroPosto();
        }

        return -1;
    }

    public static Prenotazione getFirstValida(int idUtente, int idParcheggio) throws DaoException {
        List<Prenotazione> prenotazioni = null;

        prenotazioni = PrenotazioniDao.getPrenotazioni(idUtente, idParcheggio);

        prenotazioni.sort(new Comparator<Prenotazione>() {
            @Override
            public int compare(Prenotazione o1, Prenotazione o2) {
                return o1.getTempoInizio().compareTo(o2.getTempoFine());
            }
        });

        for (Prenotazione prenotazione : prenotazioni) {
            if (isValid(prenotazione)) return prenotazione;
        }

        return null;
    }

    private static boolean isValid(Prenotazione prenotazione) {
        LocalDateTime now = LocalDateTime.now();
        return !prenotazione.getTempoInizio().isBefore(now) && !prenotazione.getTempoInizio().isAfter(now.plusMinutes(15));
    }

    public static Prenotazione getPrenotazioneById(int idPrenotazione) {
        Prenotazione prenotazione = null;

        try {
            PrenotazioniDao.getById(idPrenotazione);
        } catch (DaoException e) {
            return null;
        }

        return prenotazione;
    }

    public static List<Prenotazione> getPrenotazioniByParcheggioInizioFine(int idParcheggio, LocalDateTime tempoInizio, LocalDateTime tempoFine) throws DaoException {
        List<Prenotazione> prenotazioni = PrenotazioniDao.getByParcheggio(idParcheggio);
        return prenotazioni.stream().filter(prenotazione -> prenotazione.getTempoInizio().isAfter(tempoInizio) && prenotazione.getTempoFine().isBefore(tempoFine)).toList();
    }
}
