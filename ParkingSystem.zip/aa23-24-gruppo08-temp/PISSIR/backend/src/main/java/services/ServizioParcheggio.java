package services;

import spark.Request;
import spark.Response;
import dao.DaoException;
import dao.ParcheggioDao;
import models.Intervallo;
import models.Parcheggio;
import models.PostoAuto;
import models.Prenotazione;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.TreeMap;

import static spark.Spark.halt;
import static server.Server.GSON;
import static utils.CustomDateTimeFormatter.CUSTOM_DATE_TIME_FORMATTER;

public class ServizioParcheggio {

    public static final int POSTO_LIBERO = 0;
    public static final int POSTO_OCCUPATO = 1;
    public static final int POSTO_PREMIUM = 1;
    public static final int POSTO_BASE = 0;


    public static Object getOccupazione(Request request, Response response) {
        List<PostoAuto> postoAutoList = null;

        int idParcheggio = -1;

        try {
            idParcheggio = Integer.parseInt(request.params("idParcheggio"));
        } catch (NumberFormatException e) {
            halt(400, "id parcheggio non valido");
        }

        try {
            postoAutoList = ParcheggioDao.getPostiAuto(idParcheggio);
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(postoAutoList);
    }

    public static float getPrezzoSosta(int idParcheggio) {
        Parcheggio parcheggio = null;

        try {
            parcheggio = ParcheggioDao.getById(idParcheggio);
        } catch (DaoException e) {
            return -1;
        }

        return parcheggio.getCostoSosta();
    }

    public static float getPrezzoRicarica(int idParcheggio) {
        Parcheggio parcheggio = null;

        try {
            parcheggio = ParcheggioDao.getById(idParcheggio);
        } catch (DaoException e) {
            return -1;
        }

        return parcheggio.getCostoRicarica();
    }

    public static Object getAll(Request request, Response response) {
        List<Parcheggio> parcheggi = null;

        try {
            parcheggi = ParcheggioDao.getAll();
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(parcheggi);
    }

    public static Object getById(Request request, Response response) {
        Parcheggio parcheggio = null;

        int idParcheggio = -1;

        try {
            idParcheggio = Integer.parseInt(request.params("idParcheggio"));
        } catch (NumberFormatException e) {
            halt(400, "id parcheggio non valido");
        }

        try {
            parcheggio = ParcheggioDao.getById(idParcheggio);
        } catch (DaoException e) {
            halt(500);
        }

        response.type("application/json");
        response.status(200);

        return GSON.toJson(parcheggio);
    }

    public static Object aggiornaCosti(Request request, Response response) {
        Map body = GSON.fromJson(request.body(), Map.class);

        if (body == null) halt(400, "inserire una costo");

        int idParcheggio = -1;

        try {
            idParcheggio = Integer.parseInt(request.params("idParcheggio"));
        } catch (NumberFormatException e) {
            halt(400, "id parcheggio non valido");
        }

        int tipo = -1;

        if (request.queryMap().hasKey("tipo")) {
            try {
                tipo = Integer.parseInt(request.queryMap("tipo").value());
            } catch (NumberFormatException e) {
                halt(422, "tipo non valido");
            }
        } else {
            halt(400, "inserire tipo");
        }

        float costo = -1;

        switch (tipo) {
            case 0:
                costo = ((Double) body.get("costoSosta")).floatValue();
                try {
                    ParcheggioDao.aggiornaCostoSosta(costo, idParcheggio);
                } catch (DaoException e) {
                    halt(500);
                }
                break;
            case 1:
                costo = ((Double) body.get("costoRicarica")).floatValue();
                try {
                    ParcheggioDao.aggiornaCostoRicarica(costo, idParcheggio);
                } catch (DaoException e) {
                    halt(500);
                }
                break;
            default:
                halt(422, "tipo non valido");
                break;
        }

        response.status(200);

        return "";
    }

    public static Object getDisponibilita(Request request, Response response) {
        int idParcheggio = -1;

        try {
            idParcheggio = Integer.parseInt(request.params("idParcheggio"));
        } catch (NumberFormatException e) {
            halt(422, "id parcheggio non valido");
        }

        LocalDateTime tempoInizio = null;

        try {
            tempoInizio = LocalDateTime.parse(request.queryMap("tempoInizio").value(), CUSTOM_DATE_TIME_FORMATTER);
        } catch (DateTimeParseException e) {
            halt(422, "data inizio non valida");
        }

        LocalDateTime tempoFine = null;

        try {
            tempoFine = LocalDateTime.parse(request.queryMap("tempoFine").value(), CUSTOM_DATE_TIME_FORMATTER);
        } catch (DateTimeParseException e) {
            halt(422, "data fine non valida");
        }

        List<Prenotazione> prenotazioni = null;

        try {
            prenotazioni = ServizioPrenotazioni.getPrenotazioniByParcheggioInizioFine(idParcheggio, tempoInizio, tempoFine);
        } catch (DaoException e) {
            halt(500);
        }

        int postiPremium = -1;

        try {
            postiPremium = ParcheggioDao.getPostiPremium(idParcheggio);
        } catch (DaoException e) {
            halt(500);
        }

        List<Intervallo> intervalli = calcolaIntervalliDisponibili(prenotazioni, tempoInizio, tempoFine, postiPremium);

        response.type("application/json");
        response.status(200);

        return GSON.toJson(intervalli);
    }

    private static List<Intervallo> calcolaIntervalliDisponibili(List<Prenotazione> prenotazioni, LocalDateTime inizio, LocalDateTime fine, int posti) {
        TreeMap<LocalDateTime, Integer> eventi = new TreeMap<>();

        // Pre-elaborazione delle prenotazioni
        for (Prenotazione prenotazione : prenotazioni) {
            eventi.merge(prenotazione.getTempoInizio(), 1, Integer::sum);
            eventi.merge(prenotazione.getTempoFine(), -1, Integer::sum);
        }

        List<Intervallo> intervalliLiberi = new ArrayList<>();
        int postiOccupati = 0;
        LocalDateTime attuale = inizio;
        LocalDateTime inizioIntervalloLibero = null;

        // Itera attraverso tutti i tempi di evento ordinati
        for (var entry : eventi.entrySet()) {
            LocalDateTime tempoEvento = entry.getKey();
            int variazionePosti = entry.getValue();

            // Aggiungi intervalli liberi tra 'attuale' e 'tempoEvento'
            while (attuale.isBefore(tempoEvento) && attuale.isBefore(fine)) {
                LocalDateTime prossimo = attuale.plusMinutes(15);
                if (postiOccupati < posti && prossimo.isBefore(fine)) {
                    if (inizioIntervalloLibero == null) {
                        inizioIntervalloLibero = attuale;
                    }
                } else {
                    if (inizioIntervalloLibero != null) {
                        intervalliLiberi.add(new Intervallo(inizioIntervalloLibero, attuale));
                        inizioIntervalloLibero = null;
                    }
                }
                attuale = prossimo;
            }

            // Aggiorna il numero di posti occupati
            postiOccupati += variazionePosti;
        }

        // Aggiungi eventuali intervalli liberi rimanenti fino alla fine
        if (attuale.isBefore(fine) && postiOccupati < posti) {
            if (inizioIntervalloLibero == null) {
                inizioIntervalloLibero = attuale;
            }
            intervalliLiberi.add(new Intervallo(inizioIntervalloLibero, fine));
        }

        return intervalliLiberi;
    }

}
