package dao;

import models.Sosta;
import utils.DBConnect;

import static services.ServizioSoste.*;
import static utils.CustomDateTimeFormatter.CUSTOM_DATE_TIME_FORMATTER;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class SosteDao {

    public static Sosta getSostaById(int id) throws DaoException {
        String sql = "SELECT * FROM Soste WHERE idSosta = ?";
        Sosta sosta = null;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, id);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                LocalDateTime tempoInizio;
                LocalDateTime tempoFine;

                try {
                    tempoInizio = LocalDateTime.parse(rs.getString("tempoInizio"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    throw new DaoException();
                }

                try {
                    tempoFine =  LocalDateTime.parse(rs.getString("tempoFine"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    tempoFine = null;
                }

                sosta = new Sosta(rs.getInt("idSosta"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrenotazione"),
                        rs.getInt("idParcheggio"),
                        tempoInizio,
                        tempoFine,
                        rs.getFloat("prezzoOrario"),
                        rs.getInt("stato"),
                        rs.getString("targa"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return sosta;
    }

    public static List<Sosta> getSoste() throws DaoException {
        String sql = "SELECT * FROM Soste";
        List<Sosta> soste = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                LocalDateTime tempoInizio;
                LocalDateTime tempoFine;

                try {
                    tempoInizio = LocalDateTime.parse(rs.getString("tempoInizio"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    throw new DaoException();
                }

                try {
                    tempoFine =  LocalDateTime.parse(rs.getString("tempoFine"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    tempoFine = null;
                }

                Sosta sosta = new Sosta(rs.getInt("idSosta"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrenotazione"),
                        rs.getInt("idParcheggio"),
                        tempoInizio,
                        tempoFine,
                        rs.getFloat("prezzoOrario"),
                        rs.getInt("stato"),
                        rs.getString("targa"));
                soste.add(sosta);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return soste;
    }

    public static List<Sosta> getSosteByStato(boolean corrente) throws DaoException {
        String sql = "SELECT * FROM Soste WHERE stato = ?";
        List<Sosta> soste = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            if (corrente) {
                st.setInt(1, IN_CORSO);
            }
            else {
                st.setInt(1, PASSATA);
            }

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                LocalDateTime tempoInizio;
                LocalDateTime tempoFine;

                try {
                    tempoInizio = LocalDateTime.parse(rs.getString("tempoInizio"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    throw new DaoException();
                }

                try {
                    tempoFine =  LocalDateTime.parse(rs.getString("tempoFine"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    tempoFine = null;
                }

                Sosta sosta = new Sosta(rs.getInt("idSosta"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrenotazione"),
                        rs.getInt("idParcheggio"),
                        tempoInizio,
                        tempoFine,
                        rs.getFloat("prezzoOrario"),
                        rs.getInt("stato"),
                        rs.getString("targa"));
                soste.add(sosta);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return soste;
    }


    public static List<Sosta> getSosteUtente(int idUtente) throws DaoException {
        String sql = "SELECT * FROM Soste WHERE idUtente = ?";
        List<Sosta> soste = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                LocalDateTime tempoInizio;
                LocalDateTime tempoFine;

                try {
                    tempoInizio = LocalDateTime.parse(rs.getString("tempoInizio"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    throw new DaoException();
                }

                try {
                    tempoFine =  LocalDateTime.parse(rs.getString("tempoFine"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    tempoFine = null;
                }

                Sosta sosta = new Sosta(rs.getInt("idSosta"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrenotazione"),
                        rs.getInt("idParcheggio"),
                        tempoInizio,
                        tempoFine,
                        rs.getFloat("prezzoOrario"),
                        rs.getInt("stato"),
                        rs.getString("targa"));
                soste.add(sosta);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return soste;
    }

    public static List<Sosta> getSosteUtenteByStato(int idUtente, boolean corrente) throws DaoException {
        String sql = "SELECT * FROM Soste WHERE idUtente = ? AND stato = ?";
        List<Sosta> soste = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);
            if (corrente) {
                st.setInt(2, IN_CORSO);
            }
            else {
                st.setInt(2, PASSATA);
            }

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                LocalDateTime tempoInizio;
                LocalDateTime tempoFine;

                try {
                    tempoInizio = LocalDateTime.parse(rs.getString("tempoInizio"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    throw new DaoException();
                }

                try {
                    tempoFine =  LocalDateTime.parse(rs.getString("tempoFine"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    tempoFine = null;
                }

                Sosta sosta = new Sosta(rs.getInt("idSosta"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrenotazione"),
                        rs.getInt("idParcheggio"),
                        tempoInizio,
                        tempoFine,
                        rs.getFloat("prezzoOrario"),
                        rs.getInt("stato"),
                        rs.getString("targa"));
                soste.add(sosta);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return soste;
    }

    public static int addSosta(Sosta sosta) throws DaoException {
        int id = -1;
        final String sql = "INSERT INTO Soste(idUtente, idPrenotazione, idParcheggio, tempoInizio, tempoFine, prezzoOrario, stato, targa) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            st.setInt(1, sosta.getIdUtente());
            st.setInt(2, sosta.getIdPrenotazione());
            st.setInt(3, sosta.getIdParcheggio());

            String tempoInizio;
            String tempoFine;

            try {
                tempoInizio = sosta.getTempoInizio().format(CUSTOM_DATE_TIME_FORMATTER);
            } catch (DateTimeParseException | NullPointerException e) {
                throw new DaoException();
            }

            try {
                tempoFine = sosta.getTempoFine().format(CUSTOM_DATE_TIME_FORMATTER);
            } catch (DateTimeParseException | NullPointerException ignored) {
                tempoFine = "";
            }

            st.setString(4, tempoInizio);
            st.setString(5, tempoFine);
            st.setFloat(6, sosta.getPrezzoOrario());
            st.setInt(7, sosta.getStato());
            st.setString(8, sosta.getTarga());

            st.executeUpdate();

            ResultSet rs = st.getGeneratedKeys();

            if (rs.next()) id = rs.getInt(1);

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return id;
    }

    public static Sosta getSostaByTarga(String targa) throws DaoException {
        Sosta sosta = null;
        String sql = "SELECT * FROM Soste WHERE targa = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, targa);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                LocalDateTime tempoInizio;
                LocalDateTime tempoFine;

                try {
                    tempoInizio = LocalDateTime.parse(rs.getString("tempoInizio"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    throw new DaoException();
                }

                try {
                    tempoFine =  LocalDateTime.parse(rs.getString("tempoFine"), CUSTOM_DATE_TIME_FORMATTER);
                } catch (DateTimeParseException | NullPointerException e) {
                    tempoFine = null;
                }

                 sosta = new Sosta(rs.getInt("idSosta"),
                         rs.getInt("idUtente"),
                         rs.getInt("idPrenotazione"),
                         rs.getInt("idParcheggio"),
                         tempoInizio,
                         tempoFine,
                         rs.getFloat("prezzoOrario"),
                         rs.getInt("stato"),
                         rs.getString("targa"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return sosta;
    }

    public static void terminaSosta(Sosta sosta) throws DaoException {
        String sql = "UPDATE Soste SET tempoFine=?, stato=? WHERE idSosta=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, sosta.getTempoFine().format(CUSTOM_DATE_TIME_FORMATTER));
            st.setInt(2, PASSATA);
            st.setInt(3, sosta.getIdSosta());

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }
}
