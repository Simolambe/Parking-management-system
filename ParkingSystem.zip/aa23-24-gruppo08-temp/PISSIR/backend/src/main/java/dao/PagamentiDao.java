package dao;

import models.Pagamento;
import utils.DBConnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PagamentiDao {
    public static void addPagamento(Pagamento pagamento) throws DaoException {
        final String sql = "INSERT INTO Pagamenti(idUtente, idPrestazione, importo, data, tipo, tipoUtente) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, pagamento.getIdUtente());
            st.setInt(2, pagamento.getIdPrestazione());
            st.setFloat(3, pagamento.getImporto());
            st.setString(4, pagamento.getData().toString());
            st.setInt(5, pagamento.getTipo());
            st.setInt(6, pagamento.getTipoUtente());

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static List<Pagamento> getAll() throws DaoException {
        String sql = "SELECT * FROM Pagamenti";

        List<Pagamento> pagamenti = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Pagamento pagamento = new Pagamento(rs.getInt("idPagamento"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrestazione"),
                        rs.getFloat("importo"),
                        LocalDate.parse(rs.getString("data")),
                        rs.getInt("tipo"),
                        rs.getInt("tipoUtente"));

                pagamenti.add(pagamento);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return pagamenti;
    }

    public static List<Pagamento> getAllByTipoUtente(int tipoUtente) throws DaoException {
        String sql = "SELECT * FROM Pagamenti WHERE tipoUtente=?";
        List<Pagamento> pagamenti = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, tipoUtente);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Pagamento pagamento = new Pagamento(rs.getInt("idPagamento"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrestazione"),
                        rs.getFloat("importo"),
                        LocalDate.parse(rs.getString("data")),
                        rs.getInt("tipo"),
                        rs.getInt("tipoUtente"));

                pagamenti.add(pagamento);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return pagamenti;
    }

    public static List<Pagamento> getAllByTipoAndTipoUtente(int tipoPagamento, int tipoUtente) throws DaoException {
        String sql = "SELECT * FROM Pagamenti WHERE tipo=? AND tipoUtente=?";

        List<Pagamento> pagamenti = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, tipoPagamento);
            st.setInt(2, tipoUtente);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Pagamento pagamento = new Pagamento(rs.getInt("idPagamento"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrestazione"),
                        rs.getFloat("importo"),
                        LocalDate.parse(rs.getString("data")),
                        rs.getInt("tipo"),
                        rs.getInt("tipoUtente"));

                pagamenti.add(pagamento);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return pagamenti;
    }

    public static List<Pagamento> getAllByTipo(int tipoPagamento) throws DaoException {
        String sql = "SELECT * FROM Pagamenti WHERE tipo=?";

        List<Pagamento> pagamenti = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, tipoPagamento);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Pagamento pagamento = new Pagamento(rs.getInt("idPagamento"),
                        rs.getInt("idUtente"),
                        rs.getInt("idPrestazione"),
                        rs.getFloat("importo"),
                        LocalDate.parse(rs.getString("data")),
                        rs.getInt("tipo"),
                        rs.getInt("tipoUtente"));

                pagamenti.add(pagamento);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return pagamenti;
    }
}
