package dao;

import models.Ricarica;
import services.ServizioRicariche;
import utils.DBConnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static services.ServizioRicariche.IN_CODA;
import static services.ServizioRicariche.IN_CORSO;

public class RicaricheDao {
    public static int addRicaria(Ricarica ricarica) throws DaoException {
        int id = -1;
        final String sql = "INSERT INTO Ricariche(idSosta, " +
                "idParcheggio, " +
                "idUtente, " +
                "percentualeRichiesta, " +
                "percentualeAttuale, " +
                "notifica, " +
                "kilowattRicaricati, " +
                "stato, " +
                "numeroPosto, " +
                "potenzaKilowatt, " +
                "prezzoRicarica) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            st.setInt(1, ricarica.getIdSosta());
            st.setInt(2, ricarica.getIdParcheggio());
            st.setInt(3, ricarica.getIdUtente());
            st.setInt(4, ricarica.getPercentualeRichiesta());
            st.setInt(5, ricarica.getPercentualeAttuale());
            st.setBoolean(6, ricarica.isNotifica());
            st.setFloat(7, ricarica.getKilowattRicaricati());
            st.setInt(8, ricarica.getStato());
            st.setInt(9, ricarica.getNumeroPosto());
            st.setInt(10, ricarica.getPotenzaKilowatt());
            st.setFloat(11, ricarica.getPrezzoRicarica());

            st.executeUpdate();

            ResultSet rs = st.getGeneratedKeys();

            if (rs.next()) id = rs.getInt(1);

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return id;
    }

    public static List<Ricarica> getRicaricheUtente(int idUtente) throws DaoException {
        String sql = "SELECT * FROM Ricariche WHERE idUtente = ?";
        List<Ricarica> ricariche = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Ricarica ricarica = new Ricarica(rs.getInt("idRicarica"),
                        rs.getInt("idSosta"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("idUtente"),
                        rs.getInt("percentualeRichiesta"),
                        rs.getInt("percentualeAttuale"),
                        rs.getBoolean("notifica"),
                        rs.getFloat("kilowattRicaricati"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"),
                        rs.getInt("potenzaKilowatt"),
                        rs.getFloat("prezzoRicarica"));
                ricariche.add(ricarica);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return ricariche;
    }

    public static List<Ricarica> getRicariche() throws DaoException {
        String sql = "SELECT * FROM Ricariche";
        List<Ricarica> ricariche = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Ricarica ricarica = new Ricarica(rs.getInt("idRicarica"),
                        rs.getInt("idSosta"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("idUtente"),
                        rs.getInt("percentualeRichiesta"),
                        rs.getInt("percentualeAttuale"),
                        rs.getBoolean("notifica"),
                        rs.getFloat("kilowattRicaricati"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"),
                        rs.getInt("potenzaKilowatt"),
                        rs.getFloat("prezzoRicarica"));
                ricariche.add(ricarica);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return ricariche;
    }

    public static Ricarica getRicaricaById(int id) throws DaoException {
        String sql = "SELECT * FROM Ricariche WHERE idRicarica = ?";
        Ricarica ricarica = null;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, id);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                ricarica = new Ricarica(rs.getInt("idRicarica"),
                        rs.getInt("idSosta"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("idUtente"),
                        rs.getInt("percentualeRichiesta"),
                        rs.getInt("percentualeAttuale"),
                        rs.getBoolean("notifica"),
                        rs.getFloat("kilowattRicaricati"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"),
                        rs.getInt("potenzaKilowatt"),
                        rs.getFloat("prezzoRicarica"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return ricarica;
    }

    public static List<Ricarica> getRicaricheBySosta(int idSosta) throws DaoException {
        String sql = "SELECT * FROM Ricariche WHERE idSosta = ?";
        List<Ricarica> ricariche = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idSosta);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Ricarica ricarica = new Ricarica(rs.getInt("idRicarica"),
                        rs.getInt("idSosta"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("idUtente"),
                        rs.getInt("percentualeRichiesta"),
                        rs.getInt("percentualeAttuale"),
                        rs.getBoolean("notifica"),
                        rs.getFloat("kilowattRicaricati"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"),
                        rs.getInt("potenzaKilowatt"),
                        rs.getFloat("prezzoRicarica"));
                ricariche.add(ricarica);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return ricariche;
    }

    public static void cambiaStato(int idRicarica, int percentualeAttuale, float kilowattRicaricati, int potenzaKilowatt, int stato) throws DaoException {
        String sql = "UPDATE Ricariche SET percentualeAttuale = ?, kilowattRicaricati = ?,  potenzaKilowatt = ?, stato = ? WHERE idRicarica = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, percentualeAttuale);
            st.setFloat(2, kilowattRicaricati);
            st.setFloat(3, potenzaKilowatt);
            st.setInt(4, stato);
            st.setInt(5, idRicarica);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void cancellaRicarica(int idRicarica, int cancellata) throws DaoException {
        String sql = "UPDATE Ricariche SET stato = ? WHERE idRicarica = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, cancellata);
            st.setInt(2, idRicarica);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void terminaRicarica(int idRicarica, int percentualeAttuale, float kilowattRicaricati, int stato) throws DaoException {
        String sql = "UPDATE Ricariche SET percentualeAttuale = ?, kilowattRicaricati = ?, stato = ? WHERE idRicarica = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, percentualeAttuale);
            st.setFloat(2, kilowattRicaricati);
            st.setInt(3, stato);
            st.setInt(4, idRicarica);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static List<Ricarica> getRicaricheByStato(int stato) throws DaoException {
        String sql = "SELECT * FROM Ricariche WHERE stato = ?";

        List<Ricarica> ricariche = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, stato);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Ricarica ricarica = new Ricarica(rs.getInt("idRicarica"),
                        rs.getInt("idSosta"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("idUtente"),
                        rs.getInt("percentualeRichiesta"),
                        rs.getInt("percentualeAttuale"),
                        rs.getBoolean("notifica"),
                        rs.getFloat("kilowattRicaricati"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"),
                        rs.getInt("potenzaKilowatt"),
                        rs.getFloat("prezzoRicarica"));
                ricariche.add(ricarica);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return ricariche;
    }

    public static List<Ricarica> getRicaricheUtenteByStato(int idUtente, int stato) throws DaoException {
        String sql = "SELECT * FROM Ricariche WHERE stato = ? AND idUtente = ?";

        List<Ricarica> ricariche = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, stato);
            st.setInt(2, idUtente);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Ricarica ricarica = new Ricarica(rs.getInt("idRicarica"),
                        rs.getInt("idSosta"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("idUtente"),
                        rs.getInt("percentualeRichiesta"),
                        rs.getInt("percentualeAttuale"),
                        rs.getBoolean("notifica"),
                        rs.getFloat("kilowattRicaricati"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"),
                        rs.getInt("potenzaKilowatt"),
                        rs.getFloat("prezzoRicarica"));
                ricariche.add(ricarica);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return ricariche;
    }

    public static List<Ricarica> getRicaricheInCoda(int idParcheggio) throws DaoException {
        String sql = "SELECT * FROM Ricariche WHERE idParcheggio=? AND stato=?";
        List<Ricarica> ricariche = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idParcheggio);
            st.setInt(2, IN_CODA);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Ricarica ricarica = new Ricarica(rs.getInt("idRicarica"),
                        rs.getInt("idSosta"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("idUtente"),
                        rs.getInt("percentualeRichiesta"),
                        rs.getInt("percentualeAttuale"),
                        rs.getBoolean("notifica"),
                        rs.getFloat("kilowattRicaricati"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"),
                        rs.getInt("potenzaKilowatt"),
                        rs.getFloat("prezzoRicarica"));
                ricariche.add(ricarica);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return ricariche;
    }

    /* public static Ricarica getRicaricaInCorso(int idParcheggio) throws DaoException {
        String sql = "SELECT * FROM Ricariche WHERE idParcheggio=? AND stato=?";
        Ricarica ricarica = null;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idParcheggio);
            st.setInt(2, IN_CORSO);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                ricarica = new Ricarica(rs.getInt("idRicarica"),
                        rs.getInt("idSosta"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("idUtente"),
                        rs.getInt("percentualeRichiesta"),
                        rs.getInt("percentualeAttuale"),
                        rs.getBoolean("notifica"),
                        rs.getFloat("kilowattRicaricati"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"),
                        rs.getInt("potenzaKilowatt"),
                        rs.getFloat("prezzoRicarica"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return ricarica;
    } */
}
