package dao;

import models.Prenotazione;
import utils.DBConnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static services.ServizioPrenotazioni.*;

public class PrenotazioniDao {

    public static List<Prenotazione> getPrenotazioni(int idUtente) throws DaoException {
        final String sql = "SELECT * FROM Prenotazioni WHERE Prenotazioni.idUtente = ? AND Prenotazioni.stato = ?";
        List<Prenotazione> prenotazioni = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);
            st.setInt(2, VALIDA);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static List<Prenotazione> getPrenotazioni(int idUtente, int idParcheggio) throws DaoException {
        final String sql = "SELECT * FROM Prenotazioni WHERE idUtente = ? AND stato = ? AND idParcheggio=?";
        List<Prenotazione> prenotazioni = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);
            st.setInt(2, VALIDA);
            st.setInt(3, idParcheggio);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static List<Prenotazione> getByPostoAuto(int numeroPosto) throws DaoException {
        List<Prenotazione> prenotazioni = new ArrayList<>();
        String sql = "SELECT * FROM Prenotazioni WHERE Prenotazioni.numeroPosto = ? AND Prenotazioni.stato = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, numeroPosto);
            st.setInt(2, VALIDA);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static int addPrenotazione(Prenotazione prenotazione) throws DaoException {
        int id = -1;
        final String sql = "INSERT INTO Prenotazioni(idUtente, idParcheggio, tempoInizio, tempoFine, stato, numeroPosto) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            st.setInt(1, prenotazione.getIdUtente());
            st.setInt(2, prenotazione.getIdParcheggio());
            st.setString(3, prenotazione.getTempoInizio().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            st.setString(4, prenotazione.getTempoFine().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            st.setInt(5, prenotazione.getStato());
            st.setInt(6, prenotazione.getNumeroPosto());

            st.executeUpdate();

            ResultSet rs = st.getGeneratedKeys();

            if (rs.next()) id = rs.getInt(1);

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return id;
    }

    public static List<Prenotazione> getByUtente(int idUtente) throws DaoException {
        List<Prenotazione> prenotazioni = new ArrayList<>();
        String sql = "SELECT * FROM Prenotazioni WHERE Prenotazioni.idUtente = ? AND Prenotazioni.stato = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);
            st.setInt(2, VALIDA);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static Prenotazione getById(int idPrenotazione) throws DaoException {
        String sql = "SELECT * FROM Prenotazioni WHERE idPrenotazione = ?";
        Prenotazione prenotazione = null;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idPrenotazione);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
               prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazione;
    }

    public static void cambiaStato(int idPrenotazione, int stato) throws DaoException {
        String sql = "UPDATE Prenotazioni SET stato = ? WHERE idPrenotazione = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, stato);
            st.setInt(2, idPrenotazione);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static List<Prenotazione> getAll() throws DaoException {
        List<Prenotazione> prenotazioni = new ArrayList<>();
        String sql = "SELECT * FROM Prenotazioni";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static List<Prenotazione> getByNumeroPosto(int numeroPosto) throws DaoException {
        List<Prenotazione> prenotazioni = new ArrayList<>();
        String sql = "SELECT * FROM Prenotazioni WHERE numeroPosto=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, numeroPosto);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static List<Prenotazione> getPrenotazioniValide(int idUtente) throws DaoException {
        List<Prenotazione> prenotazioni = new ArrayList<>();
        String sql = "SELECT * FROM Prenotazioni WHERE idUtente=? AND stato=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);
            st.setInt(2, VALIDA);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static List<Prenotazione> getPrenotazioniValide() throws DaoException {
        List<Prenotazione> prenotazioni = new ArrayList<>();
        String sql = "SELECT * FROM Prenotazioni WHERE stato=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, VALIDA);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static List<Prenotazione> getPrenotazioniPassate(int idUtente) throws DaoException {
        List<Prenotazione> prenotazioni = new ArrayList<>();
        String sql = "SELECT * FROM Prenotazioni WHERE idUtente=? AND (stato=? OR stato=? OR stato=?)";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);
            st.setInt(2, UTILIZZATA);
            st.setInt(3, CANCELLATA);
            st.setInt(4, SCADUTA);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }

    public static List<Prenotazione> getByParcheggio(int idParcheggio) throws DaoException {
        String sql = "SELECT * FROM Prenotazioni WHERE idParcheggio=?";
        List<Prenotazione> prenotazioni = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idParcheggio);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Prenotazione prenotazione = new Prenotazione(rs.getInt("idPrenotazione"),
                        rs.getInt("idUtente"),
                        rs.getInt("idParcheggio"),
                        LocalDateTime.parse(rs.getString("tempoInizio"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        LocalDateTime.parse(rs.getString("tempoFine"), DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                        rs.getInt("stato"),
                        rs.getInt("numeroPosto"));
                prenotazioni.add(prenotazione);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return prenotazioni;
    }
}
