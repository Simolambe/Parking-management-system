package dao;

public class DaoException extends Exception {

}
