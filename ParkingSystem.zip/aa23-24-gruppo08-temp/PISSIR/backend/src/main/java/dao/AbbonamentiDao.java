package dao;

import models.Abbonamento;
import utils.DBConnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AbbonamentiDao {
    public static int add(Abbonamento abbonamento) throws DaoException {
        String sql = "INSERT INTO Abbonamenti(idUtente, costo, data) VALUES (?, ?, ?)";
        int id = -1;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            st.setInt(1, abbonamento.getIdUtente());
            st.setFloat(2, abbonamento.getCosto());
            st.setString(3, abbonamento.getData().toString());

            st.executeUpdate();

            ResultSet rs = st.getGeneratedKeys();

            if (rs.next()) id = rs.getInt(1);

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return id;
    }
}
