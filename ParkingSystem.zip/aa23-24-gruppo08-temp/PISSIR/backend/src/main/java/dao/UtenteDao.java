package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import models.*;
import services.ServizioUtenti;
import utils.DBConnect;

import static services.ServizioUtenti.UTENTE_PREMIUM;

public class UtenteDao {

    public static List<Utente> getAll() throws DaoException {
        final String sql = "SELECT * FROM Utenti";
        List<Utente> utenti = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Utente utente = new Utente(rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getInt("tipo"),
                        rs.getString("immagine"));

                utenti.add(utente);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return utenti;
    }

    public static int addUser(Utente utente) throws DaoException {
        int id = -1;
        final String sql = "INSERT INTO Utenti(nome, cognome, email, password, tipo, immagine) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            st.setString(1, utente.getNome());
            st.setString(2, utente.getCognome());
            st.setString(3, utente.getEmail());
            st.setString(4, utente.getPassword());
            st.setInt(5, ServizioUtenti.UTENTE_BASE);
            st.setString(6, null);

            st.executeUpdate();

            ResultSet rs = st.getGeneratedKeys();

            if (rs.next()) id = rs.getInt(1);

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return id;
    }

    public static Utente findUserByEmail(String email) throws DaoException {
        Utente utente = null;
        final String sql = "SELECT * FROM Utenti WHERE email = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            st.setString(1, email);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String cognome = rs.getString("cognome");
                String password = rs.getString("password");
                int tipo = rs.getInt("tipo");
                String immagine = rs.getString("immagine");

                utente = new Utente(id,
                        nome,
                        cognome,
                        email,
                        password,
                        tipo,
                        immagine);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return utente;
    }

    public static void updateEmail(int idUtente, String email) throws DaoException {
        final String sql = "UPDATE Utenti SET email = ? WHERE id = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, email);
            st.setInt(2, idUtente);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void updatePassword(int idUtente, String password) throws DaoException {
        final String sql = "UPDATE Utenti SET password=? WHERE id=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, password);
            st.setInt(2, idUtente);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void deleteUser(int idUtente) throws DaoException {
        final String sql = "DELETE FROM Utenti WHERE id=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void addPaymentMethod(MetodoPagamento metodoPagamento) throws DaoException {
        String sql = "INSERT INTO MetodiPagamento(idUtente, numeroCarta, annoScadenza, meseScadenza, cvv, tipoCarta, titolare) VALUES(?, ?, ?, ?, ?, ?, ?)";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, metodoPagamento.getIdUtente());
            st.setString(2, metodoPagamento.getNumeroCarta());
            st.setString(3, metodoPagamento.getAnnoScadenza());
            st.setString(4, metodoPagamento.getMeseScadenza());
            st.setString(5, metodoPagamento.getCvv());
            st.setString(6, metodoPagamento.getTipoCarta());
            st.setString(7, metodoPagamento.getTitolare());

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static MetodoPagamento getMetodoPagamento(int idUtente) throws DaoException {
        MetodoPagamento metodoPagamento = null;
        String sql = "SELECT * FROM MetodiPagamento WHERE idUtente=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);

            ResultSet rs = st.executeQuery();

            if (rs.next()) metodoPagamento = new MetodoPagamento(rs.getInt("idUtente"),
                    rs.getString("numeroCarta"),
                    rs.getString("annoScadenza"),
                    rs.getString("meseScadenza"),
                    rs.getString("cvv"),
                    rs.getString("tipoCarta"),
                    rs.getString("titolare"));

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return metodoPagamento;
    }

    public static void deleteMetodoPagamento(int idUtente) throws DaoException {
        String sql = "DELETE FROM MetodiPagamento WHERE idUtente=?";
        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void addVeicolo(Veicolo veicolo) throws DaoException {
        String sql = "INSERT INTO Veicoli(idUtente, targa) VALUES(?, ?)";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, veicolo.getIdUtente());
            st.setString(2, veicolo.getTarga());

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static List<Veicolo> getVeicoli(int idUtente) throws DaoException {
        String sql = "SELECT * FROM Veicoli WHERE idUtente=?";

        List<Veicolo> veicoli = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                veicoli.add(new Veicolo(rs.getInt("idUtente"), rs.getString("targa")));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return veicoli;
    }

    public static void deleteVeicolo(String targa) throws DaoException {
        String sql = "DELETE FROM Veicoli WHERE targa=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, targa);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static Utente getUtenteByTarga(String targa) throws DaoException {
        String sql = "SELECT * FROM Utenti INNER JOIN Veicoli ON id=idUtente WHERE targa=?";
        Utente utente = null;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, targa);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                utente = new Utente(rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getInt("tipo"),
                        rs.getString("immagine"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return utente;
    }

    public static Utente getUtenteByEmail(String email) throws DaoException {
        String sql = "SELECT * FROM Utenti WHERE email = ?";

        Utente utente = null;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, email);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                utente = new Utente(rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getInt("tipo"),
                        rs.getString("immagine"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return utente;
    }

    public static Utente getById(int idUtente) throws DaoException {
        String sql = "SELECT * FROM Utenti WHERE id=?";

        Utente utente = null;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idUtente);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                utente = new Utente(rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cognome"),
                        rs.getString("email"),
                        rs.getString("password"),
                        rs.getInt("tipo"),
                        rs.getString("immagine"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return utente;
    }

    public static void updateNome(int idUtente, String nome) throws DaoException {
        final String sql = "UPDATE Utenti SET nome=? WHERE id=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, nome);
            st.setInt(2, idUtente);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void updateCognome(int idUtente, String cognome) throws DaoException {
        final String sql = "UPDATE Utenti SET cognome=? WHERE id=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, cognome);
            st.setInt(2, idUtente);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void updateImmagine(int idUtente, String immagine) throws DaoException {
        final String sql = "UPDATE Utenti SET immagine=? WHERE id=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, immagine);
            st.setInt(2, idUtente);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void upgradeToPremium(int idUtente) throws DaoException {
        final String sql = "UPDATE Utenti SET tipo=? WHERE id=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, UTENTE_PREMIUM);
            st.setInt(2, idUtente);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }
}