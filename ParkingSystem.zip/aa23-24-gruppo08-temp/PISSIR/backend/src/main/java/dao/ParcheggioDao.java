package dao;

import models.Parcheggio;
import models.PostoAuto;
import services.ServizioParcheggio;
import utils.DBConnect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static services.ServizioParcheggio.POSTO_PREMIUM;

public class ParcheggioDao {

    public static List<PostoAuto> getPostiAuto(int idParcheggio) throws DaoException {
        String sql = "SELECT * FROM PostiAuto WHERE idParcheggio=?";
        List<PostoAuto> postiAuto = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idParcheggio);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                PostoAuto postoAuto = new PostoAuto(rs.getInt("numeroPosto"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPrenotazioni"),
                        rs.getInt("tipo"));

                postiAuto.add(postoAuto);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return postiAuto;
    }

    public static void cambiaStatoPosto(int idParcheggio, int numeroPosto, int stato) throws DaoException {
        String sql = "UPDATE PostiAuto SET (stato) = ? WHERE numeroPosto = ? AND idParcheggio=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, stato);
            st.setInt(2, numeroPosto);
            st.setInt(3, idParcheggio);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void aggiornaPrenotazioniPosto(int idParcheggio, int numeroPosto, int numeroPrenotazioni) throws DaoException {
        String sql = "UPDATE PostiAuto SET (numeroPrenotazioni) = ? WHERE numeroPosto = ? AND idParcheggio=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, numeroPrenotazioni);
            st.setInt(2, numeroPosto);
            st.setInt(3, idParcheggio);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static List<Parcheggio> getAll() throws DaoException {
        List<Parcheggio> parcheggi = new ArrayList<>();
        String sql = "SELECT * FROM Parcheggi";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                Parcheggio parcheggio = new Parcheggio(rs.getInt("idParcheggio"),
                        rs.getString("citta"),
                        rs.getString("via"),
                        rs.getString("civico"),
                        rs.getInt("numeroPostiBase"),
                        rs.getInt("numeroPostiLiberi"),
                        rs.getInt("numeroPostiPremium"),
                        rs.getInt("numeroMWBot"),
                        rs.getFloat("costoSosta"),
                        rs.getFloat("costoRicarica"));

                parcheggi.add(parcheggio);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return parcheggi;
    }

    public static Parcheggio getById(int idParcheggio) throws DaoException {
        Parcheggio parcheggio = null;
        String sql = "SELECT * FROM Parcheggi WHERE idParcheggio = ?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idParcheggio);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                 parcheggio = new Parcheggio(rs.getInt("idParcheggio"),
                        rs.getString("citta"),
                        rs.getString("via"),
                        rs.getString("civico"),
                        rs.getInt("numeroPostiBase"),
                        rs.getInt("numeroPostiLiberi"),
                        rs.getInt("numeroPostiPremium"),
                        rs.getInt("numeroMWBot"),
                        rs.getFloat("costoSosta"),
                        rs.getFloat("costoRicarica"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return parcheggio;
    }

    public static void aggiornaCostoSosta(float costo, int idParcheggio) throws DaoException {
        String sql = "UPDATE Parcheggi SET costoSosta=? WHERE idParcheggio=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setFloat(1, costo);
            st.setInt(2, idParcheggio);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static void aggiornaCostoRicarica(float costo, int idParcheggio) throws DaoException {
        String sql = "UPDATE Parcheggi SET costoRicarica=? WHERE idParcheggio=?";

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setFloat(1, costo);
            st.setInt(2, idParcheggio);

            st.executeUpdate();

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }
    }

    public static int getPostiPremium(int idParcheggio) throws DaoException {
        String sql = "SELECT numeroPostiPremium FROM Parcheggi WHERE idParcheggio=?";
        int numeroPostiPremium = -1;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idParcheggio);

            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                numeroPostiPremium = rs.getInt("numeroPostiPremium");
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return numeroPostiPremium;
    }

    public static PostoAuto getPostoAutoById(int idParcheggio, int numeroPosto) throws DaoException {
        String sql = "SELECT * FROM PostiAuto WHERE idParcheggio = ? AND numeroPosto = ?";
        PostoAuto postoAuto = null;

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idParcheggio);
            st.setInt(2, numeroPosto);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                postoAuto = new PostoAuto(rs.getInt("numeroPosto"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPrenotazioni"),
                        rs.getInt("tipo"));
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return postoAuto;
    }

    public static List<PostoAuto> getPostiAutoPremium(int idParcheggio) throws DaoException {
        String sql = "SELECT * FROM PostiAuto WHERE idParcheggio=? AND tipo=?";
        List<PostoAuto> postiAuto = new ArrayList<>();

        try {
            Connection conn = DBConnect.getInstance().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, idParcheggio);
            st.setInt(2, POSTO_PREMIUM);

            ResultSet rs = st.executeQuery();

            while(rs.next()) {
                PostoAuto postoAuto = new PostoAuto(rs.getInt("numeroPosto"),
                        rs.getInt("idParcheggio"),
                        rs.getInt("stato"),
                        rs.getInt("numeroPrenotazioni"),
                        rs.getInt("tipo"));

                postiAuto.add(postoAuto);
            }

            conn.close();
        } catch (SQLException e) {
            throw new DaoException();
        }

        return postiAuto;
    }
}
