package models;

public class Veicolo {

    int idUtente;
    String targa;

    public Veicolo(int idUtente, String targa) {
        this.idUtente = idUtente;
        this.targa = targa;
    }

    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public String getTarga() {
        return targa;
    }

    public void setTarga(String targa) {
        this.targa = targa;
    }

}
