package models;

public class Parcheggio {

    private int idParcheggio;
    private String citta;
    private String via;
    private String civico;
    private int numeroPostiBase;
    private int numeroPostiPremium;
    private int numeroPostiLiberi;
    private int numeroMWBot;
    private float costoSosta;
    private float costoRicarica;

    public Parcheggio(int idParcheggio, String citta, String via, String civico, int numeroPostiBase, int numeroPostiLiberi, int numeroPostiPremium, int numeroMWBot, float costoSosta, float costoRicarica) {
        this.idParcheggio = idParcheggio;
        this.citta = citta;
        this.via = via;
        this.civico = civico;
        this.numeroPostiBase = numeroPostiBase;
        this.numeroPostiPremium = numeroPostiPremium;
        this.numeroPostiLiberi = numeroPostiLiberi;
        this.numeroMWBot = numeroMWBot;
        this.costoSosta = costoSosta;
        this.costoRicarica = costoRicarica;
    }

    public int getIdParcheggio() {
        return idParcheggio;
    }

    public void setIdParcheggio(int idParcheggio) {
        this.idParcheggio = idParcheggio;
    }

    public int getNumeroPostiBase() {
        return numeroPostiBase;
    }

    public void setNumeroPostiBase(int numeroPostiBase) {
        this.numeroPostiBase = numeroPostiBase;
    }

    public int getNumeroPostiPremium() {
        return numeroPostiPremium;
    }

    public void setNumeroPostiPremium(int numeroPostiPremium) {
        this.numeroPostiPremium = numeroPostiPremium;
    }

    public int getNumeroMWBot() {
        return numeroMWBot;
    }

    public void setNumeroMWBot(int numeroMWBot) {
        this.numeroMWBot = numeroMWBot;
    }

    public float getCostoSosta() {
        return costoSosta;
    }

    public void setCostoSosta(float costoSosta) {
        this.costoSosta = costoSosta;
    }

    public float getCostoRicarica() {
        return costoRicarica;
    }

    public void setCostoRicarica(float costoRicarica) {
        this.costoRicarica = costoRicarica;
    }

    public int getNumeroPostiLiberi() {
        return numeroPostiLiberi;
    }

    public void setNumeroPostiLiberi(int numeroPostiLiberi) {
        this.numeroPostiLiberi = numeroPostiLiberi;
    }

    public String getCitta() {
        return citta;
    }

    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getVia() {
        return via;
    }

    public void setVia(String via) {
        this.via = via;
    }

    public String getCivico() {
        return civico;
    }

    public void setCivico(String civico) {
        this.civico = civico;
    }
}
