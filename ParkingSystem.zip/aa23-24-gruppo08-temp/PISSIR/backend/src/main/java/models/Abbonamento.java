package models;

import java.time.LocalDate;

public class Abbonamento {

    private int idAbbonamento;
    private int idUtente;
    private float costo;
    private LocalDate data;

    public Abbonamento(int idAbbonamento, int idUtente, float costo, LocalDate data) {
        this.idAbbonamento = idAbbonamento;
        this.idUtente = idUtente;
        this.costo = costo;
        this.data = data;
    }

    public int getIdAbbonamento() {
        return idAbbonamento;
    }

    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public void setIdAbbonamento(int idAbbonamento) {
        this.idAbbonamento = idAbbonamento;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }
}
