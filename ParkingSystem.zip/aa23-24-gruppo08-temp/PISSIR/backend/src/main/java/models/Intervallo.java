package models;

import java.time.LocalDateTime;

public class Intervallo {

    private LocalDateTime inizio;
    private LocalDateTime fine;

    public Intervallo(LocalDateTime inizio, LocalDateTime fine) {
        this.inizio = inizio;
        this.fine = fine;
    }
}
