package models;

import java.time.LocalDateTime;

public class Sosta {

    private int idSosta;
    private int idUtente;
    private int idPrenotazione;
    private int idParcheggio;
    private LocalDateTime tempoInizio;
    private LocalDateTime tempoFine;
    private float prezzoOrario;
    private int stato;
    private String targa;

    public Sosta(int idSosta, int idUtente, int idPrenotazione, int idParcheggio, LocalDateTime tempoInizio, LocalDateTime tempoFine, float prezzoOrario, int stato, String targa) {
        this.idSosta = idSosta;
        this.idUtente = idUtente;
        this.idPrenotazione = idPrenotazione;
        this.idParcheggio = idParcheggio;
        this.tempoInizio = tempoInizio;
        this.tempoFine = tempoFine;
        this.prezzoOrario = prezzoOrario;
        this.stato = stato;
        this.targa = targa;
    }

    public int getIdSosta() {
        return idSosta;
    }

    public void setIdSosta(int idSosta) {
        this.idSosta = idSosta;
    }

    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public int getIdPrenotazione() {
        return idPrenotazione;
    }

    public void setIdPrenotazione(int idPrenotazione) {
        this.idPrenotazione = idPrenotazione;
    }

    public int getIdParcheggio() {
        return idParcheggio;
    }

    public void setIdParcheggio(int idParcheggio) {
        this.idParcheggio = idParcheggio;
    }

    public LocalDateTime getTempoFine() {
        return tempoFine;
    }

    public void setTempoFine(LocalDateTime tempoFine) {
        this.tempoFine = tempoFine;
    }

    public LocalDateTime getTempoInizio() {
        return tempoInizio;
    }

    public void setTempoInizio(LocalDateTime tempoInizio) {
        this.tempoInizio = tempoInizio;
    }

    public float getPrezzoOrario() {
        return prezzoOrario;
    }

    public void setPrezzoOrario(float prezzo) {
        this.prezzoOrario = prezzo;
    }

    public int getStato() {
        return stato;
    }

    public void setStato(int stato) {
        this.stato = stato;
    }

    public String getTarga() {
        return targa;
    }

    public void setTarga(String targa) {
        this.targa = targa;
    }
}
