package models;

public class MetodoPagamento {

    int idUtente;
    String numeroCarta;
    String meseScadenza;
    String annoScadenza;
    String cvv;
    String tipoCarta;
    String titolare;

    public MetodoPagamento(int idUtente, String numeroCarta, String meseScadenza, String annoScadenza, String cvv, String tipoCarta, String titolare) {
        this.idUtente = idUtente;
        this.numeroCarta = numeroCarta;
        this.meseScadenza = meseScadenza;
        this.annoScadenza = annoScadenza;
        this.cvv = cvv;
        this.tipoCarta = tipoCarta;
        this.titolare = titolare;
    }


    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public String getNumeroCarta() {
        return numeroCarta;
    }

    public void setNumeroCarta(String numeroCarta) {
        this.numeroCarta = numeroCarta;
    }

    public String getAnnoScadenza() {
        return annoScadenza;
    }

    public void setAnnoScadenza(String annoScadenza) {
        this.annoScadenza = annoScadenza;
    }

    public String getMeseScadenza() {
        return meseScadenza;
    }

    public void setMeseScadenza(String meseScadenza) {
        this.meseScadenza = meseScadenza;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getTipoCarta() {
        return tipoCarta;
    }

    public void setTipoCarta(String tipoCarta) {
        this.tipoCarta = tipoCarta;
    }

    public String getTitolare() {
        return titolare;
    }

    public void setTitolare(String titolare) {
        this.titolare = titolare;
    }
}
