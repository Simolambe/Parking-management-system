package models;

public class Ricarica {

    private int idRicarica;
    private int idSosta;
    private int idParcheggio;
    private int idUtente;
    private int percentualeRichiesta;
    private boolean notifica;
    private float kilowattRicaricati;
    private int stato;
    private int numeroPosto;
    private int percentualeAttuale;
    private int potenzaKilowatt;
    private float prezzoRicarica;

    public Ricarica(int idRicarica, int idSosta, int idParcheggio, int idUtente, int percentualeRichiesta, int percentualeAttuale, boolean notifica, float kilowattRicaricati, int stato, int numeroPosto, int potenzaKilowatt, float prezzoRicarica) {
        this.idRicarica = idRicarica;
        this.idSosta = idSosta;
        this.idParcheggio = idParcheggio;
        this.idUtente = idUtente;
        this.percentualeRichiesta = percentualeRichiesta;
        this.percentualeAttuale = percentualeAttuale;
        this.notifica = notifica;
        this.kilowattRicaricati = kilowattRicaricati;
        this.stato = stato;
        this.numeroPosto = numeroPosto;
        this.potenzaKilowatt = potenzaKilowatt;
        this.prezzoRicarica = prezzoRicarica;
    }

    public int getIdRicarica() {
        return idRicarica;
    }

    public void setIdRicarica(int idRicarica) {
        this.idRicarica = idRicarica;
    }

    public int getIdSosta() {
        return idSosta;
    }

    public void setIdSosta(int idSosta) {
        this.idSosta = idSosta;
    }

    public int getIdParcheggio() {
        return idParcheggio;
    }

    public void setIdParcheggio(int idParcheggio) {
        this.idParcheggio = idParcheggio;
    }

    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public int getPercentualeRichiesta() {
        return percentualeRichiesta;
    }

    public void setPercentualeRichiesta(int percentualeRichiesta) {
        this.percentualeRichiesta = percentualeRichiesta;
    }

    public int getPercentualeAttuale() {
        return percentualeAttuale;
    }

    public void setPercentualeAttuale(int percentualeAttuale) {
        this.percentualeAttuale = percentualeAttuale;
    }

    public boolean isNotifica() {
        return notifica;
    }

    public void setNotifica(boolean notifica) {
        this.notifica = notifica;
    }

    public float getKilowattRicaricati() {
        return kilowattRicaricati;
    }

    public void setKilowattRicaricati(float kilowattRicaricati) {
        this.kilowattRicaricati = kilowattRicaricati;
    }

    public int getStato() {
        return stato;
    }

    public void setStato(int stato) {
        this.stato = stato;
    }

    public int getNumeroPosto() {
        return numeroPosto;
    }

    public void setNumeroPosto(int numeroPosto) {
        this.numeroPosto = numeroPosto;
    }

    public int getPotenzaKilowatt() {
        return potenzaKilowatt;
    }

    public void setPotenzaKilowatt(int potenzaKilowatt) {
        this.potenzaKilowatt = potenzaKilowatt;
    }

    public float getPrezzoRicarica() {
        return prezzoRicarica;
    }

    public void setPrezzoRicarica(float prezzoRicarica) {
        this.prezzoRicarica = prezzoRicarica;
    }
}
