package models;

import java.time.LocalDate;

public class Pagamento {

    private int idPagamento;
    private int idUtente;
    private int idPrestazione;
    private float importo;
    private LocalDate data;
    private int tipo;
    private int tipoUtente;

    public Pagamento(int idPagamento, int idUtente, int idPrestazione, float importo, LocalDate data, int tipo, int tipoUtente) {
        this.idPagamento = idPagamento;
        this.idUtente = idUtente;
        this.idPrestazione = idPrestazione;
        this.importo = importo;
        this.data = data;
        this.tipo = tipo;
        this.tipoUtente = tipoUtente;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public int getIdPagamento() {
        return idPagamento;
    }

    public void setIdPagamento(int idPagamento) {
        this.idPagamento = idPagamento;
    }

    public int getIdPrestazione() {
        return idPrestazione;
    }

    public void setIdPrestazione(int idPrestazione) {
        this.idPrestazione = idPrestazione;
    }

    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public float getImporto() {
        return importo;
    }

    public void setImporto(float importo) {
        this.importo = importo;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getTipoUtente() {
        return tipoUtente;
    }

    public void setTipoUtente(int tipoUtente) {
        this.tipoUtente = tipoUtente;
    }
}

