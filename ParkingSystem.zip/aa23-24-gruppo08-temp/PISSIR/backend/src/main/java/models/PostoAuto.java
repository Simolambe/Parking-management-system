package models;

public class PostoAuto {

    private int numeroPosto;
    private int stato;
    private int numeroPrenotazioni;
    private int tipo;
    private int idParcheggio;

    public PostoAuto(int numeroPosto, int idParcheggio, int stato, int numeroPrenotazioni, int tipo) {
        this.numeroPosto = numeroPosto;
        this.stato = stato;
        this.numeroPrenotazioni = numeroPrenotazioni;
        this.tipo = tipo;
        this.idParcheggio = idParcheggio;
    }

    public int getNumeroPosto() {
        return numeroPosto;
    }

    public void setNumeroPosto(int numeroPosto) {
        this.numeroPosto = numeroPosto;
    }

    public int getNumeroPrenotazioni() {
        return numeroPrenotazioni;
    }

    public void setNumeroPrenotazioni(int prenotato) {
        this.numeroPrenotazioni = prenotato;
    }

    public int getStato() {
        return stato;
    }

    public void setStato(int stato) {
        this.stato = stato;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getIdParcheggio() {
        return idParcheggio;
    }

    public void setIdParcheggio(int idParcheggio) {
        this.idParcheggio = idParcheggio;
    }
}
