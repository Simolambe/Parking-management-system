package models;

import java.time.LocalDateTime;

public class Prenotazione {

    private int idPrenotazione;
    private int idUtente;
    private int idParcheggio;
    private LocalDateTime tempoInizio;
    private LocalDateTime tempoFine;
    private int stato;
    private int numeroPosto;

    public Prenotazione(int idPrenotazione, int idUtente, int idParcheggio, LocalDateTime tempoInizio, LocalDateTime tempoFine, int stato, int numeroPosto) {
        this.idPrenotazione = idPrenotazione;
        this.idUtente = idUtente;
        this.idParcheggio = idParcheggio;
        this.tempoInizio = tempoInizio;
        this.tempoFine = tempoFine;
        this.stato = stato;
        this.numeroPosto = numeroPosto;
    }

    public int getIdPrenotazione() {
        return idPrenotazione;
    }

    public void setIdPrenotazione(int idPrenotazione) {
        this.idPrenotazione = idPrenotazione;
    }

    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }

    public int getNumeroPosto() {
        return numeroPosto;
    }

    public void setNumeroPosto(int numeroPosto) {
        this.numeroPosto = numeroPosto;
    }

    public int getStato() {
        return stato;
    }

    public void setStato(int stato) {
        this.stato = stato;
    }

    public LocalDateTime getTempoFine() {
        return tempoFine;
    }

    public void setTempoFine(LocalDateTime tempoFine) {
        this.tempoFine = tempoFine;
    }

    public LocalDateTime getTempoInizio() {
        return tempoInizio;
    }

    public void setTempoInizio(LocalDateTime tempoInizio) {
        this.tempoInizio = tempoInizio;
    }

    public int getIdParcheggio() {
        return idParcheggio;
    }

    public void setIdParcheggio(int idParcheggio) {
        this.idParcheggio = idParcheggio;
    }
}
