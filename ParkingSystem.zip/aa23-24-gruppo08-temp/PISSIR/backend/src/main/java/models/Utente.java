package models;

import java.util.ArrayList;

public class Utente {

    private int id;
    private String nome;
    private String cognome;
    private String email;
    private String password;
    private int tipo;
    private String immagine;

    /**
     * Costruttore.
     *
     * @param id rappresenta l'id unico dell'utente
     * @param nome il nome dell'utente
     * @param cognome il cognome dell'utente
     * @param email l'email dell'utente
     * @param password la password del'utente
     */
    public Utente(int id, String nome, String cognome, String email, String password, int tipo, String immagine) {
        this.id = id;
        this.nome = nome;
        this.cognome = cognome;
        this.email = email;
        this.password = password;
        this.tipo = tipo;
        this.immagine = immagine;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return this.cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public String getImmagine() {
        return immagine;
    }

    public void setImmagine(String immagine) {
        this.immagine = immagine;
    }
}
