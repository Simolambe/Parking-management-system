package utils;

import org.eclipse.paho.client.mqttv3.*;
import dao.DaoException;
import dao.ParcheggioDao;
import dao.UtenteDao;
import models.PostoAuto;
import models.Ricarica;
import models.Utente;
import services.ServizioRicariche;
import services.ServizioSoste;

import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

import static server.Server.GSON;
import static server.Server.clientMap;
import static services.ServizioParcheggio.POSTO_LIBERO;
import static services.ServizioParcheggio.POSTO_OCCUPATO;

public class MQTTCallback implements MqttCallback {

    private static final Config config;
    private static final String frontEndBaseUrl;
    private static final String notificaRicaricaApiUrl;
    private static final String notificaTermineRicaricaApiUrl;
    private static final String notificaInizioRicaricaApiUrl;
    private static final String notificaOccupazionePostoApiUrl;
    // private static final String notificaNumeroCodaApiUrl;

    private static final String TOPIC_CONTROLLA_TARGA_IN;
    private static final String TOPIC_CONTROLLA_TARGA_OUT;
    private static final String TOPIC_RIC_STATO;
    private static final String TOPIC_RIC_TERM;
    private static final String TOPIC_SENSORI;
    private static final String TOPIC_SBARRA_IN;
    private static final String TOPIC_SBARRA_OUT;
    private static final String TOPIC_ERRORE_SOSTA_IN;
    private static final String TOPIC_ERRORE_SOSTA_OUT;

    private static final Logger logger = Logger.getLogger(MQTTCallback.class.getName());

    private int idParcheggio;

    static {
        config = Config.getInstance();

        frontEndBaseUrl = config.getFrontEndBaseUrl();
        notificaRicaricaApiUrl = config.getNotificaRicaricaApiUrl();
        notificaTermineRicaricaApiUrl = config.getNotificaTermineRicaricaApiUrl();
        notificaInizioRicaricaApiUrl = config.getNotificaInizioRicaricaApiUrl();
        notificaOccupazionePostoApiUrl = config.getNotificaOccupazionePostoApiUrl();

        TOPIC_CONTROLLA_TARGA_IN = config.getTopicControllaTargaIn();
        TOPIC_CONTROLLA_TARGA_OUT = config.getTopicControllaTargaOut();
        TOPIC_RIC_STATO = config.getTopicRicStato();
        TOPIC_RIC_TERM = config.getTopicRicTerm();
        TOPIC_SENSORI = config.getTopicSensori();
        TOPIC_SBARRA_IN = config.getTopicSbarraIn();
        TOPIC_SBARRA_OUT = config.getTopicSbarraOut();
        TOPIC_ERRORE_SOSTA_IN = config.getTopicErroreSostaIn();
        TOPIC_ERRORE_SOSTA_OUT = config.getTopicErroreSostaOut();
    }

    public MQTTCallback(int idParcheggio) {
        this.idParcheggio = idParcheggio;
    }

    @Override
    public void connectionLost(Throwable throwable) {
        logger.log(Level.WARNING, "Connessione persa, tentativo di riconnessione...", throwable);

        boolean reconnected = false;
        int attempt = 0;
        while (!reconnected) {
            try {
                MqttClient client = clientMap.get(idParcheggio);

                Thread.sleep(2000);
                client.connect();
                reconnected = true;
                logger.info("Riconnessione al broker MQTT riuscita");

                client.subscribe(TOPIC_CONTROLLA_TARGA_IN, 1);
                client.subscribe(TOPIC_CONTROLLA_TARGA_OUT, 1);
                client.subscribe(TOPIC_SENSORI + "/+", 1);
                client.subscribe(TOPIC_RIC_STATO, 1);
                client.subscribe(TOPIC_RIC_TERM, 1);
                logger.info("Sottoscrizione ai topic MQTT riuscita");
            } catch (MqttException | InterruptedException e) {
                attempt++;
                logger.log(Level.WARNING, "Errore durante la riconnessione al broker MQTT, tentativo: " + attempt, e);
            }
        }
    }

    @Override
    public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
        logger.log(Level.SEVERE, "Ricevuto messaggio su topic: " + s);

        String payload = new String(mqttMessage.getPayload(), StandardCharsets.UTF_8);

        if (s.matches(TOPIC_SENSORI + "/\\d+")) handleSensori(s, payload);
        if (s.equals(TOPIC_CONTROLLA_TARGA_IN)) handleControllaTargaIn(payload);
        if (s.equals(TOPIC_CONTROLLA_TARGA_OUT)) handleControllaTargaOut(payload);
        if (s.equals(TOPIC_RIC_TERM)) handleRicaricaTerm(payload);
        if (s.equals(TOPIC_RIC_STATO)) handleRicaricaStato(payload);
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
        logger.info("Consegna completata per il messaggio: " + iMqttDeliveryToken.getMessageId());
    }

    private void handleControllaTargaIn(String payload) {
        String[] arr = payload.split(",");

        int idParcheggio = Integer.parseInt(arr[0]);
        String targa = arr[1];

        try {
            int res = ServizioSoste.avviaSosta(targa, idParcheggio);
            switch(res) {
                case 0: // targa valida, sosta creata
                    clientMap.get(idParcheggio).publish(TOPIC_SBARRA_IN, (idParcheggio + ",UP").getBytes(), 1, false);
                    logger.info("Sbarra alzata per la targa: " + targa);
                    break;
                case 1: // nessun utente associato alla targa
                    clientMap.get(idParcheggio).publish(TOPIC_ERRORE_SOSTA_IN, (idParcheggio + ",Targa non trovata").getBytes(), 1, false);
                    logger.log(Level.SEVERE, "Inviato messaggio di errore utente non trovato");
                    break;
                case 2: // sosta già in corso
                    clientMap.get(idParcheggio).publish(TOPIC_ERRORE_SOSTA_IN, (idParcheggio + ",Il veicolo identificato da " + targa + " è già in sosta").getBytes(), 1, false);
                    logger.log(Level.SEVERE, "Inviato messaggio di errore metodo pagamento non trovato");
                    break;
                case 3: // nessun metodo di pagamento
                    clientMap.get(idParcheggio).publish(TOPIC_ERRORE_SOSTA_IN, (idParcheggio + ",Nessun metodo di pagamento trovato").getBytes(), 1, false);
                    logger.log(Level.SEVERE, "Inviato messaggio di errore metodo pagamento non trovato");
                    break;
                case 4: // errore dao
                    logger.log(Level.SEVERE, "Errore del Dao");
                    break;
                default:
                    logger.log(Level.SEVERE, "Impossibile creare la sosta per la targa: " + targa);
                    break;
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Errore durante il controllo della targa: " + targa, e);
        }
    }

    private void handleControllaTargaOut(String payload) {
        String[] arr = payload.split(",");

        int idParcheggio = Integer.parseInt(arr[0]);
        String targa = arr[1];

        try {
            int res = ServizioSoste.terminaSosta(targa, idParcheggio);
            switch(res) {
                case 0: // targa valida, sosta terminata
                    clientMap.get(idParcheggio).publish(TOPIC_SBARRA_OUT, (idParcheggio + ",UP").getBytes(), 1, false);
                    logger.info("Sbarra alzata per la targa: " + targa);
                    break;
                case 1: // nessun utente associato alla targa
                    clientMap.get(idParcheggio).publish(TOPIC_ERRORE_SOSTA_OUT, (idParcheggio + ",Targa non trovata").getBytes(), 1, false);
                    logger.log(Level.SEVERE, "Inviato messaggio di errore utente non trovato");
                    break;
                case 2: // sosta non in corso
                    clientMap.get(idParcheggio).publish(TOPIC_ERRORE_SOSTA_OUT, (idParcheggio + ",Il veicolo identificato da " + targa + " non è in sosta").getBytes(), 1, false);
                    logger.log(Level.SEVERE, "Inviato messaggio di errore metodo pagamento non trovato");
                    break;
                case 3: // nessun metodo di pagamento
                    clientMap.get(idParcheggio).publish(TOPIC_ERRORE_SOSTA_OUT, (idParcheggio + ",Nessun metodo di pagamento trovato").getBytes(), 1, false);
                    logger.log(Level.SEVERE, "Inviato messaggio di errore metodo pagamento non trovato");
                    break;
                case 4: // errore dao
                    logger.log(Level.SEVERE, "Errore del Dao");
                    break;
                case 5: // pagamento non effettuato
                    clientMap.get(idParcheggio).publish(TOPIC_ERRORE_SOSTA_OUT, (idParcheggio + ",Impossibile effettuare il pagamento").getBytes(), 1, false);
                    logger.log(Level.SEVERE, "Inviato messaggo di errore pagamento non effettuato");
                    break;
                default:
                    logger.log(Level.SEVERE, "Impossibile creare la sosta per la targa: " + targa);
                    break;
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Errore durante il controllo della targa: " + targa, e);
        }
    }

    private void handleSensori(String topic, String payload) {
        String[] topicArr = topic.split("/");

        int sensore = Integer.parseInt(topicArr[2]);

        String[] payloadArr = payload.split(",");

        int idParcheggio = Integer.parseInt(payloadArr[0]);
        int stato = payloadArr[1].equals("LIBERO") ? POSTO_LIBERO : POSTO_OCCUPATO;

        try {
            ParcheggioDao.cambiaStatoPosto(idParcheggio, sensore, stato);
            PostoAuto postoAuto = ParcheggioDao.getPostoAutoById(idParcheggio, sensore);
            DataSender.sendData(frontEndBaseUrl + notificaOccupazionePostoApiUrl, GSON.toJson(postoAuto));
            logger.info("Stato posto aggiornato per il sensore: " + sensore);
        } catch (DaoException e) {
            logger.log(Level.SEVERE, "Errore durante l'aggiornamento dello stato del posto: " + sensore, e);
        }
    }

    private void handleRicaricaStato(String payload) {
        try {
            String[] arr = payload.split(",");

            int idRicarica = Integer.parseInt(arr[1]);
            int percentualeAttuale = Integer.parseInt(arr[2]);
            float kilowattRicaricati = Float.parseFloat(arr[3]);
            int potenzaKilowatt = Integer.parseInt(arr[4]);

            Ricarica ricarica = ServizioRicariche.getRicaricaById(idRicarica);

            if (ricarica == null) {
                logger.log(Level.SEVERE, "Ricarica null");
                return;
            }

            ServizioRicariche.aggiornaRicarica(idRicarica, percentualeAttuale, kilowattRicaricati, potenzaKilowatt, ServizioRicariche.IN_CORSO);

            if (ricarica.getStato() == ServizioRicariche.IN_CODA) {
                DataSender.sendData(frontEndBaseUrl + notificaInizioRicaricaApiUrl, GSON.toJson(ricarica));
            } else {
                DataSender.sendData(frontEndBaseUrl + notificaRicaricaApiUrl, GSON.toJson(ricarica));
            }

            logger.info("Aggiornato stato ricarica: " + idRicarica);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Errore durante l'aggiornamento dello stato della ricarica.", e);
        }
    }

    private void handleRicaricaTerm(String payload) {
        try {
            String[] arr = payload.split(",");

            int idRicarica = Integer.parseInt(arr[1]);
            int percentualeAttuale = Integer.parseInt(arr[2]);
            float kilowattRicaricati = Float.parseFloat(arr[3]);

            ServizioRicariche.terminaRicarica(idRicarica, percentualeAttuale, kilowattRicaricati, ServizioRicariche.EROGATA);

            Ricarica ricarica = ServizioRicariche.getRicaricaById(idRicarica);

            if (ricarica == null) {
                logger.log(Level.SEVERE, "Ricarica null");
                return;
            }

            DataSender.sendData(frontEndBaseUrl + notificaTermineRicaricaApiUrl, GSON.toJson(ricarica));

            if (ricarica.isNotifica()) {
                Utente utente;

                try {
                    utente = UtenteDao.getById(ricarica.getIdUtente());
                } catch (DaoException e) {
                    logger.log(Level.SEVERE, "Errore durante il recupero dell'utente");
                    return;
                }

                EmailSender.sendEmail(utente.getEmail(), utente.getNome() + " " + utente.getCognome(), "Termine ricarica", draftTextPart(utente, ricarica), draftHtmlPart(utente, ricarica));
            }

            logger.info("Terminata ricarica: " + idRicarica);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Errore durante la terminazione della ricarica", e);
        }
    }

    private static String draftHtmlPart(Utente utente, Ricarica ricarica) {
        return "<h3>Gentile " +  utente.getNome() + " " + utente.getCognome() + ".</h3><br />"
                + "<p>Ti informiamo che la tua ricarica &egrave; terminata con successo.</p><br>"
                + "<ul>"
                + "<li>Percentuale raggiunta: " + ricarica.getPercentualeAttuale() + "%.</li>"
                + "<li>Kilowatt ricaricati: " + ricarica.getKilowattRicaricati() + "kW.</li>"
                + "<li>Prezzo: " + ricarica.getPrezzoRicarica() * ricarica.getKilowattRicaricati() + "&euro;.</li>"
                + "</ul>"
                + "<br /><br />"
                + "<div style=\"text-align: center;\">"
                + "<p>&copy; SmartParking, Vercelli, via Duomo 6,<br />13100, Italia (IT)"
                + "</div>";
    }

    private static String draftTextPart(Utente utente, Ricarica ricarica) {
        return "Gentile " +  utente.getNome() + " " + utente.getCognome() + ".\n"
                + "Ti informiamo che la tua ricarica è terminata con successo.\n"
                + "- Percentuale raggiunta: " + ricarica.getPercentualeAttuale() + "%.\n"
                + "- Kilowatt ricaricati: " + ricarica.getKilowattRicaricati() + "kW.\n"
                + "- Prezzo: " + ricarica.getPrezzoRicarica() * ricarica.getKilowattRicaricati() + "€.\n";
    }

    /* private void handleNotificaNumeroCoda(String payload) {
        String[] arr = payload.split(" ");

        Ricarica ricarica = ServizioRicariche.getRicaricaById(Integer.parseInt(arr[0]));

        if (ricarica == null) {
            logger.log(Level.SEVERE, "Ricarica null");
            return;
        }

        String[] temp = new String[]{String.valueOf(ricarica.getIdUtente()), arr[0], arr[1]};

        DataSender.sendData(frontEndBaseUrl + notificaNumeroCodaApiUrl, GSON.toJson(arr));
    } */
}
