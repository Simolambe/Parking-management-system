package utils;

import dao.DaoException;
import dao.PrenotazioniDao;
import models.Prenotazione;
import services.ServizioPrenotazioni;

import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControllorePrenotazioni {

    private Thread thread;

    private static ControllorePrenotazioni instance;
    private static final Logger logger = Logger.getLogger(ControllorePrenotazioni.class.getName());

    public static synchronized ControllorePrenotazioni getInstance() {
        if (instance == null) {
            instance = new ControllorePrenotazioni();
        }
        return instance;
    }

    public void controllaPrenotazioni(int timeout) {
        thread = new Thread(() -> controllaPrenotazioniImpl(timeout));
        thread.start();
    }

    public void interrupt() {
        thread.interrupt();
    }

    private static void controllaPrenotazioniImpl(int timeout) {
        try {
            while(!Thread.currentThread().isInterrupted()) {
                for (Prenotazione prenotazione : PrenotazioniDao.getPrenotazioniValide()) {
                    if (!isValid(prenotazione)) {
                        PrenotazioniDao.cambiaStato(prenotazione.getIdPrenotazione(), ServizioPrenotazioni.SCADUTA);
                    }
                }
                Thread.sleep(timeout);
            }
        } catch (InterruptedException | DaoException e) {
            logger.log(Level.SEVERE, "Catched exception, stoppind thread.", e);
            Thread.currentThread().interrupt();
        }
    }

    private static boolean isValid(Prenotazione prenotazione) {
        LocalDateTime now = LocalDateTime.now();
        return !prenotazione.getTempoInizio().isBefore(now) && !prenotazione.getTempoInizio().isAfter(now.plusMinutes(15));
    }

}
