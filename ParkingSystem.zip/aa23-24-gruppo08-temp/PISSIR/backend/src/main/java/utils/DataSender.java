package utils;

import javax.net.ssl.*;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.security.GeneralSecurityException;
import java.security.cert.X509Certificate;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataSender {

    private static final SSLContext sslContext;
    private static final Logger logger = Logger.getLogger(DataSender.class.getName());

    static {
        SSLContext temp = null;

        try {
            temp = configureTrustAllCerts();
        } catch (GeneralSecurityException e) {
            logger.log(Level.SEVERE,
                    "Impossibile configurare il contesto SSL per ignorare la verifica del certificato SSL");
        }

        sslContext = temp;
    }

    public static void sendData(String uri, String data) {
        HttpClient client = HttpClient.newBuilder()
                .sslContext(sslContext)
                .build();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .header("Content-Type", "application/json")
                .POST(BodyPublishers.ofString(data))
                .build();

        try {
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            logger.log(Level.INFO, "Dati inviati correttamente: " + data);
            logger.log(Level.INFO, "Response status code: " + response.statusCode());
            logger.log(Level.INFO, "Response body: " + response.body());
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Errore di I/O durante l'invio dei dati", e);
        } catch (InterruptedException e) {
            logger.log(Level.SEVERE, "Invio interrotto", e);
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Errore generico durante l'invio dei dati", e);
        }
    }

    private static SSLContext configureTrustAllCerts() throws GeneralSecurityException {
        TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                    }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                    }
                }
        };

        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        return sc;
    }
}