package utils;

import com.mailjet.client.errors.MailjetException;
import com.mailjet.client.errors.MailjetSocketTimeoutException;
import com.mailjet.client.MailjetClient;
import com.mailjet.client.MailjetRequest;
import com.mailjet.client.MailjetResponse;
import com.mailjet.client.ClientOptions;
import com.mailjet.client.resource.Emailv31;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.logging.Logger;

public class EmailSender {

    private static final String API_KEY = "49aeb3a2708e44530072a2d685710cac";
    private static final String API_SECRET = "da5a7df0209bd8b83762bf2d2c06c3a8";
    private static final MailjetClient client = new MailjetClient(API_KEY, API_SECRET, new ClientOptions("v3.1"));
    private static final String FROM = "20046007@studenti.uniupo.it";
    private static final String NAME = "Smart Parking";
    private static final Logger logger = Logger.getLogger(MQTTCallback.class.getName());

    public static void sendEmail(String to, String name, String subject, String textpart, String htmlPart) throws MailjetSocketTimeoutException, MailjetException {
        MailjetRequest request = new MailjetRequest(Emailv31.resource)
                .property(Emailv31.MESSAGES, new JSONArray()
                        .put(new JSONObject()
                                .put(Emailv31.Message.FROM, new JSONObject()
                                        .put("Email", FROM)
                                        .put("Name", NAME))
                                .put(Emailv31.Message.TO, new JSONArray()
                                        .put(new JSONObject()
                                                .put("Email", to)
                                                .put("Name", name)))
                                .put(Emailv31.Message.SUBJECT, subject)
                                .put(Emailv31.Message.TEXTPART, textpart)
                                .put(Emailv31.Message.HTMLPART, htmlPart)));

        MailjetResponse response = client.post(request);

        logger.info("Response status: " + response.getStatus() + ". Response data: " + response.getData());
    }

}
