package utils;

import org.tomlj.Toml;
import org.tomlj.TomlArray;
import org.tomlj.TomlParseResult;
import org.tomlj.TomlTable;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Config {
    private static Config instance;

    // [brokers]
    private final Map<Integer, String> MAP_BROKERS = new HashMap<>();

    // [topics]
    private String TOPIC_CONTROLLA_TARGA_IN;
    private String TOPIC_CONTROLLA_TARGA_OUT;
    private String TOPIC_ERRORE_SOSTA_IN;
    private String TOPIC_ERRORE_SOSTA_OUT;
    private String TOPIC_SBARRA_IN;
    private String TOPIC_SBARRA_OUT;
    private String TOPIC_SENSORI;
    private String TOPIC_CODA_RIC_ADD;
    private String TOPIC_CODA_RIC_NUM_CODA;
    private String TOPIC_RIC_STATO;
    private String TOPIC_RIC_TERM;
    private String TOPIC_RIC_INT;
    private String TOPIC_RIC_CANC;
    private String TOPIC_LWT;

    // [db]
    private String DBLOC;

    // [frontend]
    private String base_url;
    private String notifica_ricarica_api_url;
    private String notifica_termine_ricarica_api_url;
    private String notifica_inizio_ricarica_api_url;
    private String notifica_occupazione_posto_api_url;
    // private String notifica_numero_coda_api_url;

    // [api]
    private int PORT;
    private String API_ROOT;
    private String API_VERSION;

    // [abbonamento]
    private float COSTO_ABBONAMENTO;

    private Config() {
        try {
            Path source = Paths.get("config.toml");
            TomlParseResult result = Toml.parse(source);

            result.errors().forEach(error -> System.err.println("Parsing error: " + error.toString()));

            if (!result.hasErrors()) {
                DBLOC = result.getString("db.dbloc");

                TOPIC_CONTROLLA_TARGA_IN = result.getString("topics.TOPIC_CONTROLLA_TARGA_IN");
                TOPIC_CONTROLLA_TARGA_OUT = result.getString("topics.TOPIC_CONTROLLA_TARGA_OUT");
                TOPIC_ERRORE_SOSTA_IN = result.getString("topics.TOPIC_ERRORE_SOSTA_IN");
                TOPIC_ERRORE_SOSTA_OUT = result.getString("topics.TOPIC_ERRORE_SOSTA_OUT");
                TOPIC_SBARRA_IN = result.getString("topics.TOPIC_SBARRA_IN");
                TOPIC_SBARRA_OUT = result.getString("topics.TOPIC_SBARRA_OUT");
                TOPIC_SENSORI = result.getString("topics.TOPIC_SENSORI");
                TOPIC_CODA_RIC_ADD = result.getString("topics.TOPIC_CODA_RIC_ADD");
                TOPIC_CODA_RIC_NUM_CODA = result.getString("topics.TOPIC_CODA_RIC_NUM_CODA");
                TOPIC_RIC_STATO = result.getString("topics.TOPIC_RIC_STATO");
                TOPIC_RIC_TERM = result.getString("topics.TOPIC_RIC_TERM");
                TOPIC_RIC_INT = result.getString("topics.TOPIC_RIC_INT");
                TOPIC_RIC_CANC = result.getString("topics.TOPIC_RIC_CANC");
                TOPIC_LWT = result.getString("topics.TOPIC_LWT");

                TomlArray brokers = result.getArray("brokers");
                for (int i = 0; i < brokers.size(); i++) {
                    TomlTable table = brokers.getTable(i);
                    MAP_BROKERS.put(table.getLong("id_parcheggio").intValue(), table.getString("broker_url"));
                }

                base_url = result.getString("frontend.base_url");
                notifica_ricarica_api_url = result.getString("frontend.notifica_ricarica_api_url");
                notifica_termine_ricarica_api_url = result.getString("frontend.notifica_termine_ricarica_api_url");
                notifica_inizio_ricarica_api_url = result.getString("frontend.notifica_inizio_ricarica_api_url");
                notifica_occupazione_posto_api_url = result.getString("frontend.notifica_occupazione_posto_api_url");
                // notifica_numero_coda_api_url = result.getString("frontend.notifica_numero_coda_api_url");

                PORT = result.getLong("api.port").intValue();
                API_ROOT = result.getString("api.api_root");
                API_VERSION = result.getString("api.api_version");

                COSTO_ABBONAMENTO = result.getDouble("abbonamento.costo").floatValue();
            }
        } catch (IOException e) {
            System.err.println("Errore durante la lettura del file di configurazione: " + e.getMessage());
        }
    }

    public static synchronized Config getInstance() {
        if (instance == null) {
            instance = new Config();
        }
        return instance;
    }

    // Getters
    public Map<Integer, String> getMapBrokers() {
        return MAP_BROKERS;
    }

    public String getTopicControllaTargaIn() {
        return TOPIC_CONTROLLA_TARGA_IN;
    }

    public String getTopicControllaTargaOut() {
        return TOPIC_CONTROLLA_TARGA_OUT;
    }

    public String getTopicErroreSostaIn() {
        return TOPIC_ERRORE_SOSTA_IN;
    }

    public String getTopicErroreSostaOut() {
        return TOPIC_ERRORE_SOSTA_OUT;
    }

    public String getTopicSbarraIn() {
        return TOPIC_SBARRA_IN;
    }

    public String getTopicSbarraOut() {
        return TOPIC_SBARRA_OUT;
    }

    public String getTopicSensori() {
        return TOPIC_SENSORI;
    }

    public String getTopicCodaRicAdd() {
        return TOPIC_CODA_RIC_ADD;
    }

    public String getTopicCodaRicNumCoda() {
        return TOPIC_CODA_RIC_NUM_CODA;
    }

    public String getTopicRicStato() {
        return TOPIC_RIC_STATO;
    }

    public String getTopicRicTerm() {
        return TOPIC_RIC_TERM;
    }

    public String getTopicRicInt() {
        return TOPIC_RIC_INT;
    }

    public String getTopicRicCanc() {
        return TOPIC_RIC_CANC;
    }

    public String getTopicLwt() {
        return TOPIC_LWT;
    }

    public String getDbloc() {
        return DBLOC;
    }

    public String getFrontEndBaseUrl() {
        return base_url;
    }

    public String getNotificaRicaricaApiUrl() {
        return notifica_ricarica_api_url;
    }

    public String getNotificaTermineRicaricaApiUrl() {
        return notifica_termine_ricarica_api_url;
    }

    public String getNotificaInizioRicaricaApiUrl() {
        return notifica_inizio_ricarica_api_url;
    }

    public String getNotificaOccupazionePostoApiUrl() {
        return notifica_occupazione_posto_api_url;
    }

    public int getPort() {
        return PORT;
    }

    public String getApiRoot() {
        return API_ROOT;
    }

    public String getApiVersion() {
        return API_VERSION;
    }

    public float getCostoAbbonamento() {
        return COSTO_ABBONAMENTO;
    }
}
