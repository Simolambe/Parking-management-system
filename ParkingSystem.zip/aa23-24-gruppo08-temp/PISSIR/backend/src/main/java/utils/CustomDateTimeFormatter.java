package utils;

import java.time.format.DateTimeFormatter;

public class CustomDateTimeFormatter {

    public static final DateTimeFormatter CUSTOM_DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
}
